<?php
namespace PontifexOI\PublicPart;

use PontifexOI\Api\SoapClient;
use Mollie\Api\MollieApiClient;
use PontifexOI\PublicPart\PaymentSuccessShortcode;
use PontifexOI\Helpers\PaymentHelpers; // <-- Gebruik ALTIJD deze helper!

class Frontend {
    private static $instance = null;

    public static function get_instance() {
        return self::$instance ?: (self::$instance = new self());
    }

    private function __construct() {
        add_shortcode('pontifex_oi_planning',     [$this, 'render_planning_shortcode']);
        add_shortcode('pontifex_oi_registration', [$this, 'render_registration_shortcode']);
        add_action('wp_enqueue_scripts',          [$this, 'enqueue_assets']);
        add_action('wp_ajax_pontifex_oi_process_payment', [$this, 'process_payment']);
        add_action('wp_ajax_pontifex_oi_get_planning',        [$this, 'ajax_get_planning']);
        add_action('wp_ajax_nopriv_pontifex_oi_get_planning', [$this, 'ajax_get_planning']);
        add_action('wp_ajax_pontifex_oi_get_filter_options',        [$this, 'ajax_get_filter_options']);
        add_action('wp_ajax_nopriv_pontifex_oi_get_filter_options', [$this, 'ajax_get_filter_options']);
        add_action('init', function() {
            PaymentSuccessShortcode::register_shortcode();
        });
    }

    public function enqueue_assets() {
        if (!is_admin()) {
            global $post;
            $has_planning     = false;
            $has_registration = false;
            if (is_a($post, 'WP_Post') && isset($post->post_content)) {
                $has_planning     = strpos($post->post_content, '[pontifex_oi_planning]') !== false;
                $has_registration = strpos($post->post_content, '[pontifex_oi_registration]') !== false;
            }
            wp_enqueue_style('pontifex-oi-shared', PONTIFEX_OI_URL . 'assets/css/pontifex-oi-shared.css', [], PONTIFEX_OI_VERSION);
            if ($has_planning) {
                wp_enqueue_style('pontifex-oi-planning', PONTIFEX_OI_URL . 'assets/css/pontifex-oi-planning.css', ['pontifex-oi-shared'], PONTIFEX_OI_VERSION);
            }
            if ($has_registration) {
                wp_enqueue_style('pontifex-oi-registration', PONTIFEX_OI_URL . 'assets/css/pontifex-oi-registration.css', ['pontifex-oi-shared'], PONTIFEX_OI_VERSION);
            }
            wp_enqueue_style('pontifex-oi-payment-success', PONTIFEX_OI_URL . 'assets/css/pontifex-oi-payment-success.css', [], PONTIFEX_OI_VERSION);
            wp_enqueue_script('pontifex-oi', PONTIFEX_OI_URL . 'assets/js/pontifex-oi.js', ['jquery'], PONTIFEX_OI_VERSION, true);
            wp_localize_script('pontifex-oi', 'PontifexOiAjax', [
                'ajax_url' => admin_url('admin-ajax.php'),
            ]);
        }
    }

    public function render_planning_shortcode($atts = []) {
        $soap = new SoapClient();
        $filters = [
            'exam_type' => $_GET['exam_type'] ?? '',
            'language'  => $_GET['language'] ?? '',
            'material'  => $_GET['material'] ?? '',
            'month'     => $_GET['month'] ?? '',
            'province'  => $_GET['province'] ?? '',
            'location'  => $_GET['location'] ?? '',
            'timeslot'  => $_GET['timeslot'] ?? '',
            'page'      => isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1,
        ];
        $per_page   = 10;
        $exam_types = $soap->getExamTypes();
        $languages  = $soap->getLanguages($filters);
        $materials  = $soap->getMaterials($filters);
        $months     = $soap->getMonths($filters);
        $provinces  = $soap->getProvinces($filters);
        $locations  = $soap->getLocations($filters);
        $timeslots  = $soap->getTimeslots($filters);
        $all_planning  = $soap->getPlanning($filters);
        $total_results = count($all_planning);
        $total_pages   = (int) ceil($total_results / $per_page);
        $offset        = ($filters['page'] - 1) * $per_page;
        $planning      = array_slice($all_planning, $offset, $per_page);

        $args = [
            'exam_types'   => $exam_types,
            'languages'    => $languages,
            'materials'    => $materials,
            'months'       => $months,
            'provinces'    => $provinces,
            'locations'    => $locations,
            'timeslots'    => $timeslots,
            'planning'     => $planning,
            'filters'      => $filters,
            'current_page' => $filters['page'],
            'total_pages'  => $total_pages,
            'per_page'     => $per_page,
        ];

        ob_start();
        include PONTIFEX_OI_PATH . 'templates/planning-list.php';
        return ob_get_clean();
    }

    public function render_registration_shortcode($atts = []) {
        ob_start();
        include PONTIFEX_OI_PATH . 'templates/registration-form.php';
        return ob_get_clean();
    }

    public function ajax_get_planning() {
        $filters  = $_POST['filters'] ?? [];
        $page     = isset($filters['page']) ? max(1, (int) $filters['page']) : 1;
        $per_page = isset($filters['per_page']) ? max(1, (int) $filters['per_page']) : 10;
        $soap     = new SoapClient();
        $all      = $soap->getPlanning($filters);
        $total    = count($all);
        $total_pg = max(1, (int) ceil($total / $per_page));
        $offset   = ($page - 1) * $per_page;
        $planning = array_slice($all, $offset, $per_page);

        wp_send_json_success([
            'planning'     => $planning,
            'current_page' => $page,
            'total_pages'  => $total_pg,
        ]);
    }

    public function ajax_get_filter_options() {
        $filter  = $_POST['filter']  ?? '';
        $filters = $_POST['filters'] ?? [];
        $soap    = new SoapClient();
        $options = [];
        switch ($filter) {
            case 'location': $options = $soap->getLocations($filters); break;
            case 'language': $options = $soap->getLanguages($filters); break;
            case 'material': $options = $soap->getMaterials($filters); break;
            case 'month':    $options = $soap->getMonths($filters);    break;
            case 'province': $options = $soap->getProvinces($filters); break;
            case 'timeslot': $options = $soap->getTimeslots($filters); break;
        }
        wp_send_json_success(['options' => $options]);
    }

    public function process_payment() {
        $amount = $_POST['amount'] ?? 10.00;
        $description = 'Inschrijving voor examen';

        // Gebruik altijd de centrale helper voor API-key!
        $apiKey = PaymentHelpers::get_mollie_api_key();

        // Je zou het Mollie profileId (indien gewenst) ook via admin settings kunnen doen.
        $profileId = defined('PONTIFEX_MOLLIE_PROFILE_ID')
            ? PONTIFEX_MOLLIE_PROFILE_ID
            : null;

        $mollie = new MollieApiClient();
        $mollie->setApiKey($apiKey);

        try {
            $paymentArgs = [
                'amount' => [
                    'currency' => 'EUR',
                    'value'    => number_format($amount, 2, '.', ''),
                ],
                'description' => $description,
                'redirectUrl' => home_url('/thank-you'),
                'webhookUrl'  => home_url('/mollie-webhook'),
            ];
            // Voeg profileId toe als gewenst
            if ($profileId) {
                $paymentArgs['profileId'] = $profileId;
            }

            $payment = $mollie->payments->create($paymentArgs);
            wp_send_json_success(['payment_url' => $payment->getCheckoutUrl()]);
        } catch (\Exception $e) {
            wp_send_json_error(['message' => 'Betaling kon niet worden verwerkt: ' . $e->getMessage()]);
        }
    }
}