<?php
namespace PontifexOI\PublicPart;

use Mollie\Api\MollieApiClient;
use PontifexOI\PublicPart\PaymentSuccessShortcode;
use PontifexOI\Helpers\PaymentHelpers;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Include de helper voor prijsberekening
require_once PONTIFEX_OI_PATH . 'includes/helpers/producten-prijzen.php';

class Frontend {
    private static $instance = null;

    public static function get_instance() {
        return self::$instance ?: (self::$instance = new self());
    }

    private function __construct() {
        // Shortcodes
        add_shortcode('pontifex_oi_planning',     [$this, 'render_planning_shortcode']);
        add_shortcode('pontifex_oi_registration', [$this, 'render_registration_shortcode']);

        // Scripts & styles
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);

        // AJAX endpoints
        add_action('wp_ajax_pontifex_oi_process_payment',     [$this, 'process_payment']);
        add_action('wp_ajax_pontifex_oi_get_planning',        [$this, 'ajax_get_planning']);
        add_action('wp_ajax_nopriv_pontifex_oi_get_planning', [$this, 'ajax_get_planning']);
        add_action('wp_ajax_pontifex_oi_get_filter_options',        [$this, 'ajax_get_filter_options']);
        add_action('wp_ajax_nopriv_pontifex_oi_get_filter_options', [$this, 'ajax_get_filter_options']);
        add_action('wp_ajax_pontifex_oi_get_price',        [$this, 'ajax_get_price']);
        add_action('wp_ajax_nopriv_pontifex_oi_get_price', [$this, 'ajax_get_price']);

        // Init payment-success shortcode
        add_action('init', function() {
            PaymentSuccessShortcode::register_shortcode();
        });
    }

    public function enqueue_assets() {
        if (is_admin()) {
            return; // Geen styles laden in de admin omgeving
        }

        // Globale variabele voor de huidige post
        global $post;

        // Controleer of de planning en registratie shortcodes aanwezig zijn op de pagina
        $has_planning     = is_a($post, 'WP_Post') && strpos($post->post_content, '[pontifex_oi_planning]') !== false;
        $has_registration = is_a($post, 'WP_Post') && strpos($post->post_content, '[pontifex_oi_registration]') !== false;

        // Laad de gedeelde stylesheet altijd
        wp_enqueue_style('pontifex-oi-shared', PONTIFEX_OI_URL . 'assets/css/pontifex-oi-shared.css', [], PONTIFEX_OI_VERSION);

        // Laad de planning stylesheet alleen als de planning shortcode op de pagina staat
        if ($has_planning) {
            wp_enqueue_style('pontifex-oi-planning', PONTIFEX_OI_URL . 'assets/css/pontifex-oi-planning.css', ['pontifex-oi-shared'], PONTIFEX_OI_VERSION);
        }

        // Laad de registratie stylesheet alleen als de registratie shortcode op de pagina staat
        if ($has_registration) {
            wp_enqueue_style('pontifex-oi-registration', PONTIFEX_OI_URL . 'assets/css/pontifex-oi-registration.css', ['pontifex-oi-shared'], PONTIFEX_OI_VERSION);
        }

        // Laad de betalingssucces stylesheet altijd (ook in admin)
        wp_enqueue_style('pontifex-oi-payment-success', PONTIFEX_OI_URL . 'assets/css/pontifex-oi-payment-success.css', [], PONTIFEX_OI_VERSION);

        // Laad de JavaScript bestanden
        wp_enqueue_script('pontifex-oi', PONTIFEX_OI_URL . 'assets/js/pontifex-oi.js', ['jquery'], PONTIFEX_OI_VERSION, true);

        // Lokaliseren van de script met de juiste ajax_url
        wp_localize_script('pontifex-oi', 'PontifexOiAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
        ]);
    }

    public function render_planning_shortcode($atts = []) {
        // Filters uit URL
        $filters = array_merge([
            'exam_type' => '',
            'language'  => '',
            'material'  => '',
            'daytype'   => '',
            'month'     => '',
            'province'  => '',
            'location'  => '',
            'timeslot'  => '',
            'page'      => 1,
        ], array_intersect_key($_GET, array_flip([
            'exam_type','language','material','daytype','month','province','location','timeslot','page'
        ])));

        // Zet defaults bij eerste bezoek
        if (empty($filters['exam_type'])) $filters['exam_type'] = 'los-examen-vca-basis';
        if (empty($filters['language'])) $filters['language'] = 'nl';
        if (empty($filters['material'])) $filters['material'] = '1';

        // Hardcoded dropdown-opties
        $args['exam_types'] = [
            ['id'=>'','name'=>'Toon alles'],
            ['id'=>'los-examen-vca-basis','name'=>'VCA Basis'],
            ['id'=>'los-examen-vca-vol','name'=>'VCA Vol'],
            ['id'=>'vca-basis-weekend','name'=>'VCA Basis Cursus Weekend'],
            ['id'=>'vca-vol-weekend','name'=>'VCA Vol Cursus Weekend'],
        ];
        $args['languages'] = [
            ['id'=>'','name'=>'Toon alles'],
            ['id'=>'nl','name'=>'Nederlands'],
            ['id'=>'en','name'=>'Engels'],
        ];
        $args['materials'] = [
            ['id'=>'','name'=>'Geen keuze'],
            ['id'=>'1','name'=>'Los examen'],
            ['id'=>'2','name'=>'Examen + boek'],
            ['id'=>'4','name'=>'Examen + e-learning'],
            ['id'=>'5','name'=>'Examen + proefexamens'],
            ['id'=>'6','name'=>'Examen + boek + proefexamens'],
            ['id'=>'7','name'=>'Examen + e-learning + proefexamens'],
        ];

        // SOAP-client voor de rest van de filters en planning
        $soap = new \PontifexOI\Api\SoapClient();

        $per_page       = 10;
        $all_planning   = $soap->getPlanning($filters);
        $total_results  = count($all_planning);
        $total_pages    = (int) ceil($total_results / $per_page);
        $offset         = ($filters['page'] - 1) * $per_page;
        $planning       = array_slice($all_planning, $offset, $per_page);

        $args += [
            'months'       => $soap->getMonths($filters),
            'provinces'    => $soap->getProvinces($filters),
            'locations'    => $soap->getLocations($filters),
            'timeslots'    => $soap->getTimeslots($filters),
            'planning'     => $planning,
            'filters'      => $filters,
            'current_page' => $filters['page'],
            'total_pages'  => $total_pages,
            'per_page'     => $per_page,
        ];

        ob_start();
        include PONTIFEX_OI_PATH . 'templates/planning-list.php';
        return ob_get_clean();
    }

    public function render_registration_shortcode($atts = []) {
        // Haal GET-parameters op en geef deze door aan het template
        $defaults = [
            'exam_type' => isset($_GET['exam_type']) ? sanitize_text_field($_GET['exam_type']) : '',
            'language' => isset($_GET['language']) ? sanitize_text_field($_GET['language']) : '',
            'material' => isset($_GET['material']) ? sanitize_text_field($_GET['material']) : '',
            'date' => isset($_GET['date']) ? sanitize_text_field($_GET['date']) : '',
            'time' => isset($_GET['time']) ? sanitize_text_field($_GET['time']) : '',
            'location' => isset($_GET['location']) ? sanitize_text_field($_GET['location']) : '',
            'province' => isset($_GET['province']) ? sanitize_text_field($_GET['province']) : '',
            'spots' => isset($_GET['spots']) ? sanitize_text_field($_GET['spots']) : '',
            'price' => isset($_GET['price']) ? sanitize_text_field($_GET['price']) : '',
        ];
        // Stuur de data naar het registratie-formulier
        ob_start();
        include PONTIFEX_OI_PATH . 'templates/registration-form.php';
        $output = ob_get_clean();
        // Vervang eventueel placeholders met deze waarden in het template
        // Of laat JS deze invullen aan de hand van deze $defaults (verstandig bij AJAX/SPA gedrag)
        return $output;
    }

    public function ajax_get_planning() {
        $filters  = $_POST['filters'] ?? [];
        $page     = max(1, (int) ($filters['page']     ?? 1));
        $per_page = max(1, (int) ($filters['per_page'] ?? 10));
        $soap     = new \PontifexOI\Api\SoapClient();

        $all       = $soap->getPlanning($filters);
        $total     = count($all);
        $total_pg  = max(1, (int) ceil($total / $per_page));
        $offset    = ($page - 1) * $per_page;
        $planning  = array_slice($all, $offset, $per_page);

        wp_send_json_success([
            'planning'     => $planning,
            'current_page' => $page,
            'total_pages'  => $total_pg,
        ]);
    }

    public function ajax_get_filter_options() {
        $filter  = $_POST['filter']  ?? '';
        $filters = $_POST['filters'] ?? [];
        $soap    = new \PontifexOI\Api\SoapClient();
        $options = [];

        switch ($filter) {
            case 'location': $options = $soap->getLocations($filters); break;
            case 'language': $options = $soap->getLanguages($filters); break;
            case 'material': $options = $soap->getMaterials($filters); break;
            case 'month':    $options = $soap->getMonths($filters);    break;
            case 'province': $options = $soap->getProvinces($filters); break;
            case 'timeslot': $options = $soap->getTimeslots($filters); break;
        }

        wp_send_json_success(['options' => $options]);
    }

    /**
     * AJAX handler voor dynamische prijs
     */
    public function ajax_get_price() {
        $exam_type = sanitize_text_field($_POST['exam_type'] ?? '');
        $language  = sanitize_text_field($_POST['language']  ?? '');
        $material  = sanitize_text_field($_POST['material']  ?? '');

        // Haal prijs op via helper
        $price = get_product_price($exam_type, $language, $material);

        // Format als eurobedrag
        $price_str = (is_numeric($price) && $price > 0)
            ? '€' . number_format((float)$price, 2, ',', '.')
            : '';

        wp_send_json_success(['price' => $price_str]);
    }

    /**
     * AJAX handler voor Mollie-betaling
     */
    public function process_payment() {
        $amount      = $_POST['amount']      ?? 10.00;
        $description = 'Inschrijving voor examen';

        $apiKey    = PaymentHelpers::get_mollie_api_key();
        $profileId = defined('PONTIFEX_MOLLIE_PROFILE_ID') ? PONTIFEX_OI_MOLLIE_PROFILE_ID : null;

        $mollie = new MollieApiClient();
        $mollie->setApiKey($apiKey);

        try {
            $paymentArgs = [
                'amount'      => ['currency' => 'EUR', 'value' => number_format($amount, 2, '.', '')],
                'description' => $description,
                'redirectUrl' => home_url('/thank-you'),
                'webhookUrl'  => home_url('/mollie-webhook'),
            ];
            if ($profileId) {
                $paymentArgs['profileId'] = $profileId;
            }
            $payment = $mollie->payments->create($paymentArgs);
            wp_send_json_success(['payment_url' => $payment->getCheckoutUrl()]);
        } catch (\Exception $e) {
            wp_send_json_error(['message' => 'Betaling kon niet worden verwerkt: ' . $e->getMessage()]);
        }
    }
}

// Initialise
Frontend::get_instance();