<?php
namespace PontifexOI\PublicPart;

use PontifexOI\PublicPart\PaymentHelpers; // Voeg de helperclass toe

class PaymentSuccessShortcode {

    // Registreer de shortcode
    public static function register_shortcode() {
        add_shortcode('pontifex_oi_payment_success', [self::class, 'render']);
    }

    /**
     * Render de betalingssucces pagina
     */
    public static function render($atts) {
        // Start output buffer om HTML op te vangen
        ob_start();

        // Dummy text voor testmodus
        $is_test_mode = PaymentHelpers::is_test_mode();

        // Gegevens kandidaat ophalen (4 velden op één rij)
        $candidate_fullname = $is_test_mode ? 'Jan Jansen' : PaymentHelpers::get_data('candidate_fullname');
        $candidate_infix = $is_test_mode ? 'de' : PaymentHelpers::get_data('candidate_infix');
        $candidate_lastname = $is_test_mode ? 'Jansen' : PaymentHelpers::get_data('candidate_lastname');
        $candidate_birthdate = $is_test_mode ? '01-01-1990' : PaymentHelpers::get_data('candidate_birthdate');

        // Bestelgegevens ophalen
        $order_initials = $is_test_mode ? 'J' : PaymentHelpers::get_data('order_initials');
        $order_infix = $is_test_mode ? 'de' : PaymentHelpers::get_data('order_infix');
        $order_lastname = $is_test_mode ? 'Jansen' : PaymentHelpers::get_data('order_lastname');
        $order_postcode = $is_test_mode ? '1234 AB' : PaymentHelpers::get_data('order_postcode');
        $order_housenumber = $is_test_mode ? '56' : PaymentHelpers::get_data('order_housenumber');
        $order_street = $is_test_mode ? 'Main Street' : PaymentHelpers::get_data('order_street');
        $order_city = $is_test_mode ? 'Amsterdam' : PaymentHelpers::get_data('order_city');
        $order_phone = $is_test_mode ? '0612345678' : PaymentHelpers::get_data('order_phone');
        $order_email = $is_test_mode ? 'test@example.com' : PaymentHelpers::get_data('order_email');
        $order_company = $is_test_mode ? 'Test Company' : PaymentHelpers::get_data('order_company');
        $order_vat = $is_test_mode ? 'NL123456789B01' : PaymentHelpers::get_data('order_vat');

        // Betalingsgegevens ophalen
        $exam_label = $is_test_mode ? 'VCA' : PaymentHelpers::get_data('exam_label');
        $language_label = $is_test_mode ? 'Nederlands' : PaymentHelpers::get_data('language_label');
        $material_label = $is_test_mode ? 'Boek' : PaymentHelpers::get_data('material_label');
        $location = $is_test_mode ? 'Breda' : PaymentHelpers::get_data('location');
        $date = $is_test_mode ? '01-12-2025' : PaymentHelpers::get_data('date');
        $time = $is_test_mode ? '10:00' : PaymentHelpers::get_data('time');
        $amount = $is_test_mode ? '1' : PaymentHelpers::get_data('amount');
        $price = $is_test_mode ? '€100.00' : PaymentHelpers::get_data('price');
        $btw = $is_test_mode ? '€21.00' : PaymentHelpers::get_data('btw');
        $total = $is_test_mode ? '€121.00' : PaymentHelpers::get_data('total');

        ?>
        <div class="pontifex-oi-payment-success">
            <h2 class="pontifex-oi-payment-success-title"><?php esc_html_e('Betaling succesvol', 'pontifex-oi'); ?></h2>
            <p class="pontifex-oi-payment-success-message"><?php esc_html_e('Bedankt voor je inschrijving.', 'pontifex-oi'); ?><br>
               <?php esc_html_e('Je betaling is succesvol ontvangen. Een overzicht van je bestelling is naar je e-mailadres gestuurd.', 'pontifex-oi'); ?></p>
        
            <!-- Candidate details -->
            <h3 class="pontifex-oi-section-label"><?php esc_html_e('Gegevens kandidaat', 'pontifex-oi'); ?></h3>
            <div class="pontifex-oi-candidate-details">
                <div class="bestel-item"><strong><?php esc_html_e('Naam en achternaam:', 'pontifex-oi'); ?></strong> <?php echo esc_html($candidate_fullname); ?></div>
                <div class="bestel-item"><strong><?php esc_html_e('Tussenvoegsel (optioneel):', 'pontifex-oi'); ?></strong> <?php echo esc_html($candidate_infix); ?></div>
                <div class="bestel-item"><strong><?php esc_html_e('Achternaam:', 'pontifex-oi'); ?></strong> <?php echo esc_html($candidate_lastname); ?></div>
                <div class="bestel-item"><strong><?php esc_html_e('Geboortedatum:', 'pontifex-oi'); ?></strong> <?php echo esc_html($candidate_birthdate); ?></div>
            </div>
        
            <!-- Bestelgegevens en Betaalgegevens -->
            <div class="pontifex-oi-flex-row">
                <div class="pontifex-oi-column">
                    <h3 class="pontifex-oi-section-label"><?php esc_html_e('Bestelgegevens', 'pontifex-oi'); ?></h3>
                    <div class="pontifex-oi-box">
                        <div class="bestel-item"><strong><?php esc_html_e('Naam:', 'pontifex-oi'); ?></strong> <?php echo esc_html($order_initials . ' ' . $order_infix . ' ' . $order_lastname); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('Postcode en huisnummer:', 'pontifex-oi'); ?></strong> <?php echo esc_html($order_postcode . ' ' . $order_housenumber); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('Adres:', 'pontifex-oi'); ?></strong> <?php echo esc_html($order_street . ', ' . $order_city); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('Telefoonnummer:', 'pontifex-oi'); ?></strong> <?php echo esc_html($order_phone); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('E-mailadres:', 'pontifex-oi'); ?></strong> <?php echo esc_html($order_email); ?></div>
                    </div>
                </div>

                <div class="pontifex-oi-column">
                    <h3 class="pontifex-oi-section-label"><?php esc_html_e('Betaalgegevens', 'pontifex-oi'); ?></h3>
                    <div class="pontifex-oi-box">
                        <div class="bestel-item"><strong><?php esc_html_e('Examen:', 'pontifex-oi'); ?></strong> <?php echo esc_html($exam_label); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('Taal:', 'pontifex-oi'); ?></strong> <?php echo esc_html($language_label); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('Lesmateriaal:', 'pontifex-oi'); ?></strong> <?php echo esc_html($material_label); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('Locatie:', 'pontifex-oi'); ?></strong> <?php echo esc_html($location); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('Datum:', 'pontifex-oi'); ?></strong> <?php echo esc_html($date); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('Tijd:', 'pontifex-oi'); ?></strong> <?php echo esc_html($time); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('Aantal:', 'pontifex-oi'); ?></strong> <?php echo esc_html($amount); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('Prijs:', 'pontifex-oi'); ?></strong> <?php echo esc_html($price); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('BTW (21%):', 'pontifex-oi'); ?></strong> <?php echo esc_html($btw); ?></div>
                        <div class="bestel-item"><strong><?php esc_html_e('Totaal:', 'pontifex-oi'); ?></strong> <?php echo esc_html($total); ?></div>
                    </div>
                </div>
            </div>
        
            <!-- Button to go back to home -->
            <a href="<?php echo esc_url(home_url('/')); ?>" class="pontifex-oi-back-link-inschrijven">
                <?php esc_html_e('Terug naar de homepagina', 'pontifex-oi'); ?>
            </a>
        </div>
        <?php

        // Haal de gegenereerde HTML op (e-mail zal hier niet worden weergegeven)
        $message = ob_get_clean();

        // E-mail verzenden (nu gebeurt dit pas na het genereren van de pagina)
        $to = PaymentHelpers::get_data('order_email'); // Gebruik het e-mailadres van de klant
        $subject = 'Betaling succesvol ontvangen';
        $headers = array('Content-Type: text/html; charset=UTF-8', 'From: Your Company <no-reply@yourcompany.com>');

        // Verstuur de e-mail
        wp_mail($to, $subject, $message, $headers);

        return $message;
    }
}