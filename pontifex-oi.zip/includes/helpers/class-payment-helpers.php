<?php
namespace PontifexOI\Helpers;

class PaymentHelpers
{
    /**
     * Haal veilige, gefilterde waarde op uit $_GET (voor uitzonderingen of debug)
     * Gebruik dit spaarzaam en nooit voor productielogica!
     */
    public static function get_data($key, $default = null)
    {
        return isset($_GET[$key]) ? sanitize_text_field($_GET[$key]) : $default;
    }

    /**
     * Retourneer TRUE als plugin in testmodus staat (en dus test key moet gebruiken)
     */
    public static function is_test_mode()
    {
        // Alleen admin-instelling bepaalt!
        $test = get_option('pontifex_oi_mollie_test_mode', false);
        return ($test === '1' || $test === 1 || $test === true);
    }

    /**
     * Haal altijd de juiste (admin) Mollie API key op (test of live)
     */
    public static function get_mollie_api_key()
    {
        if (self::is_test_mode()) {
            return get_option('pontifex_oi_mollie_test_api_key', '');
        }
        return get_option('pontifex_oi_mollie_live_api_key', '');
    }
}