<?php
namespace PontifexOI\PublicPart;

class PaymentHelpers
{
    /**
     * Haal veilige, gefilterde waarde op uit $_GET (ook voor arrays!)
     * Retourneert altijd alle waarden van het opgegeven key als array (indien aanwezig),
     * anders de enkelvoudige waarde. Geeft $default terug als het veld niet bestaat.
     */
    public static function get_data($key, $default = null)
    {
        if (!isset($_GET[$key])) return $default;
        $val = $_GET[$key];
        if (is_array($val)) {
            // Elk veld van de array schoonmaken
            return array_map('sanitize_text_field', $val);
        }
        // Enkelvoudig veld
        return sanitize_text_field($val);
    }

    /**
     * Retourneer TRUE als plugin in testmodus staat (en dus test key moet gebruiken)
     */
    public static function is_test_mode()
    {
        // Alleen admin-instelling bepaalt!
        $test = get_option('pontifex_oi_mollie_test_mode', false);
        return ($test === '1' || $test === 1 || $test === true);
    }

    /**
     * Haal altijd de juiste (admin) Mollie API key op (test of live)
     */
    public static function get_mollie_api_key()
    {
        if (self::is_test_mode()) {
            return get_option('pontifex_oi_mollie_test_api_key', '');
        }
        return get_option('pontifex_oi_mollie_live_api_key', '');
    }
}