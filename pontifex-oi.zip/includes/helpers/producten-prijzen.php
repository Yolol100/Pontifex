<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Hoofdproducten (examensoorten)
$EXAM_PRODUCTS = [
    'los-examen-vca-basis'   => ['label' => 'VCA Basis',           'prices' => ['nl'=>129,'en'=>129]],  // Aangepast
    'los-examen-vca-vol'     => ['label' => 'VCA Vol',             'prices' => ['nl'=>139,'en'=>139]],  // Aangepast
    'vca-basis-weekend'      => ['label' => 'VCA Basis Cursus Weekend',       'prices' => ['nl'=>245]],
    'vca-vol-weekend'        => ['label' => 'VCA Vol Cursus Weekend',         'prices' => ['nl'=>245]],
    'e-learning-vca-basis'   => ['label' => 'E‑learning VCA Basis',           'prices' => ['nl'=>29,'en'=>49]],
    'e-learning-vca-vol'     => ['label' => 'E‑learning VCA Vol',             'prices' => ['nl'=>39,'en'=>59]],
    'vca-basis-proefexamens' => ['label' => 'VCA Basis Proefexamens',         'prices' => ['nl'=>25]],
    'vca-vol-proefexamens'   => ['label' => 'VCA Vol Proefexamens',           'prices' => ['nl'=>25]],
];

// Lesmateriaal los
$MATERIAL_PRODUCTS = [
    'boek-vca-basis' => ['label' => 'Boek VCA Basis',  'prices' => ['nl'=>36,'en'=>56]],
    'boek-vca-vol'   => ['label' => 'Boek VCA Vol',    'prices' => ['nl'=>42,'en'=>62]],
    'boek-vca-combi' => ['label' => 'Boek VCA Combi',  'prices' => ['nl'=>49,'en'=>69]],
];

// Mapping voor pakketten (dropdown "Lesmateriaal")
$MATERIAL_COMBIS = [
    '1'         => [],
    '2_basis'   => ['boek-vca-basis'],
    '2_vol'     => ['boek-vca-vol'],
    '4_basis'   => ['e-learning-vca-basis'],
    '4_vol'     => ['e-learning-vca-vol'],
    '5_basis'   => ['vca-basis-proefexamens'],
    '5_vol'     => ['vca-vol-proefexamens'],
    '6_basis'   => ['boek-vca-basis','vca-basis-proefexamens'],
    '6_vol'     => ['boek-vca-vol','vca-vol-proefexamens'],
    '7_basis'   => ['e-learning-vca-basis','vca-basis-proefexamens'],
    '7_vol'     => ['e-learning-vca-vol','vca-vol-proefexamens'],
];

/**
 * Geef de prijs terug op basis van keuzes.
 *
 * @param string $exam_type Slug van het examen
 * @param string $language  'nl' of 'en'
 * @param string $material  Pakketcode uit 1,2,4,5,6,7
 * @return float
 */
function get_product_price( $exam_type, $language = 'nl', $material = '' ) {
    global $EXAM_PRODUCTS, $MATERIAL_PRODUCTS, $MATERIAL_COMBIS;

    $total = 0;

    // 1) Examen prijs
    if ( isset( $EXAM_PRODUCTS[ $exam_type ] ) ) {
        $prices     = $EXAM_PRODUCTS[ $exam_type ]['prices'];
        $exam_price = $prices[ $language ] ?? $prices['nl'] ?? 0;
        $total     += $exam_price;
    }

    // 2) Alleen examen als materiaal leeg of '1'
    if ( empty($material) || $material === '1' ) {
        return $total;
    }

    // 3) Bepaal combiKey
    $combiKey = $material;
    if ( in_array($material, ['2','4','5','6','7'], true) ) {
        $suffix   = ( strpos($exam_type, 'vca-vol') !== false ) ? 'vol' : 'basis';
        $combiKey = "{$material}_{$suffix}";
    }

    // 4) Pakketprijzen optellen
    if ( isset($MATERIAL_COMBIS[$combiKey]) ) {
        foreach ($MATERIAL_COMBIS[$combiKey] as $prod) {
            if ( isset($EXAM_PRODUCTS[$prod]) ) {
                $prices     = $EXAM_PRODUCTS[$prod]['prices'];
                $item_price = $prices[$language] ?? $prices['nl'] ?? 0;
            } elseif ( isset($MATERIAL_PRODUCTS[$prod]) ) {
                $prices     = $MATERIAL_PRODUCTS[$prod]['prices'];
                $item_price = $prices[$language] ?? $prices['nl'] ?? 0;
            } else {
                $item_price = 0;
            }
            $total += $item_price;
        }
    }

    return $total;
}

/**
 * Return alle examensoorten.
 * @return array
 */
function get_all_exam_products() {
    global $EXAM_PRODUCTS;
    return $EXAM_PRODUCTS;
}

/**
 * Return alle losse materialen.
 * @return array
 */
function get_all_material_products() {
    global $MATERIAL_PRODUCTS;
    return $MATERIAL_PRODUCTS;
}