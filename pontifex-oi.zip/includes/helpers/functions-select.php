<?php
namespace PontifexOI\Helpers;

function render_select($name, $label, $options, $selected = null, $label_class = '') {
    // (optioneel) zorg hier dat material altijd een "Geen keuze" heeft
    if ($name === 'material') {
        $hasEmpty = false;
        foreach ($options as $o) {
            if ((isset($o['id']) && $o['id'] === '') || $o === '') {
                $hasEmpty = true;
                break;
            }
        }
        if (!$hasEmpty) {
            array_unshift($options, ['id' => '', 'name' => __('Geen keuze','pontifex-oi')]);
        }
    }

    $label_class_attr = $label_class ? ' class="' . esc_attr($label_class) . '"' : '';

    echo '<label' . $label_class_attr . '>';
    echo esc_html($label);
    echo '<select name="' . esc_attr($name) . '" class="pontifex-oi-filter" data-filter="' . esc_attr($name) . '">';
    foreach ($options as $option) {
        $value = isset($option['id']) ? $option['id'] : $option;
        $text  = isset($option['name']) ? $option['name'] : $option;
        $is_selected = ((string)$value === (string)$selected) ? 'selected' : '';
        echo '<option value="' . esc_attr($value) . '" ' . $is_selected . '>' . esc_html($text) . '</option>';
    }
    echo '</select>';
    echo '</label>';
}