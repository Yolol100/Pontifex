<?php
namespace PontifexOI\Api;

// Placeholder voor API controller.
class ApiController {
    // TODO: API-calls, authenticatie, handlers
}