<?php
namespace PontifexOI\Api;

use Exception;

/**
 * Centrale SOAP-client voor communicatie met de Pontifex Open Inschrijvingen webservice.
 */
class SoapClient {
    /**
     * @var \SoapClient|null
     */
    private $client = null;

    /**
     * @var string
     */
    private $endpoint = 'https://staging.webservice.pontifexcertificatie.nl/service.php';

    /**
     * @var array
     */
    private $options = [
        'trace'      => 1,
        'exceptions' => 1,
        'cache_wsdl' => WSDL_CACHE_BOTH,
    ];

    public function __construct() {
        if (class_exists('\SoapClient')) {
            try {
                $this->client = new \SoapClient(null, array_merge($this->options, [
                    'location' => $this->endpoint,
                    'uri'      => 'http://pontifexcertificatie.nl/',
                    'style'    => SOAP_DOCUMENT,
                    'use'      => SOAP_LITERAL,
                ]));
            } catch (Exception $e) {
                error_log('[PontifexOI] SOAP-client error: ' . $e->getMessage());
                $this->client = null;
            }
        }
    }

    /* -------------------------- STATIC/DUMMY DATA METHODS -------------------------- */

    public function getExamTypes($filters = []) {
        $exam_types = [
            ['id' => 'b-vca',     'name' => 'B-VCA'],
            ['id' => 'vol-vca',   'name' => 'VOL-VCA'],
            ['id' => 'vca-basis', 'name' => 'VCA Basis'],
        ];

        if (!empty($filters['province']) && $filters['province'] === 'zh') {
            return [
                ['id' => 'vol-vca', 'name' => 'VOL-VCA'],
            ];
        }
        return $exam_types;
    }

    public function getLanguages($filters = []) {
        $languages = [
            'b-vca' => [
                ['id' => 'nl', 'name' => 'Nederlands'],
                ['id' => 'en', 'name' => 'Engels'],
                ['id' => 'de', 'name' => 'Duits'],
            ],
            'vol-vca' => [
                ['id' => 'nl', 'name' => 'Nederlands'],
                ['id' => 'en', 'name' => 'Engels'],
            ],
            'vca-basis' => [
                ['id' => 'nl', 'name' => 'Nederlands'],
            ],
        ];

        if (!empty($filters['exam_type']) && isset($languages[$filters['exam_type']])) {
            return $languages[$filters['exam_type']];
        }

        // fallback alle unieke talen
        $all = [];
        foreach ($languages as $arr) {
            foreach ($arr as $lang) {
                $all[$lang['id']] = $lang;
            }
        }
        return array_values($all);
    }

    public function getMaterials($filters = []) {
        // Uit tweede versie: Altijd een "Geen keuze"-optie vooraan
        if (!empty($filters['exam_type']) && $filters['exam_type'] === 'vol-vca') {
            return [
                ['id' => '',        'name' => 'Geen keuze'],
                ['id' => 'examen',  'name' => 'Los examen'],
                ['id' => 'boek',    'name' => 'Met boek'],
            ];
        }
        // Uit tweede versie: 'Geen keuze' optie toegevoegd voor overige exam_types
        return [
            ['id' => '',         'name' => 'Geen keuze'],
            ['id' => 'examen',   'name' => 'Los examen'],
            ['id' => 'boek',     'name' => 'Met boek'],
            ['id' => 'digiboek', 'name' => 'Met digiboek'],
        ];
    }

    public function getMonths($filters = []) {
        return [
            ['id' => '',        'name' => 'Toon alles'],
            ['id' => '2025-07', 'name' => 'Juli 2025'],
            ['id' => '2025-08', 'name' => 'Augustus 2025'],
        ];
    }

    public function getProvinces($filters = []) {
        $provinces = [
            ['id' => '',   'name' => 'Toon alles'],
            ['id' => 'zh', 'name' => 'Zuid-Holland'],
            ['id' => 'ge', 'name' => 'Gelderland'],
            ['id' => 'nb', 'name' => 'Noord-Brabant'],
            ['id' => 'ov', 'name' => 'Overijssel'],
        ];

        if (!empty($filters['exam_type']) && $filters['exam_type'] === 'b-vca') {
            return [
                ['id' => 'zh', 'name' => 'Zuid-Holland'],
                ['id' => 'ge', 'name' => 'Gelderland'],
            ];
        }
        return $provinces;
    }

    public function getLocations($filters = []) {
        $all_locations = [
            'zh' => [
                ['id' => 'barendrecht', 'name' => 'Barendrecht'],
                ['id' => 'breda',       'name' => 'Breda'],
            ],
            'ge' => [
                ['id' => 'groessen',    'name' => 'Groessen'],
            ],
            'ov' => [
                ['id' => 'hengelo',     'name' => 'Hengelo'],
            ],
            'nb' => [
                ['id' => 'breda',       'name' => 'Breda'],
            ]
        ];

        $locations = [];
        if (!empty($filters['province']) && isset($all_locations[$filters['province']])) {
            $locations = $all_locations[$filters['province']];
        } else {
            $unique = [];
            foreach ($all_locations as $locs) {
                foreach ($locs as $loc) {
                    $unique[$loc['id']] = $loc;
                }
            }
            $locations = array_values($unique);
        }

        array_unshift($locations, ['id' => '', 'name' => 'Toon alles']);
        return $locations;
    }

    public function getTimeslots($filters = []) {
        if (!empty($filters['location']) && $filters['location'] === 'barendrecht') {
            return [
                ['id' => '',        'name' => 'Toon alles'],
                ['id' => 'ochtend', 'name' => 'Ochtend'],
                ['id' => 'avond',   'name' => 'Avond'],
            ];
        }
        return [
            ['id' => '',        'name' => 'Toon alles'],
            ['id' => 'ochtend', 'name' => 'Ochtend'],
            ['id' => 'middag',  'name' => 'Middag'],
            ['id' => 'avond',   'name' => 'Avond'],
        ];
    }

    /**
     * Planningdata ophalen, gefilterd.
     * Belangrijk: we normaliseren filters (afkorting -> volledige naam, slug -> naam).
     */
    public function getPlanning($filters = []) {
        // Dummy dataset
        $data = [
            [
                'date'       => '24-07-2025 (donderdag)',
                'time'       => '10:00',
                'location'   => 'Barendrecht',
                'province'   => 'Zuid-Holland',
                'spots'      => '15 plaatsen',
                'price'      => '€ 66.00',
                'signup_url' => '#'
            ],
            [
                'date'       => '24-07-2025 (donderdag)',
                'time'       => '16:00',
                'location'   => 'Groessen',
                'province'   => 'Gelderland',
                'spots'      => '10 plaatsen',
                'price'      => '€ 66.00',
                'signup_url' => '#'
            ],
            [
                'date'       => '24-07-2025 (donderdag)',
                'time'       => '19:00',
                'location'   => 'Barendrecht',
                'province'   => 'Zuid-Holland',
                'spots'      => '19 plaatsen',
                'price'      => '€ 66.00',
                'signup_url' => '#'
            ],
            [
                'date'       => '24-07-2025 (donderdag)',
                'time'       => '19:00',
                'location'   => 'Hengelo',
                'province'   => 'Overijssel',
                'spots'      => 'VOL',
                'price'      => '€ 66.00',
                'signup_url' => '#'
            ],
            // ...meer rows...
        ];

        // 1. Normaliseer filters
        $filters = $this->normalizeFilters($filters);

        // 2. Filteren
        $filtered = array_filter($data, function ($row) use ($filters) {

            // province
            if (!empty($filters['province'])) {
                if (strcasecmp($row['province'] ?? '', $filters['province']) !== 0) {
                    return false;
                }
            }

            // location
            if (!empty($filters['location'])) {
                if (strcasecmp($row['location'] ?? '', $filters['location']) !== 0) {
                    return false;
                }
            }

            // timeslot (bepaald op basis van tijd)
            if (!empty($filters['timeslot'])) {
                $slot = $this->detectTimeslot($row['time'] ?? '');
                if (strcasecmp($slot, $filters['timeslot']) !== 0) {
                    return false;
                }
            }

            // month filter? (optioneel)
            if (!empty($filters['month'])) {
                // voorbeeld: '2025-07' vergelijken met datumstring
                // haal maand-jaar uit row['date'] (dd-mm-YYYY)
                if (preg_match('~(\d{2})-(\d{2})-(\d{4})~', $row['date'] ?? '', $m)) {
                    $rowMonth = $m[3] . '-' . $m[2]; // YYYY-MM
                    if ($rowMonth !== $filters['month']) {
                        return false;
                    }
                }
            }

            return true;
        });

        return array_values($filtered);
    }

    /* -------------------------- HELPERS -------------------------- */

    /**
     * Normaliseert inkomende filterwaarden naar de waarden die in de dataset staan.
     */
    private function normalizeFilters(array $filters): array {
        // Provincie afkortingen -> volledige naam
        $provMap = [
            'zh' => 'Zuid-Holland',
            'ge' => 'Gelderland',
            'nb' => 'Noord-Brabant',
            'ov' => 'Overijssel',
        ];
        if (!empty($filters['province'])) {
            $key = strtolower($filters['province']);
            if (isset($provMap[$key])) {
                $filters['province'] = $provMap[$key];
            }
        }

        // Locatie slugs -> naam (title case)
        $locMap = [
            'barendrecht' => 'Barendrecht',
            'breda'       => 'Breda',
            'groessen'    => 'Groessen',
            'hengelo'     => 'Hengelo',
        ];
        if (!empty($filters['location'])) {
            $lkey = strtolower($filters['location']);
            if (isset($locMap[$lkey])) {
                $filters['location'] = $locMap[$lkey];
            }
        }

        // timeslot mag gewoon 'ochtend/middag/avond' blijven
        // maar niets te mappen hier tenzij je andere keys gebruikt

        return $filters;
    }

    /**
     * Bepaal timeslot (ochtend/middag/avond) uit een tijd string "HH:MM".
     */
    private function detectTimeslot($time): string {
        if (!preg_match('~^(\d{1,2})~', $time, $m)) {
            return '';
        }
        $h = (int) $m[1];
        if ($h < 12) return 'ochtend';
        if ($h < 18) return 'middag';
        return 'avond';
    }

    /* -------------------------- (OPTIONEEL) LIVE SOAP CALLS -------------------------- */

    private function callSoap($method, $params = []) {
        if (!$this->client) {
            return false;
        }
        try {
            $response = $this->client->__soapCall($method, [$params]);
            return $this->normalizeResponse($response);
        } catch (Exception $e) {
            error_log('[PontifexOI] SOAP error (' . $method . '): ' . $e->getMessage());
            return false;
        }
    }

    private function normalizeResponse($response) {
        if (is_object($response)) {
            $response = json_decode(json_encode($response), true);
        }
        return $response;
    }
}