<?php
namespace PontifexOI\Admin;

class Admin {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
    }

    public function enqueue_admin_assets($hook) {
        if (
            $hook === 'pontifex_page_pontifex_oi_mollie' ||
            $hook === 'pontifex_page_pontifex_oi_soap'
        ) {
            wp_enqueue_style(
                'pontifex-oi-admin',
                PONTIFEX_OI_URL . 'assets/css/pontifex-oi-admin.css',
                [],
                PONTIFEX_OI_VERSION
            );
            wp_enqueue_script(
                'pontifex-oi-admin',
                PONTIFEX_OI_URL . 'assets/js/pontifex-oi-admin.js',
                ['jquery'],
                PONTIFEX_OI_VERSION,
                true
            );
        }
    }

    public function add_menu() {
        // Hoofdmenu: Pontifex (niet klikbaar)
        add_menu_page(
            'Pontifex',
            'Pontifex',
            'manage_options',
            'pontifex_oi_main',
            '', // geen callback!
            'dashicons-awards',
            60
        );
    
        // Submenu Mollie
        add_submenu_page(
            'pontifex_oi_main',
            'Mollie instellingen',
            'Mollie',
            'manage_options',
            'pontifex_oi_mollie',
            [$this, 'settings_page']
        );
    
        // Submenu Soap
        add_submenu_page(
            'pontifex_oi_main',
            'Soap instellingen',
            'Soap',
            'manage_options',
            'pontifex_oi_soap',
            [$this, 'soap_settings_page']
        );
    
        // Verwijder het automatisch toegevoegde eerste submenu-item (het dubbele Pontifex item)
        add_action('admin_head', function() {
            remove_submenu_page('pontifex_oi_main', 'pontifex_oi_main');
        });
    }

    public function register_settings() {
        // Mollie instellingen
        register_setting('pontifex_oi_mollie_group', 'pontifex_oi_mollie_live_api_key');
        register_setting('pontifex_oi_mollie_group', 'pontifex_oi_mollie_test_api_key');
        register_setting('pontifex_oi_mollie_group', 'pontifex_oi_mollie_test_mode', [
            'type'    => 'boolean',
            'default' => false,
        ]);

        // Soap instellingen
        register_setting('pontifex_oi_soap_group', 'pontifex_oi_soap_url');
        register_setting('pontifex_oi_soap_group', 'pontifex_oi_soap_user_id');
        register_setting('pontifex_oi_soap_group', 'pontifex_oi_soap_company_id');
        register_setting('pontifex_oi_soap_group', 'pontifex_oi_soap_hash');
    }

    public function settings_page() {
        $live_key   = esc_attr(get_option('pontifex_oi_mollie_live_api_key', ''));
        $test_key   = esc_attr(get_option('pontifex_oi_mollie_test_api_key', ''));
        $test_mode  = get_option('pontifex_oi_mollie_test_mode') ? 'checked' : '';
        ?>
        <div class="pontifex-admin-wrap">
            <div class="pontifex-admin-card">
                <?php
                if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
                    echo '<div id="message" class="updated notice notice-success is-dismissible" style="margin: 0 0 1rem 0 !Important; width:85%;"><p>Instellingen zijn opgeslagen.</p></div>';
                }
                ?>
                <form method="post" action="options.php" autocomplete="off">
                    <?php settings_fields('pontifex_oi_mollie_group'); ?>

                    <div class="pontifex-admin-row">
                        <label for="pontifex_oi_mollie_live_api_key" class="pontifex-admin-label">Live API Key</label>
                        <div class="pontifex-admin-desc">Voer hier je live Mollie API key in (begin meestal met <code>live_</code>).</div>
                        <input type="text" id="pontifex_oi_mollie_live_api_key" name="pontifex_oi_mollie_live_api_key" class="pontifex-admin-input" value="<?php echo $live_key; ?>" autocomplete="off" />
                    </div>

                    <div class="pontifex-admin-row">
                        <label for="pontifex_oi_mollie_test_api_key" class="pontifex-admin-label">Test API Key</label>
                        <div class="pontifex-admin-desc">Voer hier je test Mollie API key in (begin meestal met <code>test_</code>).</div>
                        <input type="text" id="pontifex_oi_mollie_test_api_key" name="pontifex_oi_mollie_test_api_key" class="pontifex-admin-input" value="<?php echo $test_key; ?>" autocomplete="off" />
                    </div>

                    <div class="pontifex-admin-row pontifex-admin-toggle-row">
                        <label for="pontifex_oi_mollie_test_mode" class="pontifex-admin-label" style="margin-bottom:0;">Testmodus</label>
                        <label class="pontifex-toggle-switch<?php echo $test_mode ? ' checked' : ''; ?>">
                            <input type="checkbox" id="pontifex_oi_mollie_test_mode" name="pontifex_oi_mollie_test_mode" value="1" style="display:none;" <?php echo $test_mode; ?>>
                            <span class="pontifex-toggle-knob"></span>
                        </label>
                        <span class="pontifex-toggle-label">Testmodus <?php echo $test_mode ? 'ingeschakeld' : 'uitgeschakeld'; ?></span>
                    </div>

                    <button type="submit" class="pontifex-admin-submit">Opslaan</button>
                </form>
            </div>
        </div>
        <?php
    }

    public function soap_settings_page() {
        include_once PONTIFEX_OI_PATH . 'includes/admin/page-soap-settings.php';
    }
}

// ===== AJAX HANDLER BUITEN DE CLASS =====
add_action('wp_ajax_pontifex_oi_fetch_soap_data', function() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Geen toegang.']);
    }

    try {
        $soapClient = new \PontifexOI\Api\SoapClient();
        $soapClient->fetchAndStorePlanning();
        wp_send_json_success(['message' => 'Gegevens succesvol opgehaald en opgeslagen.']);
    } catch (\Exception $e) {
        wp_send_json_error(['message' => $e->getMessage()]);
    }
});