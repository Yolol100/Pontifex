<?php
// Geen hardcoded prijzen of producten meer. Alles via JS vullen!
?>

<!-- Stap 2: Bestellen & Inschrijven -->
<div class="pontifex-oi-stepper" role="heading" aria-level="2" tabindex="0">
    <?php esc_html_e('Stap 2: Bestellen & Inschrijven', 'pontifex-oi'); ?>
</div>

<section class="pontifex-oi-section" id="step-2">

    <!-- Titel + terug -->
    <div class="pontifex-oi-title-row">
        <h2 class="pontifex-oi-section-label">
            <?php esc_html_e('Gegevens kandidaat', 'pontifex-oi'); ?>
        </h2>
        <span class="pontifex-oi-back-link" tabindex="0">
            <?php esc_html_e('Terug naar planning', 'pontifex-oi'); ?>
        </span>
    </div>

    <form class="pontifex-oi-candidate-form" autocomplete="off">

        <!-- Kandidaten -->
        <div class="pontifex-oi-candidates-list">
            <div class="pontifex-oi-candidate-row">
                <div>
                    <label for="candidate_fullname_1"><?php esc_html_e('Naam en achternaam', 'pontifex-oi'); ?> <span class="required">*</span></label>
                    <input type="text" id="candidate_fullname_1" name="candidate_fullname[]" required placeholder="<?php esc_attr_e('Bijv. Jan Jansen', 'pontifex-oi'); ?>">
                </div>
                <div>
                    <input type="text" placeholder="<?php esc_attr_e('Tussenvoegsel (optioneel)', 'pontifex-oi'); ?>" name="candidate_infix[]">
                </div>
                <div>
                    <input type="text" placeholder="<?php esc_attr_e('Achternaam', 'pontifex-oi'); ?>" name="candidate_lastname[]" required>
                </div>
                <div class="pontifex-oi-candidate-birthdate-wrapper" style="position:relative; min-width:180px;">
                    <label for="candidate_birthdate_1"><?php esc_html_e('Geboortedatum', 'pontifex-oi'); ?> <span class="required">*</span></label>
                    <input type="date" id="candidate_birthdate_1" name="candidate_birthdate[]" required placeholder="<?php esc_attr_e('jjjj-mm-dd', 'pontifex-oi'); ?>">
                    <button type="button" class="pontifex-oi-remove-candidate" title="<?php esc_attr_e('Kandidaat verwijderen', 'pontifex-oi'); ?>" style="display:none;">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Kandidaat toevoegen -->
        <div class="pontifex-oi-candidate-addrow">
            <button type="button" class="pontifex-oi-add-candidate" tabindex="0">
                <?php esc_html_e('Kandidaat toevoegen', 'pontifex-oi'); ?>
            </button>
        </div>

        <!-- Besteller- en bestelgegevens -->
        <div class="pontifex-oi-flex-row">
            <!-- Links: Bestelgegevens -->
            <div class="pontifex-oi-order-form">
                <h2 class="pontifex-oi-section-label"><?php esc_html_e('Bestelgegevens', 'pontifex-oi'); ?></h2>

                <div class="pontifex-oi-row-group">
                    <label for="order_initials">Naam <span class="required">*</span></label>
                    <div class="pontifex-oi-name-row">
                        <input type="text" id="order_initials" name="order_initials" required placeholder="<?php esc_attr_e('Voorletters', 'pontifex-oi'); ?>">
                        <input type="text" name="order_infix" placeholder="<?php esc_attr_e('Tussenvoegsel (optioneel)', 'pontifex-oi'); ?>">
                        <input type="text" name="order_lastname" required placeholder="<?php esc_attr_e('Achternaam', 'pontifex-oi'); ?>">
                    </div>
                </div>
                <div class="pontifex-oi-row-group">
                    <label for="order_postcode">Postcode en huisnummer <span class="required">*</span></label>
                    <div class="pontifex-oi-adres-row">
                        <input type="text" id="order_postcode" name="order_postcode" required placeholder="<?php esc_attr_e('Postcode', 'pontifex-oi'); ?>">
                        <input type="text" name="order_housenumber" required placeholder="<?php esc_attr_e('Huisnummer', 'pontifex-oi'); ?>">
                    </div>
                </div>
                <div class="pontifex-oi-row-group">
                    <label for="order_street">Adres <span class="required">*</span></label>
                    <div class="pontifex-oi-adres-row">
                        <input type="text" id="order_street" name="order_street" required placeholder="<?php esc_attr_e('Straat', 'pontifex-oi'); ?>">
                        <input type="text" name="order_city" required placeholder="<?php esc_attr_e('Plaats', 'pontifex-oi'); ?>">
                    </div>
                </div>
                <div class="pontifex-oi-row-group">
                    <div class="pontifex-oi-contact-row-labels">
                        <label for="order_phone">Telefoonnummer <span class="required">*</span></label>
                        <label for="order_email">E-mailadres <span class="required">*</span></label>
                    </div>
                    <div class="pontifex-oi-contact-row">
                        <input type="text" id="order_phone" name="order_phone" required placeholder="<?php esc_attr_e('Telefoonnummer', 'pontifex-oi'); ?>">
                        <input type="email" id="order_email" name="order_email" required placeholder="<?php esc_attr_e('E-mailadres', 'pontifex-oi'); ?>">
                    </div>
                </div>
                <div class="pontifex-oi-row-group">
                    <label for="order_company">Bedrijfsnaam</label>
                    <input type="text" id="order_company" name="order_company" placeholder="<?php esc_attr_e('Bedrijfsnaam', 'pontifex-oi'); ?>">
                </div>
                <div class="pontifex-oi-row-group">
                    <label for="order_vat">BTW-nummer</label>
                    <input type="text" id="order_vat" name="order_vat" placeholder="<?php esc_attr_e('BTW-nummer', 'pontifex-oi'); ?>">
                </div>
            </div>

            <!-- Rechts: Betaaloverzicht (JS vult deze in) -->
            <div class="pontifex-oi-order-summary">
                <!-- JavaScript zet hier het betaaloverzicht, akkoord checkbox en button -->
            </div>
        </div><!-- /flex-row -->

        <!-- Toevoeging voor betaling -->
        <input type="hidden" id="payment_amount" name="payment_amount" value="<?php echo $totaal; ?>">

    </form>
</section>