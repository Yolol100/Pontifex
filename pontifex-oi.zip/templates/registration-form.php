<?php
// Verkrijg de gegevens van Stap 1 via de URL
$exam_type = isset($_GET['exam_type']) ? sanitize_text_field($_GET['exam_type']) : '';
$language  = isset($_GET['language']) ? sanitize_text_field($_GET['language']) : '';
$material  = isset($_GET['material']) ? sanitize_text_field($_GET['material']) : '';
$date      = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : '';
$time      = isset($_GET['time']) ? sanitize_text_field($_GET['time']) : '';
$location  = isset($_GET['location']) ? sanitize_text_field($_GET['location']) : '';
$province  = isset($_GET['province']) ? sanitize_text_field($_GET['province']) : '';
$spots     = isset($_GET['spots']) ? sanitize_text_field($_GET['spots']) : '';
$price     = isset($_GET['price']) ? sanitize_text_field($_GET['price']) : '';

// Vertaal codes naar labels
$exam_type_labels = [
    'los-examen-vca-basis'  => 'VCA Basis',
    'los-examen-vca-vol'    => 'VCA Vol',
    'vca-basis-weekend'     => 'VCA Basis Cursus Weekend',
    'vca-vol-weekend'       => 'VCA Vol Cursus Weekend',
    ''                      => '-'
];
$language_labels = [
    'nl' => 'Nederlands',
    'en' => 'Engels',
    ''   => '-'
];
$material_labels = [
    '1' => 'Los examen',
    '2' => 'Examen + boek',
    '4' => 'Examen + e-learning',
    '5' => 'Examen + proefexamens',
    '6' => 'Examen + boek + proefexamens',
    '7' => 'Examen + e-learning + proefexamens',
    ''  => 'Geen keuze'
];
?>

<!-- Stap 2: Bestellen & Inschrijven -->
<div class="pontifex-oi-stepper" role="heading" aria-level="2" tabindex="0">
    <?php esc_html_e('Stap 2: Bestellen & Inschrijven', 'pontifex-oi'); ?>
</div>

<section class="pontifex-oi-section" id="step-2">

    <!-- Titel + terug -->
    <div class="pontifex-oi-title-row">
        <h2 class="pontifex-oi-section-label">
            <?php esc_html_e('Gegevens kandidaat', 'pontifex-oi'); ?>
        </h2>
        <!-- Link naar planning pagina aangepast -->
        <a href="/cursus-zoeken/" class="pontifex-oi-back-link" tabindex="0">
            <?php esc_html_e('Terug naar planning', 'pontifex-oi'); ?>
        </a>
    </div>

    <!-- Formulier met novalidate, zodat browservalidatie niet direct rode randen toont -->
    <form class="pontifex-oi-candidate-form" autocomplete="off" novalidate>

        <!-- Kandidaten -->
        <div class="pontifex-oi-candidates-list">
            <div class="pontifex-oi-candidate-row">
                <div>
                    <label for="candidate_fullname_1"><?php esc_html_e('Naam en achternaam', 'pontifex-oi'); ?> <span class="required">*</span></label>
                    <input type="text" id="candidate_fullname_1" name="candidate_fullname[]" required placeholder="<?php esc_attr_e('Bijv. Jan Jansen', 'pontifex-oi'); ?>">
                </div>
                <div>
                    <input type="text" placeholder="<?php esc_attr_e('Tussenvoegsel (optioneel)', 'pontifex-oi'); ?>" name="candidate_infix[]">
                </div>
                <div>
                    <input type="text" placeholder="<?php esc_attr_e('Achternaam', 'pontifex-oi'); ?>" name="candidate_lastname[]" required>
                </div>
                <div class="pontifex-oi-candidate-birthdate-wrapper" style="position:relative; min-width:180px;">
                    <label for="candidate_birthdate_1"><?php esc_html_e('Geboortedatum', 'pontifex-oi'); ?> <span class="required">*</span></label>
                    <input type="date" id="candidate_birthdate_1" name="candidate_birthdate[]" required placeholder="<?php esc_attr_e('jjjj-mm-dd', 'pontifex-oi'); ?>">
                    <button type="button" class="pontifex-oi-remove-candidate" title="<?php esc_attr_e('Kandidaat verwijderen', 'pontifex-oi'); ?>" style="display:none;">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Kandidaat toevoegen -->
        <div class="pontifex-oi-candidate-addrow">
            <button type="button" class="pontifex-oi-add-candidate" tabindex="0">
                <?php esc_html_e('Kandidaat toevoegen', 'pontifex-oi'); ?>
            </button>
        </div>

        <!-- Besteller- en bestelgegevens -->
        <div class="pontifex-oi-flex-row">
            <!-- Links: Bestelgegevens -->
            <div class="pontifex-oi-order-form">
                <h2 class="pontifex-oi-section-label"><?php esc_html_e('Bestelgegevens', 'pontifex-oi'); ?></h2>

                <div class="pontifex-oi-row-group">
                    <label for="order_initials">Naam <span class="required">*</span></label>
                    <div class="pontifex-oi-name-row">
                        <input type="text" id="order_initials" name="order_initials" required placeholder="<?php esc_attr_e('Voorletters', 'pontifex-oi'); ?>">
                        <input type="text" name="order_infix" placeholder="<?php esc_attr_e('Tussenvoegsel (optioneel)', 'pontifex-oi'); ?>">
                        <input type="text" name="order_lastname" required placeholder="<?php esc_attr_e('Achternaam', 'pontifex-oi'); ?>">
                    </div>
                </div>
                <div class="pontifex-oi-row-group">
                    <label for="order_postcode">Postcode en huisnummer <span class="required">*</span></label>
                    <div class="pontifex-oi-adres-row">
                        <input type="text" id="order_postcode" name="order_postcode" required placeholder="<?php esc_attr_e('Postcode', 'pontifex-oi'); ?>">
                        <input type="text" name="order_housenumber" required placeholder="<?php esc_attr_e('Huisnummer', 'pontifex-oi'); ?>">
                    </div>
                </div>
                <div class="pontifex-oi-row-group">
                    <label for="order_street">Adres <span class="required">*</span></label>
                    <div class="pontifex-oi-adres-row">
                        <input type="text" id="order_street" name="order_street" required placeholder="<?php esc_attr_e('Straat', 'pontifex-oi'); ?>">
                        <input type="text" name="order_city" required placeholder="<?php esc_attr_e('Plaats', 'pontifex-oi'); ?>">
                    </div>
                </div>
                <div class="pontifex-oi-row-group">
                    <div class="pontifex-oi-contact-row-labels">
                        <label for="order_phone">Telefoonnummer <span class="required">*</span></label>
                        <label for="order_email">E-mailadres <span class="required">*</span></label>
                    </div>
                    <div class="pontifex-oi-contact-row">
                        <input type="text" id="order_phone" name="order_phone" required placeholder="<?php esc_attr_e('Telefoonnummer', 'pontifex-oi'); ?>">
                        <input type="email" id="order_email" name="order_email" required placeholder="<?php esc_attr_e('E-mailadres', 'pontifex-oi'); ?>">
                    </div>
                </div>
                <div class="pontifex-oi-row-group">
                    <label for="order_company">Bedrijfsnaam</label>
                    <input type="text" id="order_company" name="order_company" placeholder="<?php esc_attr_e('Bedrijfsnaam', 'pontifex-oi'); ?>">
                </div>
                <div class="pontifex-oi-row-group">
                    <label for="order_vat">BTW-nummer</label>
                    <input type="text" id="order_vat" name="order_vat" placeholder="<?php esc_attr_e('BTW-nummer', 'pontifex-oi'); ?>">
                </div>
            </div>

            <!-- Rechts: Betaaloverzicht -->
            <div class="pontifex-oi-order-summary">
                <h3 class="pontifex-oi-section-label"><?php esc_html_e('Gegevens van uw bestelling', 'pontifex-oi'); ?></h3>
                <div class="besteloverzicht-stap2">
                    <div class="bo-item"><strong><?php esc_html_e('Examen', 'pontifex-oi'); ?></strong><span><?php echo esc_html($exam_type_labels[$exam_type] ?? '-'); ?></span></div>
                    <div class="bo-item"><strong><?php esc_html_e('Taal', 'pontifex-oi'); ?></strong><span><?php echo esc_html($language_labels[$language] ?? '-'); ?></span></div>
                    <?php if (!empty($material) && $material !== '' && ($material_labels[$material] ?? '') !== 'Geen keuze') : ?>
                        <div class="bo-item"><strong><?php esc_html_e('Lesmateriaal', 'pontifex-oi'); ?></strong><span><?php echo esc_html($material_labels[$material] ?? '-'); ?></span></div>
                    <?php endif; ?>
                    <div class="bo-item"><strong><?php esc_html_e('Datum', 'pontifex-oi'); ?></strong><span><?php echo esc_html($date ?: '-'); ?></span></div>
                    <div class="bo-item"><strong><?php esc_html_e('Tijd', 'pontifex-oi'); ?></strong><span><?php echo esc_html($time ?: '-'); ?></span></div>
                    <div class="bo-item"><strong><?php esc_html_e('Locatie', 'pontifex-oi'); ?></strong><span><?php echo esc_html($location ?: '-'); ?></span></div>
                    <div class="bo-item"><strong><?php esc_html_e('Provincie', 'pontifex-oi'); ?></strong><span><?php echo esc_html($province ?: '-'); ?></span></div>
                    <div class="bo-item"><strong><?php esc_html_e('Aantal kandidaten', 'pontifex-oi'); ?></strong><span id="candidate-count">1</span></div>
                    <div class="bo-item totaal"><strong><?php esc_html_e('Prijs totaal', 'pontifex-oi'); ?></strong><span id="total-price"><?php echo esc_html($price ?: '-'); ?></span></div>
                </div>
                <!-- BUTTON: Bestelling plaatsen -->
                <button type="button" class="pontifex-oi-submit-order"><?php esc_html_e('Bestelling plaatsen', 'pontifex-oi'); ?></button>
            </div>
        </div><!-- /flex-row -->

        <!-- Verborgen veld voor totaalbedrag -->
        <input type="hidden" id="payment_amount" name="payment_amount" value="<?php echo esc_attr($price); ?>">

    </form>
</section>