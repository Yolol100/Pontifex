<?php
use function PontifexOI\Helpers\render_select;
?>

<!-- Stepper buiten de sectie -->
<div class="pontifex-oi-stepper" role="heading" aria-level="2" tabindex="0">
    <?php esc_html_e('Stap 1: Examen & planning', 'pontifex-oi'); ?>
</div>

<section class="pontifex-oi-section">

    <!-- Stap 1 container -->
    <div id="step-1" class="active">
        <div class="pontifex-oi-bestellen">
            <form class="pontifex-oi-filters" method="get" action="" aria-label="<?php esc_attr_e('Filter examens en planning', 'pontifex-oi'); ?>">

                <div class="pontifex-oi-filter-row">
                    <div class="pontifex-oi-filter-group">
                        <h2 class="select-exam-label"><?php esc_html_e('Selecteer een examen', 'pontifex-oi'); ?></h2>
                        <div class="pontifex-oi-select-row">
                            <?php
                            render_select('exam_type', __('Selecteer een examensoort', 'pontifex-oi'), $args['exam_types'], $args['filters']['exam_type']);
                            render_select('language', __('Selecteer een taal', 'pontifex-oi'), $args['languages'], $args['filters']['language']);
                            ?>
                        </div>
                    </div>
                    <div class="pontifex-oi-filter-group">
                        <h2 class="select-material-label"><?php esc_html_e('Kies lesmateriaal (optioneel)', 'pontifex-oi'); ?></h2>
                        <div class="pontifex-oi-select-row">
                            <?php
                            // Zorg dat "Geen keuze" aanwezig is
                            $matOpts = $args['materials'];
                            if (!isset($matOpts[0]) || (isset($matOpts[0]['id']) && $matOpts[0]['id'] !== '')) {
                                array_unshift($matOpts, ['id' => '', 'name' => __('Geen keuze','pontifex-oi')]);
                            }
                            render_select('material', __('Lesmateriaal', 'pontifex-oi'), $matOpts, $args['filters']['material']);
                            ?>
                        </div>
                    </div>
                </div>

                <h2 class="pontifex-oi-filter-date-title"><?php esc_html_e('Kies een datum en locatie', 'pontifex-oi'); ?></h2>
                <div class="pontifex-oi-filter-row -no-gap" style="margin-bottom:0.8rem; align-items: flex-end;">
                    <div class="pontifex-oi-filter-group" style="flex: 1 1 22%;">
                        <label for="month-select"><?php esc_html_e('Selecteer een maand', 'pontifex-oi'); ?></label>
                        <?php render_select('month', '', $args['months'], $args['filters']['month']); ?>
                    </div>
                    <div class="pontifex-oi-filter-group" style="flex: 1 1 22%;">
                        <label for="province-select"><?php esc_html_e('Selecteer een provincie', 'pontifex-oi'); ?></label>
                        <?php render_select('province', '', $args['provinces'], $args['filters']['province']); ?>
                    </div>
                    <div class="pontifex-oi-filter-group" style="flex: 1 1 22%;">
                        <label for="location-select"><?php esc_html_e('Selecteer een locatie', 'pontifex-oi'); ?></label>
                        <?php render_select('location', '', $args['locations'], $args['filters']['location']); ?>
                    </div>
                    <div class="pontifex-oi-filter-group" style="flex: 1 1 22%;">
                        <label for="timeslot-select"><?php esc_html_e('Ochtend, middag of avond', 'pontifex-oi'); ?></label>
                        <?php render_select('timeslot', '', $args['timeslots'], $args['filters']['timeslot']); ?>
                    </div>
                </div>
            </form>

            <table class="pontifex-oi-table" aria-describedby="pontifex-oi-table-caption" role="table">
                <thead>
                    <tr>
                        <th scope="col"><?php esc_html_e('Datum', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Tijd', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Locatie', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Provincie', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Plekken vrij', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Prijs', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Aanmelden', 'pontifex-oi'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($args['planning'])): foreach ($args['planning'] as $row): ?>
                        <tr>
                            <td><?php echo esc_html($row['date']); ?></td>
                            <td><?php echo esc_html($row['time']); ?></td>
                            <td><?php echo esc_html($row['location']); ?></td>
                            <td><?php echo esc_html($row['province']); ?></td>
                            <td><?php echo esc_html($row['spots']); ?></td>
                            <td><?php echo esc_html($row['price']); ?></td>
                            <td>
                                <?php if (strtoupper($row['spots']) !== 'VOL'): ?>
                                    <a href="#"
                                       class="pontifex-oi-aanmelden"
                                       data-exam="<?php echo esc_attr($row['exam'] ?? $args['filters']['exam_type'] ?? ''); ?>"
                                       data-language="<?php echo esc_attr($row['language'] ?? $args['filters']['language'] ?? ''); ?>"
                                       data-material="<?php echo esc_attr($row['material'] ?? $args['filters']['material'] ?? ''); ?>"
                                       data-date="<?php echo esc_attr($row['date']); ?>"
                                       data-time="<?php echo esc_attr($row['time']); ?>"
                                       data-location="<?php echo esc_attr($row['location']); ?>"
                                       data-province="<?php echo esc_attr($row['province']); ?>"
                                       data-price="<?php echo esc_attr($row['price']); ?>"
                                       data-spots="<?php echo esc_attr($row['spots']); ?>"
                                    >
                                        <?php esc_html_e('Kandidaat aanmelden', 'pontifex-oi'); ?>
                                    </a>
                                <?php else: ?>
                                    <span class="pontifex-oi-vol"><?php esc_html_e('VOL', 'pontifex-oi'); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr>
                            <td colspan="7"><?php esc_html_e('Geen resultaten gevonden voor deze filters.', 'pontifex-oi'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="pontifex-oi-pagination-wrapper" role="region" aria-label="<?php esc_attr_e('Navigatie resultatenpagina\'s', 'pontifex-oi'); ?>">
                <div class="pontifex-oi-results-per-page" style="display: flex; align-items: center;">
                    <label for="pontifex-oi-results-per-page" style="margin-right: 0.5rem;"><?php esc_html_e('Aantal resultaten', 'pontifex-oi'); ?>:</label>
                    <select id="pontifex-oi-results-per-page" aria-controls="pontifex-oi-table" aria-label="<?php esc_attr_e('Aantal resultaten per pagina', 'pontifex-oi'); ?>">
                        <option value="10" <?php selected(10, $args['per_page'] ?? 10); ?>>10</option>
                        <option value="25" <?php selected(25, $args['per_page'] ?? 10); ?>>25</option>
                        <option value="50" <?php selected(50, $args['per_page'] ?? 10); ?>>50</option>
                    </select>
                </div>

                <nav aria-label="<?php echo esc_attr__('Paginanavigatie', 'pontifex-oi'); ?>">
                    <?php
                    $current = $args['current_page'] ?? 1;
                    $total   = $args['total_pages']  ?? 1;
                    $window  = 1;
                    $start   = max(2, $current - $window);
                    $end     = min($total - 1, $current + $window);
                    ?>
                    <?php if ($current > 1): ?>
                        <a href="#" data-page="<?php echo $current - 1; ?>" class="pontifex-oi-page-prev">&laquo;</a>
                    <?php else: ?>
                        <span class="pontifex-oi-page-disabled">&laquo;</span>
                    <?php endif; ?>

                    <a href="#" data-page="1" class="<?php echo $current == 1 ? 'pontifex-oi-page-active' : ''; ?>">1</a>

                    <?php if ($start > 2): ?>
                        <span>...</span>
                    <?php endif; ?>

                    <?php for ($i = $start; $i <= $end; $i++): ?>
                        <a href="#" data-page="<?php echo $i; ?>" class="<?php echo $current == $i ? 'pontifex-oi-page-active' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>

                    <?php if ($end < $total - 1): ?>
                        <span>...</span>
                    <?php endif; ?>

                    <?php if ($total > 1): ?>
                        <a href="#" data-page="<?php echo $total; ?>" class="<?php echo $current == $total ? 'pontifex-oi-page-active' : ''; ?>"><?php echo $total; ?></a>
                    <?php endif; ?>

                    <?php if ($current < $total): ?>
                        <a href="#" data-page="<?php echo $current + 1; ?>" class="pontifex-oi-page-next">&raquo;</a>
                    <?php else: ?>
                        <span class="pontifex-oi-page-disabled">&raquo;</span>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </div>

</section>