<?php
use function PontifexOI\Helpers\render_select;

// Dynamische examensoorten
$examTypes = $args['exam_types'];
if (!isset($examTypes[0]) || (isset($examTypes[0]['id']) && $examTypes[0]['id'] !== '')) {
    array_unshift($examTypes, ['id' => '', 'name' => __('Toon alles', 'pontifex-oi')]);
}

// Dynamische talen
$languages = $args['languages'];
if (!isset($languages[0]) || (isset($languages[0]['id']) && $languages[0]['id'] !== '')) {
    array_unshift($languages, ['id' => '', 'name' => __('Toon alles', 'pontifex-oi')]);
}

// Lesmateriaal
$matOpts = $args['materials'];

// Maanden, provincies, locaties en tijden ook dynamisch
$months = $args['months'];
if (!isset($months[0]) || (isset($months[0]['id']) && $months[0]['id'] !== '')) {
    array_unshift($months, ['id' => '', 'name' => __('Toon alles', 'pontifex-oi')]);
}

$provinces = $args['provinces'];
if (!isset($provinces[0]) || (isset($provinces[0]['id']) && $provinces[0]['id'] !== '')) {
    array_unshift($provinces, ['id' => '', 'name' => __('Toon alles', 'pontifex-oi')]);
}

$locations = $args['locations'];
if (!isset($locations[0]) || (isset($locations[0]['id']) && $locations[0]['id'] !== '')) {
    array_unshift($locations, ['id' => '', 'name' => __('Toon alles', 'pontifex-oi')]);
}

$timeslots = $args['timeslots'];
if (!isset($timeslots[0]) || (isset($timeslots[0]['id']) && $timeslots[0]['id'] !== '')) {
    array_unshift($timeslots, ['id' => '', 'name' => __('Toon alles', 'pontifex-oi')]);
}
?>

<div class="pontifex-oi-stepper" role="heading" aria-level="2" tabindex="0">
    <?php esc_html_e('Stap 1: Examen & planning', 'pontifex-oi'); ?>
</div>

<section class="pontifex-oi-section">
    <div id="step-1" class="active">
        <div class="pontifex-oi-bestellen">
            <form class="pontifex-oi-filters" method="get" action="" aria-label="<?php esc_attr_e('Filter examens en planning', 'pontifex-oi'); ?>">
                <div class="pontifex-oi-filter-row">
                    <div class="pontifex-oi-filter-group">
                        <h2 class="select-exam-label"><?php esc_html_e('Selecteer een examen', 'pontifex-oi'); ?></h2>
                        <div class="pontifex-oi-select-row">
                            <div class="pontifex-oi-filter-single">
                                <label for="exam_type-select"><?php esc_html_e('Examensoort', 'pontifex-oi'); ?></label>
                                <select id="exam_type-select" name="exam_type" class="pontifex-oi-filter" data-filter="exam_type">
                                    <?php foreach ($examTypes as $opt): ?>
                                        <option value="<?php echo esc_attr($opt['id']); ?>" <?php selected($args['filters']['exam_type'] ?? '', $opt['id']); ?>>
                                            <?php echo esc_html($opt['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="pontifex-oi-filter-single">
                                <label for="language-select"><?php esc_html_e('Taal', 'pontifex-oi'); ?></label>
                                <select id="language-select" name="language" class="pontifex-oi-filter" data-filter="language">
                                    <?php foreach ($languages as $opt): ?>
                                        <option value="<?php echo esc_attr($opt['id']); ?>" <?php selected($args['filters']['language'] ?? '', $opt['id']); ?>>
                                            <?php echo esc_html($opt['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="pontifex-oi-filter-group">
                        <h2 class="select-material-label"><?php esc_html_e('Lesmateriaal (optioneel)', 'pontifex-oi'); ?></h2>
                        <div class="pontifex-oi-select-row">
                            <div class="pontifex-oi-filter-single">
                                <label for="material-select"><?php esc_html_e('Lesmateriaal', 'pontifex-oi'); ?></label>
                                <select id="material-select" name="material" class="pontifex-oi-filter" data-filter="material">
                                    <?php foreach ($matOpts as $opt): ?>
                                        <option value="<?php echo esc_attr($opt['id']); ?>" <?php selected($args['filters']['material'] ?? '', $opt['id']); ?>>
                                            <?php echo esc_html($opt['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="pontifex-oi-reset-filter-container">
                                <button type="button" class="pontifex-oi-reset-filter">
                                    <?php esc_html_e('Reset filter', 'pontifex-oi'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <h2 class="select-date-label" style="margin-top:2rem;"><?php esc_html_e('Kies een datum en locatie', 'pontifex-oi'); ?></h2>
                <div class="pontifex-oi-filter-row -no-gap" style="margin-bottom:0.8rem; align-items: flex-end;">
                    <div class="pontifex-oi-filter-group" style="flex: 1 1 22%;">
                        <div class="pontifex-oi-filter-single">
                            <label for="month-select"><?php esc_html_e('Selecteer een maand', 'pontifex-oi'); ?></label>
                            <select id="month-select" name="month" class="pontifex-oi-filter" data-filter="month">
                                <?php foreach ($months as $opt): ?>
                                    <option value="<?php echo esc_attr($opt['id']); ?>" <?php selected($args['filters']['month'] ?? '', $opt['id']); ?>>
                                        <?php echo esc_html($opt['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="pontifex-oi-filter-group" style="flex: 1 1 22%;">
                        <div class="pontifex-oi-filter-single">
                            <label for="province-select"><?php esc_html_e('Selecteer een provincie', 'pontifex-oi'); ?></label>
                            <select id="province-select" name="province" class="pontifex-oi-filter" data-filter="province">
                                <?php foreach ($provinces as $opt): ?>
                                    <option value="<?php echo esc_attr($opt['id']); ?>" <?php selected($args['filters']['province'] ?? '', $opt['id']); ?>>
                                        <?php echo esc_html($opt['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="pontifex-oi-filter-group" style="flex: 1 1 22%;">
                        <div class="pontifex-oi-filter-single">
                            <label for="location-select"><?php esc_html_e('Selecteer een locatie', 'pontifex-oi'); ?></label>
                            <select id="location-select" name="location" class="pontifex-oi-filter" data-filter="location">
                                <?php foreach ($locations as $opt): ?>
                                    <option value="<?php echo esc_attr($opt['id']); ?>" <?php selected($args['filters']['location'] ?? '', $opt['id']); ?>>
                                        <?php echo esc_html($opt['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="pontifex-oi-filter-group" style="flex: 1 1 22%;">
                        <div class="pontifex-oi-filter-single">
                            <label for="timeslot-select"><?php esc_html_e('Ochtend, middag of avond', 'pontifex-oi'); ?></label>
                            <select id="timeslot-select" name="timeslot" class="pontifex-oi-filter" data-filter="timeslot">
                                <?php foreach ($timeslots as $opt): ?>
                                    <option value="<?php echo esc_attr($opt['id']); ?>" <?php selected($args['filters']['timeslot'] ?? '', $opt['id']); ?>>
                                        <?php echo esc_html($opt['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
            </form>

            <table class="pontifex-oi-table" aria-describedby="pontifex-oi-table-caption" role="table">
                <thead>
                    <tr>
                        <th scope="col"><?php esc_html_e('Datum', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Tijd', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Locatie', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Provincie', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Plekken vrij', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Prijs', 'pontifex-oi'); ?></th>
                        <th scope="col"><?php esc_html_e('Aanmelden', 'pontifex-oi'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($args['planning'])): foreach ($args['planning'] as $row): ?>
                        <tr>
                            <td><?php echo esc_html($row['date']); ?></td>
                            <td><?php echo esc_html($row['time']); ?></td>
                            <td><?php echo esc_html($row['location']); ?></td>
                            <td><?php echo esc_html($row['province']); ?></td>
                            <td><?php echo esc_html($row['spots']); ?></td>
                            <td>
                                <span class="pontifex-oi-dynamic-price"
                                      data-date="<?php echo esc_attr($row['date']); ?>"
                                      data-time="<?php echo esc_attr($row['time']); ?>"
                                      data-location="<?php echo esc_attr($row['location']); ?>"
                                      data-exam="<?php echo esc_attr($args['filters']['exam_type']); ?>"
                                      data-language="<?php echo esc_attr($args['filters']['language']); ?>"
                                      data-material="<?php echo esc_attr($args['filters']['material']); ?>"
                                >
                                    <span class="pontifex-oi-price-loader" style="display:inline-block;min-width:40px;">...</span>
                                </span>
                            </td>
                            <td>
                                <?php if (strtoupper($row['spots']) !== 'VOL'): ?>
                                    <a href="#"
                                       class="pontifex-oi-aanmelden"
                                       data-exam="<?php echo esc_attr($args['filters']['exam_type']); ?>"
                                       data-language="<?php echo esc_attr($args['filters']['language']); ?>"
                                       data-material="<?php echo esc_attr($args['filters']['material']); ?>"
                                       data-date="<?php echo esc_attr($row['date']); ?>"
                                       data-time="<?php echo esc_attr($row['time']); ?>"
                                       data-location="<?php echo esc_attr($row['location']); ?>"
                                       data-province="<?php echo esc_attr($row['province']); ?>"
                                       data-price=""
                                       data-spots="<?php echo esc_attr($row['spots']); ?>"
                                    >
                                        <?php esc_html_e('Kandidaat aanmelden', 'pontifex-oi'); ?>
                                    </a>
                                <?php else: ?>
                                    <span class="pontifex-oi-vol"><?php esc_html_e('VOL', 'pontifex-oi'); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr>
                            <td colspan="7"><?php esc_html_e('Geen resultaten gevonden voor deze filters.', 'pontifex-oi'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="pontifex-oi-pagination-wrapper" role="region" aria-label="<?php esc_attr_e('Navigatie resultatenpagina\'s', 'pontifex-oi'); ?>">
                <div class="pontifex-oi-results-per-page" style="display: flex; align-items: center;">
                    <label for="pontifex-oi-results-per-page" style="margin-right: 0.5rem;"><?php esc_html_e('Aantal resultaten', 'pontifex-oi'); ?>:</label>
                    <select id="pontifex-oi-results-per-page" aria-controls="pontifex-oi-table" aria-label="<?php esc_attr_e('Aantal resultaten per pagina', 'pontifex-oi'); ?>">
                        <option value="10" <?php selected(10, $args['per_page'] ?? 10); ?>>10</option>
                        <option value="25" <?php selected(25, $args['per_page'] ?? 10); ?>>25</option>
                        <option value="50" <?php selected(50, $args['per_page'] ?? 10); ?>>50</option>
                    </select>
                </div>

                <nav aria-label="<?php echo esc_attr__('Paginanavigatie', 'pontifex-oi'); ?>">
                    <?php
                    $current = $args['current_page'] ?? 1;
                    $total   = $args['total_pages']  ?? 1;
                    $window  = 1;
                    $start   = max(2, $current - $window);
                    $end     = min($total - 1, $current + $window);
                    ?>
                    <?php if ($current > 1): ?>
                        <a href="#" data-page="<?php echo $current - 1; ?>" class="pontifex-oi-page-prev">&laquo;</a>
                    <?php else: ?>
                        <span class="pontifex-oi-page-disabled">&laquo;</span>
                    <?php endif; ?>

                    <a href="#" data-page="1" class="<?php echo $current == 1 ? 'pontifex-oi-page-active' : ''; ?>">1</a>

                    <?php if ($start > 2): ?>
                        <span>...</span>
                    <?php endif; ?>

                    <?php for ($i = $start; $i <= $end; $i++): ?>
                        <a href="#" data-page="<?php echo $i; ?>" class="<?php echo $current == $i ? 'pontifex-oi-page-active' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>

                    <?php if ($end < $total - 1): ?>
                        <span>...</span>
                    <?php endif; ?>

                    <?php if ($total > 1): ?>
                        <a href="#" data-page="<?php echo $total; ?>" class="<?php echo $current == $total ? 'pontifex-oi-page-active' : ''; ?>"><?php echo $total; ?></a>
                    <?php endif; ?>

                    <?php if ($current < $total): ?>
                        <a href="#" data-page="<?php echo $current + 1; ?>" class="pontifex-oi-page-next">&raquo;</a>
                    <?php else: ?>
                        <span class="pontifex-oi-page-disabled">&raquo;</span>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </div>
</section>