<?php
namespace PontifexOI\PublicPart;

class PaymentSuccessHelpers {
    public static function get_data($key, $default = null) {
        return isset($_GET[$key]) ? $_GET[$key] : $default;
    }
    public static function is_test_mode() {
        return isset($_GET['test']) && $_GET['test'] === 'true';
    }
}

// Laad de helper
$is_test_mode = PaymentSuccessHelpers::is_test_mode();

if ($is_test_mode) {
    $candidate_fullnames  = ['Jan Jansen', 'Piet Pietersen'];
    $candidate_infixes    = ['de', ''];
    $candidate_lastnames  = ['Jansen', 'Pietersen'];
    $candidate_birthdates = ['01-01-1990', '02-02-1991'];
} else {
    $candidate_fullnames  = (array)PaymentSuccessHelpers::get_data('candidate_fullname');
    $candidate_infixes    = (array)PaymentSuccessHelpers::get_data('candidate_infix');
    $candidate_lastnames  = (array)PaymentSuccessHelpers::get_data('candidate_lastname');
    $candidate_birthdates = (array)PaymentSuccessHelpers::get_data('candidate_birthdate');
}

$order_initials    = $is_test_mode ? 'J' : PaymentSuccessHelpers::get_data('order_initials');
$order_infix       = $is_test_mode ? 'de' : PaymentSuccessHelpers::get_data('order_infix');
$order_lastname    = $is_test_mode ? 'Jansen' : PaymentSuccessHelpers::get_data('order_lastname');
$order_postcode    = $is_test_mode ? '1234 AB' : PaymentSuccessHelpers::get_data('order_postcode');
$order_housenumber = $is_test_mode ? '56' : PaymentSuccessHelpers::get_data('order_housenumber');
$order_street      = $is_test_mode ? 'Main Street' : PaymentSuccessHelpers::get_data('order_street');
$order_city        = $is_test_mode ? 'Amsterdam' : PaymentSuccessHelpers::get_data('order_city');
$order_phone       = $is_test_mode ? '0612345678' : PaymentSuccessHelpers::get_data('order_phone');
$order_email       = $is_test_mode ? 'test@example.com' : PaymentSuccessHelpers::get_data('order_email');
$order_company     = $is_test_mode ? 'Test Company' : PaymentSuccessHelpers::get_data('order_company');
$order_vat         = $is_test_mode ? 'NL123456789B01' : PaymentSuccessHelpers::get_data('order_vat');

$exam_label     = $is_test_mode ? 'VCA'        : PaymentSuccessHelpers::get_data('exam_label');
$language_label = $is_test_mode ? 'Nederlands' : PaymentSuccessHelpers::get_data('language_label');
$material_label = $is_test_mode ? 'Boek'       : PaymentSuccessHelpers::get_data('material_label');
$location       = $is_test_mode ? 'Breda'      : PaymentSuccessHelpers::get_data('location');
$date           = $is_test_mode ? '01-12-2025' : PaymentSuccessHelpers::get_data('date');
$time           = $is_test_mode ? '10:00'      : PaymentSuccessHelpers::get_data('time');
$amount         = $is_test_mode ? count($candidate_fullnames) : PaymentSuccessHelpers::get_data('amount');
$price          = $is_test_mode ? '€100.00'    : PaymentSuccessHelpers::get_data('price');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Betaling Succesvol</title>
</head>
<body style="background-color: #F0F0F0; font-family: 'Open Sans', sans-serif; margin: 0; padding: 0;">

    <div class="pontifex-oi-payment-success" style="background-color: #ffffff; padding: 20px; margin: 30px auto; width: 100%; max-width: 700px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);">
        <h2 class="pontifex-oi-payment-success-title" style="font-size: 24px; color: #333;">Betaling succesvol</h2>
        <p class="pontifex-oi-payment-success-message" style="font-size: 16px; color: #555;">Bedankt voor je inschrijving.<br>
            Je betaling is succesvol ontvangen. Een overzicht van je bestelling is naar je e-mailadres gestuurd.</p>
        
        <!-- Gegevens kandidaat/kandidaten -->
        <h3 class="pontifex-oi-section-label" style="font-size: 18px; color: #FF9900;">
            <?php echo count($candidate_fullnames) > 1 ? 'Gegevens kandidaten' : 'Gegevens kandidaat'; ?>
        </h3>
        <?php foreach ($candidate_fullnames as $idx => $candidate_fullname): ?>
            <div class="pontifex-oi-candidate-details" style="background-color: #f9f9f9; padding: 15px; border-radius: 6px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom:18px;">
                <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                    <strong style="font-weight: bold; color: #333;">Naam en achternaam:</strong>
                    <span style="color: #555;"><?php echo htmlspecialchars($candidate_fullname); ?></span>
                </div>
                <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                    <strong style="font-weight: bold; color: #333;">Tussenvoegsel (optioneel):</strong>
                    <span style="color: #555;"><?php echo htmlspecialchars($candidate_infixes[$idx] ?? ''); ?></span>
                </div>
                <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                    <strong style="font-weight: bold; color: #333;">Achternaam:</strong>
                    <span style="color: #555;"><?php echo htmlspecialchars($candidate_lastnames[$idx] ?? ''); ?></span>
                </div>
                <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                    <strong style="font-weight: bold; color: #333;">Geboortedatum:</strong>
                    <span style="color: #555;"><?php echo htmlspecialchars($candidate_birthdates[$idx] ?? ''); ?></span>
                </div>
            </div>
        <?php endforeach; ?>

        <!-- Bestelgegevens -->
        <div class="pontifex-oi-flex-row" style="display: flex; gap: 20px; margin-top: 20px;">
            <div class="pontifex-oi-column" style="width: 48%;">
                <h3 class="pontifex-oi-section-label" style="font-size: 18px; color: #444;">Bestelgegevens</h3>
                <div class="pontifex-oi-box" style="background-color: #f9f9f9; padding: 15px; border-radius: 6px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Naam:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars(trim($order_initials . ' ' . $order_infix . ' ' . $order_lastname)); ?></span>
                    </div>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Postcode en huisnummer:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($order_postcode . ' ' . $order_housenumber); ?></span>
                    </div>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Adres:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($order_street . ', ' . $order_city); ?></span>
                    </div>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Telefoonnummer:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($order_phone); ?></span>
                    </div>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">E-mailadres:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($order_email); ?></span>
                    </div>
                    <?php if (!empty($order_company)) : ?>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Bedrijfsnaam:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($order_company); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($order_vat)) : ?>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">BTW-nummer:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($order_vat); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Betaalgegevens -->
            <div class="pontifex-oi-column" style="width: 48%;">
                <h3 class="pontifex-oi-section-label" style="font-size: 18px; color: #444;">Betaalgegevens</h3>
                <div class="pontifex-oi-box" style="background-color: #f9f9f9; padding: 15px; border-radius: 6px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Examen:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($exam_label); ?></span>
                    </div>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Taal:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($language_label); ?></span>
                    </div>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Lesmateriaal:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($material_label); ?></span>
                    </div>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Locatie:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($location); ?></span>
                    </div>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Datum:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($date); ?></span>
                    </div>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Tijd:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($time); ?></span>
                    </div>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Aantal kandidaten:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($amount); ?></span>
                    </div>
                    <div class="bestel-item" style="display: flex; justify-content: space-between; font-size: 14px; padding: 5px 0; border-bottom: 1px solid #ddd;">
                        <strong style="font-weight: bold; color: #333;">Prijs totaal:</strong>
                        <span style="color: #555;"><?php echo htmlspecialchars($price); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>