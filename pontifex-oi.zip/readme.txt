=== Pontifex OI ===
Contributors: [jouw naam]
Tags: pontifex, inschrijven, examens, soap, api, planning
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: pontifex-oi
Domain Path: /languages

== Description ==
Veilige en schaalbare koppeling met de Pontifex Open Inschrijvingen webservice (SOAP-API). Haal actuele examenplanningen op, beheer kandidaten en verwerk inschrijvingen volledig binnen WordPress. Volledig OOP, Composer-ready, i18n, en AVG-proof. Templates zijn overridebaar, alles is future-proof en eenvoudig uit te breiden.

== Installation ==
1. Upload de pluginmap naar `/wp-content/plugins/`.
2. Activeer via het WordPress-dashboard.
3. Zet je Pontifex-API-gegevens (user_identifier, company_identifier, hash) in de code of via een settingspagina (komt in volgende release).
4. Voeg de shortcode `[pontifex_oi_planning]` toe aan een pagina of bericht.

== Frequently Asked Questions ==

= Is deze plugin AVG/GDPR-proof? =
Ja. Er worden geen persoonsgegevens lokaal opgeslagen. Alle communicatie verloopt beveiligd via de officiële Pontifex SOAP-API.

= Wat heb ik nodig voor een werkende koppeling? =
Een geldige user_identifier, company_identifier en SHA256-hash van Pontifex Certificatie.

= Kan ik deze plugin uitbreiden of themen? =
Ja, alles is overridebaar via templates en hooks. De code is volledig OOP/modulair opgezet.

== Screenshots ==
1. Voorbeeld van een instellingspagina (indien geïmplementeerd).
2. Front-end weergave van examenplanningen met filters.
3. Voorbeeld van het registratie/aanmeldformulier.

== Upgrade Notice ==
= 1.0.0 =
Eerste versie: basis integratie, veilig en schaalbaar. Gereed voor koppeling met Pontifex SOAP-API.

== Changelog ==
= 1.0.0 =
* Eerste release, klaar voor koppeling met Pontifex SOAP-API.
* Volledig OOP, Composer-ready, testbaar en future-proof.
* Templates overridebaar en i18n-ready.

== Credits ==
- Pontifex Certificatie voor de API
- [Jouw naam/team]

== Support ==
Voor hulp of uitbreidingen: [jouw supportlink of mailadres]