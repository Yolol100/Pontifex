/**
 * sidebar.js
 *
 * Injects a mobile-only filter sidebar that mirrors your desktop filters
 * and keeps everything in sync, now with AJAX-based “apply filters” so
 * the results update without a full page reload.
 */
(function(window, $) {
  'use strict';

  const PontifexOI = window.PontifexOI = window.PontifexOI || {};

  // Weekend-examens voor taal‐logica
  PontifexOI.examWeekend = ['vca-basis-weekend', 'vca-vol-weekend'];

  /**
   * Injecteert de sidebar HTML en vult de <select>s vanuit de desktop filters.
   * Alleen zichtbaar bij viewport ≤ 480px; anders worden de mobile-only elementen verwijderd.
   */
  PontifexOI.addAndPopulateSidebar = function() {
    const isMobile = $(window).width() <= 480;

    if (!isMobile) {
      // Verwijder mobile‐only elementen als ze bestaan
      $('.pontifex-oi-filters-toggle-btn, .pontifex-oi-filters-sidebar, .pontifex-oi-filters-sidebar-overlay')
        .remove();
      return;
    }

    // Niet dubbel injecteren
    if ($('.pontifex-oi-filters-toggle-btn').length) return;

    // Sidebar markup
    const sidebarHtml = `
      <button type="button" class="pontifex-oi-filters-toggle-btn">Filters</button>
      <div class="pontifex-oi-filters-sidebar-overlay"></div>
      <aside class="pontifex-oi-filters-sidebar" aria-modal="true" role="dialog" tabindex="0">
        <button class="pontifex-oi-filters-sidebar-close" aria-label="Sluit filters">&times;</button>
        <form class="pontifex-oi-filters-sidebar-form" autocomplete="off">
          <h2>Selecteer een examen</h2>
          <div class="sidebar-exam-row">
            <div>
              <label for="sidebar-exam_type">Examensoort</label>
              <select id="sidebar-exam_type" name="exam_type"></select>
            </div>
            <div>
              <label for="sidebar-language">Taal</label>
              <select id="sidebar-language" name="language"></select>
            </div>
          </div>
          <div class="sidebar-action-row">
            <button type="button" class="pontifex-oi-reset-filter pontifex-oi-sidebar-btn">
              Reset datumfilters
            </button>
          </div>
          <h2 style="margin-top:1.6rem;">Kies een datum en locatie</h2>
          <div class="sidebar-date-row">
            <div>
              <label for="sidebar-month">Maand</label>
              <select id="sidebar-month" name="month"></select>
            </div>
            <div>
              <label for="sidebar-province">Provincie</label>
              <select id="sidebar-province" name="province"></select>
            </div>
          </div>
          <div class="sidebar-location-row">
            <div>
              <label for="sidebar-location">Locatie</label>
              <select id="sidebar-location" name="location"></select>
            </div>
            <div>
              <label for="sidebar-timeslot">Dagsoort</label>
              <select id="sidebar-timeslot" name="timeslot"></select>
            </div>
          </div>
          <div class="sidebar-action-row">
            <button type="button" class="pontifex-oi-save-btn pontifex-oi-sidebar-btn">
              Filters toepassen
            </button>
          </div>
        </form>
      </aside>
    `;

    // Invoegen vóór de desktop-filters
    $(sidebarHtml).insertBefore('.pontifex-oi-filters');

    // Koppel desktop <select> IDs aan sidebar IDs
    const mapping = [
      ['#exam_type-select',  'sidebar-exam_type'],
      ['#language-select',   'sidebar-language'],
      ['#month-select',      'sidebar-month'],
      ['#province-select',   'sidebar-province'],
      ['#location-select',   'sidebar-location'],
      ['#timeslot-select',   'sidebar-timeslot']
    ];

    mapping.forEach(([desktopSel, sidebarId]) => {
      const $desk = $(desktopSel);
      const $side = $(`#${sidebarId}`);
      if ($desk.length && $side.length) {
        $side.html($desk.html());
        $side.val($desk.val());
      }
    });

    // Pas direct de taal-logica toe voor weekend‐examens
    updateSidebarLanguageOptions();
  };

  /**
   * Toon alleen 'nl' bij weekend-examens, anders alle opties.
   */
  function updateSidebarLanguageOptions() {
    const $exam = $('#sidebar-exam_type');
    const $lang = $('#sidebar-language');
    const val = $exam.val();

    if (!val) {
      $lang.val('').prop('disabled', true).find('option').show();
      return;
    }
    $lang.prop('disabled', false);

    if (PontifexOI.examWeekend.includes(val)) {
      $lang.find('option').each(function() {
        const v = $(this).val();
        $(this).toggle(v === '' || v === 'nl');
      });
      if ($lang.val() !== 'nl') $lang.val('nl');
    } else {
      $lang.find('option').show();
    }
  }

  /**
   * Registreer open/close/reset/apply events voor de sidebar.
   * “Apply filters” werkt nu via AJAX, geen volledige reload meer.
   */
  PontifexOI.registerSidebarEvents = function() {
    // Open sidebar
    $(document).on('click', '.pontifex-oi-filters-toggle-btn', function(e) {
      e.preventDefault();
      ['exam_type','language','month','province','location','timeslot']
        .forEach(name => {
          $(`#sidebar-${name}`).val($(`#${name}-select`).val());
        });
      updateSidebarLanguageOptions();
      $('.pontifex-oi-filters-sidebar, .pontifex-oi-filters-sidebar-overlay').addClass('open');
      $('.pontifex-oi-filters-sidebar').focus();
    });

    // Close sidebar
    $(document).on('click', '.pontifex-oi-filters-sidebar-overlay, .pontifex-oi-filters-sidebar-close', function(e) {
      e.preventDefault();
      $('.pontifex-oi-filters-sidebar, .pontifex-oi-filters-sidebar-overlay').removeClass('open');
    });

    // ESC sluit ook
    $(document).on('keydown', function(e) {
      if (e.key === 'Escape' && $('.pontifex-oi-filters-sidebar').hasClass('open')) {
        $('.pontifex-oi-filters-sidebar, .pontifex-oi-filters-sidebar-overlay').removeClass('open');
      }
    });

    // Reset datum/locatie filters in sidebar
    $(document).on('click', '.pontifex-oi-reset-filter', function(e) {
      e.preventDefault();
      $('#sidebar-month,#sidebar-province,#sidebar-location,#sidebar-timeslot').val('');
    });

    // Re-apply language logic als exam_type verandert
    $(document).on('change', '#sidebar-exam_type', updateSidebarLanguageOptions);

    // Apply filters via AJAX
    $(document).on('click', '.pontifex-oi-save-btn', function(e) {
      e.preventDefault();

      // 1) Sync sidebar → desktop selects & trigger change
      ['exam_type','language','month','province','location','timeslot']
        .forEach(name => {
          const v = $(`#sidebar-${name}`).val();
          $(`#${name}-select`).val(v).trigger('change');
        });

      // 2) AJAX update resultaten (staat in filters.js / main.js)
      if (PontifexOI.updatePontifexTable) {
        PontifexOI.updatePontifexTable(1);
      }

      // 3) Sluit sidebar
      $('.pontifex-oi-filters-sidebar, .pontifex-oi-filters-sidebar-overlay').removeClass('open');
    });
  };

  // Initialiseer op DOM ready
  $(function() {
    PontifexOI.addAndPopulateSidebar();
    PontifexOI.registerSidebarEvents();
  });

  // Bij resizen toggled injectie/removal
  $(window).on('resize', PontifexOI.addAndPopulateSidebar);

})(window, jQuery);