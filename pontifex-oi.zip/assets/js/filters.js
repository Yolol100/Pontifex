// assets/js/filters.js
(function(window, $) {
  'use strict';

  // Gebruik centrale config (ajaxUrl, examWeekend) uit localized JS variabele
  const cfg = window.PontifexOIConfigData || window.PontifexOIConfig || {};
  const PontifexOI = window.PontifexOI || {};
  const weekendExams = Array.isArray(cfg.examWeekend) ? cfg.examWeekend : [];

  /**
   * Haalt planning via AJAX op en update tabel + kaarten + paginatie + prijzen.
   */
  PontifexOI.updatePontifexTable = function(page = 1) {
    const filters = {
      exam_type: $('select[name="exam_type"], #exam_type-select').val(),
      language:  $('select[name="language"], #language-select').val(),
      month:     $('select[name="month"]').val(),
      province:  $('select[name="province"]').val(),
      location:  $('select[name="location"]').val(),
      timeslot:  $('select[name="timeslot"]').val(),
      page
    };

    $.post(cfg.ajaxUrl, {
      action: 'pontifex_oi_get_planning',
      filters
    }).done(function(res) {
      if (!res.success) return;

      const planning = res.data.planning || [];

      // Tabel opbouwen
      let rowsHtml = '';
      if (planning.length === 0) {
        rowsHtml = `
          <tr><td colspan="7" class="pontifex-oi-no-results">
          Geen resultaten gevonden die voldoen aan je zoekcriteria.
          </td></tr>`;
      } else {
        rowsHtml = planning.map(row => `
          <tr>
            <td>${row.date || '-'}</td>
            <td>${row.time || '-'}</td>
            <td>${row.location || '-'}</td>
            <td>${row.province || '-'}</td>
            <td>${row.spots || '-'}</td>
            <td>
              <span class="pontifex-oi-dynamic-price"
                    data-date="${row.date}"
                    data-time="${row.time}"
                    data-location="${row.location}"
                    data-exam="${row.exam || filters.exam_type}"
                    data-language="${row.language || filters.language}"
                    data-material="1">
                <span class="pontifex-oi-price-loader">…</span>
              </span>
            </td>
            <td>
              ${(row.spots || '').toUpperCase() !== 'VOL'
                ? `<form method="get" class="pontifex-oi-aanmeld-form" action="/cursus-inschrijven/">
                     <input type="hidden" name="aanmelden" value="1">
                     <input type="hidden" name="exam_type" value="${row.exam || filters.exam_type}">
                     <input type="hidden" name="language" value="${row.language || filters.language}">
                     <input type="hidden" name="material" value="1">
                     <input type="hidden" name="date" value="${row.date}">
                     <input type="hidden" name="time" value="${row.time}">
                     <input type="hidden" name="location" value="${row.location}">
                     <input type="hidden" name="province" value="${row.province}">
                     <input type="hidden" name="spots" value="${row.spots}">
                     <input type="hidden" name="price" value="" class="pontifex-oi-price-input">
                     <button type="submit" class="pontifex-oi-aanmelden">Kandidaat aanmelden</button>
                   </form>`
                : `<span class="pontifex-oi-vol">VOL</span>`
              }
            </td>
          </tr>
        `).join('');
      }
      $('.pontifex-oi-table tbody').html(rowsHtml);

      // Kaarten opbouwen (mobiel/tablet)
      let cardsHtml = '';
      if (planning.length === 0) {
        cardsHtml = `<p class="pontifex-oi-no-results">Geen resultaten gevonden voor deze filters.</p>`;
      } else {
        cardsHtml = planning.map(row => {
          const exam = row.exam || filters.exam_type;
          const lang = row.language || filters.language;
          const spots = row.spots || '-';
          return `
            <article class="pontifex-oi-card" role="listitem">
              <dl>
                <dd class="pontifex-oi-date">${row.date || '-'}</dd>
                <dt>Tijd</dt><dd>${row.time || '-'}</dd>
                <dt>Locatie</dt><dd>${row.location || '-'}</dd>
                <dt>Provincie</dt><dd>${row.province || '-'}</dd>
                <dt>Plekken vrij</dt><dd>${spots}</dd>
                <dt>Prijs</dt>
                <dd>
                  <span class="pontifex-oi-dynamic-price"
                        data-date="${row.date}"
                        data-time="${row.time}"
                        data-location="${row.location}"
                        data-exam="${exam}"
                        data-language="${lang}"
                        data-material="1">
                    <span class="pontifex-oi-price-loader">…</span>
                  </span>
                </dd>
                <dd>
                  ${spots.toUpperCase() !== 'VOL'
                    ? `<form method="get" class="pontifex-oi-aanmeld-form" action="/cursus-inschrijven/">
                         <input type="hidden" name="aanmelden" value="1">
                         <input type="hidden" name="exam_type" value="${exam}">
                         <input type="hidden" name="language" value="${lang}">
                         <input type="hidden" name="material" value="1">
                         <input type="hidden" name="date" value="${row.date}">
                         <input type="hidden" name="time" value="${row.time}">
                         <input type="hidden" name="location" value="${row.location}">
                         <input type="hidden" name="province" value="${row.province}">
                         <input type="hidden" name="spots" value="${row.spots}">
                         <input type="hidden" name="price" value="" class="pontifex-oi-price-input">
                         <button type="submit" class="pontifex-oi-aanmelden">Kandidaat aanmelden</button>
                       </form>`
                    : `<span class="pontifex-oi-vol">VOL</span>`
                  }
                </dd>
              </dl>
            </article>
          `;
        }).join('');
      }

      $('#pontifex-oi-cards-container').html(cardsHtml);

      // Update alle prijzen
      if (PontifexOI.updateAllDynamicPrices) PontifexOI.updateAllDynamicPrices();

      // Paginatie opbouwen via centrale functie
      const cp = res.data.current_page;
      const tp = res.data.total_pages;

      if (typeof PontifexOI.renderPagination === 'function') {
        PontifexOI.renderPagination(cp, tp);
      }

      if (typeof PontifexOI.initPaginationEvents === 'function') {
        PontifexOI.initPaginationEvents(function(page){
          PontifexOI.updatePontifexTable(page);
        });
      }
    }).fail(function() {
      console.warn('Ajax request voor planning is mislukt, overweeg pagina reload als fallback.');
    });
  };

  /**
   * Filterstate updaten en weekend-examens uitsluiten Engels.
   */
  function updateFiltersState() {
    const $exam = $('select[name="exam_type"], #exam_type-select');
    const $lang = $('select[name="language"], #language-select');
    const examVal = $exam.val();
    const langVal = $lang.val();

    if (!examVal) {
      $lang.val('').prop('disabled', true).find('option').show();
      return;
    }

    $lang.prop('disabled', false);

    if (weekendExams.includes(examVal)) {
      $lang.find('option').each(function() {
        const v = $(this).val();
        $(this).toggle(v === '' || v === 'nl');
      });
      if (langVal !== 'nl') {
        $lang.val('nl').trigger('change');
      }
    } else {
      $lang.find('option').show();
      if (!langVal) $lang.val('');
    }
  }

  /**
   * Alle event handlers binden.
   */
  function bindFilterHandlers() {
    $(document).on('change',
      '.pontifex-oi-filter, select[name="exam_type"], select[name="language"], #exam_type-select, #language-select',
      function() {
        updateFiltersState();
        PontifexOI.updatePontifexTable(1);
      }
    );

    $(document).on('submit', '.pontifex-oi-filters', function(e) {
      e.preventDefault();
      updateFiltersState();
      PontifexOI.updatePontifexTable(1);
    });

    $(document).on('click', '.pontifex-oi-pagination-wrapper a[data-page]', function(e) {
      e.preventDefault();
      PontifexOI.updatePontifexTable(parseInt($(this).data('page'), 10));
    });
  }

  /**
   * Dynamische prijzen updaten.
   */
  function updateAllDynamicPrices() {
    $('.pontifex-oi-dynamic-price').each(function() {
      const $el = $(this);
      const exam = $el.data('exam') || $('select[name="exam_type"], #exam_type-select').val() || 'los-examen-vca-basis';
      const language = $el.data('language') || $('select[name="language"], #language-select').val() || 'nl';
      const material = $el.data('material') || '1';
      const $loader = $el.find('.pontifex-oi-price-loader');

      $loader.text('…');
      if (PontifexOI.fetchPrice) {
        PontifexOI.fetchPrice(exam, language, material, function(priceText) {
          $loader.text(priceText);
          const $form = $el.closest('tr, .pontifex-oi-card').find('.pontifex-oi-aanmeld-form');
          if ($form.length) {
            $form.find('.pontifex-oi-price-input, input[name="price"]').val(priceText);
          }
        }, cfg.ajaxUrl);
      } else {
        $loader.text('€129,00');
      }
    });
  }

  // Expose functies op global
  if (!window.PontifexOI) window.PontifexOI = {};
  window.PontifexOI.updatePontifexTable = PontifexOI.updatePontifexTable;
  window.PontifexOI.updateFiltersState = updateFiltersState;
  window.PontifexOI.bindFilterHandlers = bindFilterHandlers;
  window.PontifexOI.updateAllDynamicPrices = updateAllDynamicPrices;

  // Init
  $(document).ready(function() {
    bindFilterHandlers();
    updateFiltersState();
    PontifexOI.updatePontifexTable(1);
  });

})(window, jQuery);