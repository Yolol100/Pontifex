// pontifex-oi-admin.js

jQuery(function ($) {
    'use strict';

    // ===================== TOGGLE SWITCH (alleen Mollie pagina) =====================
    var $testToggle = $('#pontifex_oi_mollie_test_mode');
    var $toggleSwitch = $testToggle.parent('.pontifex-toggle-switch');
    var $toggleLabel = $('.pontifex-toggle-label');

    // Zet juiste class/init bij paginalaad
    if ($testToggle.length && $toggleSwitch.length) {
        $toggleSwitch.toggleClass('checked', $testToggle.prop('checked'));
        $toggleLabel.text($testToggle.prop('checked') ? 'Testmodus ingeschakeld' : 'Testmodus uitgeschakeld');

        $testToggle.on('change', function () {
            $toggleSwitch.toggleClass('checked', this.checked);
            $toggleLabel.text(this.checked ? 'Testmodus ingeschakeld' : 'Testmodus uitgeschakeld');
        });
    }

    // ===================== COPY API KEY (voor alle inputs) =====================
    $('.pontifex-admin-input').on('focus', function () {
        $(this).select();
    });

    // ===================== SIMPLE VALIDATION (alleen voor Mollie) =====================
    $('form').on('submit', function (e) {
        // Alleen valideren als Mollie formulier (controleer op Mollie inputs)
        var $live = $('#pontifex_oi_mollie_live_api_key');
        var $test = $('#pontifex_oi_mollie_test_api_key');
        if ($live.length && $live.val() && !$live.val().startsWith('live_')) {
            alert('Let op: De live key hoort meestal te beginnen met "live_".');
            $live.focus();
            e.preventDefault();
            return false;
        }
        if ($test.length && $test.val() && !$test.val().startsWith('test_')) {
            alert('Let op: De test key hoort meestal te beginnen met "test_".');
            $test.focus();
            e.preventDefault();
            return false;
        }
        // Allow submit
        return true;
    });

    // ===================== SOAP: Haal gegevens op knop =====================
    var $fetchBtn = $('#pontifex-soap-fetch-btn');
    var $feedback = $('#pontifex-soap-fetch-feedback');

    if ($fetchBtn.length) {
        // Standaard feedbackdiv verbergen, géén ruimte reserveren!
        $feedback.hide();

        $fetchBtn.on('click', function (e) {
            e.preventDefault();

            $fetchBtn.prop('disabled', true).text('Bezig...');
            $feedback.hide().html(''); // Direct verbergen & leegmaken

            // Verzamel data uit formulier
            var soap_url    = $('#pontifex_oi_soap_url').val();
            var user_id     = $('#pontifex_oi_soap_user_id').val();
            var company_id  = $('#pontifex_oi_soap_company_id').val();
            var hash        = $('#pontifex_oi_soap_hash').val();

            $.ajax({
                url: ajaxurl, // WordPress admin ajax
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'pontifex_oi_fetch_soap_data',
                    soap_url: soap_url,
                    user_id: user_id,
                    company_id: company_id,
                    hash: hash
                },
                success: function (response) {
                    $fetchBtn.prop('disabled', false).text('Haal gegevens op');

                    if (response && response.success) {
                        $feedback.html(
                            '<div class="pontifex-soap-feedback success">' +
                            '<span class="pontifex-feedback-icon">&#10003;</span> ' +
                            '<span>Gegevens succesvol opgehaald en opgeslagen.</span>' +
                            '</div>'
                        ).css('display', 'flex');
                    } else {
                        $feedback.html(
                            '<div class="pontifex-soap-feedback error">' +
                            '<span class="pontifex-feedback-icon">&#10060;</span> ' +
                            '<span>' + (response.data && response.data.message ? response.data.message : 'Ophalen mislukt. Probeer opnieuw.') + '</span>' +
                            '</div>'
                        ).css('display', 'flex');
                    }
                },
                error: function (xhr, status, error) {
                    $fetchBtn.prop('disabled', false).text('Haal gegevens op');
                    $feedback.html(
                        '<div class="pontifex-soap-feedback error">' +
                        '<span class="pontifex-feedback-icon">&#10060;</span> ' +
                        '<span>Ophalen mislukt. Probeer opnieuw.</span>' +
                        '</div>'
                    ).css('display', 'flex');
                }
            });
        });
    }

});