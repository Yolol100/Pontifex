// pontifex-oi-admin.js

jQuery(function ($) {
    'use strict';

    // ===================== TOGGLE SWITCH =====================
    var $testToggle = $('#pontifex_oi_mollie_test_mode');
    var $toggleSwitch = $testToggle.parent('.pontifex-toggle-switch');
    var $toggleLabel = $('.pontifex-toggle-label');

    // Zet juiste class/init bij paginalaad
    if ($testToggle.length && $toggleSwitch.length) {
        $toggleSwitch.toggleClass('checked', $testToggle.prop('checked'));
        $toggleLabel.text($testToggle.prop('checked') ? 'Testmodus ingeschakeld' : 'Testmodus uitgeschakeld');

        $testToggle.on('change', function () {
            $toggleSwitch.toggleClass('checked', this.checked);
            $toggleLabel.text(this.checked ? 'Testmodus ingeschakeld' : 'Testmodus uitgeschakeld');
        });
    }

    // ===================== COPY API KEY =====================
    $('.pontifex-admin-input').on('focus', function () {
        $(this).select();
    });

    // ===================== SIMPLE VALIDATION =====================
    $('form').on('submit', function (e) {
        var $live = $('#pontifex_oi_mollie_live_api_key');
        var $test = $('#pontifex_oi_mollie_test_api_key');
        if ($live.val() && !$live.val().startsWith('live_')) {
            alert('Let op: De live key hoort meestal te beginnen met "live_".');
            $live.focus();
            e.preventDefault();
            return false;
        }
        if ($test.val() && !$test.val().startsWith('test_')) {
            alert('Let op: De test key hoort meestal te beginnen met "test_".');
            $test.focus();
            e.preventDefault();
            return false;
        }
        // Allow submit
        return true;
    });
});