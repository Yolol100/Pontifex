jQuery(function($) {
    'use strict';

    console.log('pontifex-oi main.js actief!');

    // 1. Sidebar functionaliteit (voor mobiel)
    if (window.PontifexOI) {
        if (typeof window.PontifexOI.pontifexAddSidebarHtml === 'function') {
            window.PontifexOI.pontifexAddSidebarHtml();
        }
        if (typeof window.PontifexOI.registerSidebarEvents === 'function') {
            window.PontifexOI.registerSidebarEvents();
        }
    }

    // 2. Filters initialiseren en event handlers binden
    if (window.PontifexOI) {
        if (typeof window.PontifexOI.loadFilterState === 'function') {
            window.PontifexOI.loadFilterState();
        }
        if (typeof window.PontifexOI.setDefaultFiltersIfNeeded === 'function') {
            window.PontifexOI.setDefaultFiltersIfNeeded();
        }
        if (typeof window.PontifexOI.updateFiltersState === 'function') {
            window.PontifexOI.updateFiltersState();
        }
        if (typeof window.PontifexOI.bindFilterHandlers === 'function') {
            window.PontifexOI.bindFilterHandlers();
        }
    }

    // 3. Update materiaal checkboxes
    if (window.PontifexOI && typeof window.PontifexOI.updateExtraMaterialCheckboxes === 'function') {
        window.PontifexOI.updateExtraMaterialCheckboxes();
    }

    // 4. Prijzen dynamisch updaten
    if (window.PontifexOI && typeof window.PontifexOI.updateAllDynamicPrices === 'function') {
        window.PontifexOI.updateAllDynamicPrices();
    }

    // 5. Paginatie events initialiseren
    if (window.PontifexOI && typeof window.PontifexOI.initPaginationEvents === 'function') {
        window.PontifexOI.initPaginationEvents(function(page) {
            console.log('Pagina wissel naar:', page);
            window.PontifexOI.updatePontifexTable(page);
        });
    }

    // 6. Update form inputs in table rows
    if (window.PontifexOI && typeof window.PontifexOI.updateFormInputsInTableRows === 'function') {
        window.PontifexOI.updateFormInputsInTableRows();
    }

    // 7. (Optioneel) Kandidaten functionaliteit
    // if (window.PontifexOI && typeof window.PontifexOI.initCandidates === 'function') {
    //     window.PontifexOI.initCandidates();
    // }

    // 🔧 8. AJAX-load van eerste pagina — NU correct geplaatst
    if ($('.pontifex-oi-filters').length && window.PontifexOI && typeof window.PontifexOI.updatePontifexTable === 'function') {
        console.log('Initialiseer planning via AJAX (pagina 1)');
        window.PontifexOI.updatePontifexTable(1);
    }

    console.log('pontifex-oi: alle functies zijn geïnitialiseerd.');

});