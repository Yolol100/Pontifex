/* global PontifexOiAjax */
jQuery(function ($) {
    'use strict';

    // ===================== CONFIG & GLOBALS =====================
    const ajaxUrl             = (typeof PontifexOiAjax !== 'undefined') ? PontifexOiAjax.ajax_url : '';
    const registrationPageUrl = '/cursus-inschrijven/';
    const planningPageUrl     = '/cursus-zoeken/';

    let gekozenPlanning = {};

    const dependencies = {
        exam_type: ['language', 'material'],
        language:  ['material'],
    };

    const hasStep1            = $('#step-1').length > 0;
    const hasStep2            = $('#step-2').length > 0;
    const bothStepsSamePage   = hasStep1 && hasStep2;
    const isPlanningPage      = $('.pontifex-oi-filters').length > 0;                 // stap 1
    const isRegistrationPage  = hasStep2 && !hasStep1;                                 // losse stap 2 pagina

    // ===================== HELPERS =====================
    function debounce(fn, delay) {
        let timer = null;
        return function () {
            const ctx = this, args = arguments;
            clearTimeout(timer);
            timer = setTimeout(function () { fn.apply(ctx, args); }, delay);
        };
    }

    function readParamsToPlanning() {
        const params = new URLSearchParams(window.location.search);
        const keys   = [
            'exam','exam_type','exam_label',
            'language','language_label',
            'material','material_label',
            'date','time','location','province',
            'price','spots'
        ];
        gekozenPlanning = {};
        keys.forEach(k => { if (params.has(k)) gekozenPlanning[k] = params.get(k); });
    }

    function formatNum(n) {
        return n.toFixed(2).replace('.', ',');
    }

    // Show step 1 or 2 by toggling visibility directly
    function showStep(step) {
        if (step == 2) {
            $('#step-1').hide();
            $('#step-2').show();
            $('.pontifex-oi-stepper').text('Stap 2: Bestellen & Inschrijven');
            history.replaceState(null, '', window.location.pathname + '?step=2');
        } else {
            $('#step-2').hide();
            $('#step-1').show();
            $('.pontifex-oi-stepper').text('Stap 1: Examen & planning');
            history.replaceState(null, '', window.location.pathname);
        }
    }

    function getStepFromUrl() {
        const url = new URL(window.location.href);
        return url.searchParams.get('step') || '1';
    }

    // ===================== STEP 1 (PLANNING) =====================
    if (isPlanningPage) {

        // ARIA live region
        if (!$('.pontifex-oi-aria-live').length) {
            $('<div>', {
                class: 'pontifex-oi-aria-live',
                'aria-live': 'polite',
                'aria-atomic': 'true',
                style: 'position:absolute; width:1px; height:1px; overflow:hidden; clip:rect(1px,1px,1px,1px);'
            }).appendTo('body');
        }

        // Filters
        $('.pontifex-oi-filters').on('change', '.pontifex-oi-filter', debounce(function () {
            const name = $(this).attr('name');
            if (dependencies[name]) updateDependentFilters(name);

            // Voeg de filters toe aan de URL voordat we de tabel bijwerken
            const urlParams = new URLSearchParams(window.location.search);
            $('.pontifex-oi-filter').each(function() {
                const filterName = $(this).attr('name');
                const filterValue = $(this).val();
                urlParams.set(filterName, filterValue); // Update de filterwaarde
            });
            window.history.replaceState({}, '', '?' + urlParams.toString()); // Update de URL met de nieuwe filters

            updatePontifexTable();
        }, 250));

        // Update betaling bij "Kandidaat aanmelden"
        $(document).on('click', '.pontifex-oi-aanmelden', function (e) {
            e.preventDefault();

            let params = {};

            // data-* attributes uit de link
            $.each(this.attributes, function () {
                if (this.name.indexOf('data-') === 0) {
                    const key = this.name.replace('data-', '');
                    params[key] = this.value;
                }
            });

            // Labels uit selects
            const getLabel = (name) => {
                const $opt = $(`select[name="${name}"] option:selected`);
                return $opt.length ? $opt.text() : '';
            };

            params.exam_label     = getLabel('exam_type');
            params.language_label = getLabel('language');
            let matLabel          = getLabel('material');
            if (!matLabel || matLabel.trim() === '') matLabel = 'Geen keuze';
            params.material_label = matLabel;

            // Toevoegen van payment_amount
            params.payment_amount = $('#payment_amount').val();

            // Verder met betaling
            window.location.href = registrationPageUrl + '?' + $.param(params);
        });

        // Pagination
        $('.pontifex-oi-pagination-wrapper').on('click', 'nav a', function (e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page) updatePontifexTable(page);
        });

        function updatePontifexTable(page = 1) {
            const $form   = $('.pontifex-oi-filters');
            const filters = {};

            $form.find('.pontifex-oi-filter').each(function () {
                filters[$(this).attr('name')] = $(this).val();
            });
            filters.per_page = $('#pontifex-oi-results-per-page').val();
            filters.page     = page;

            $('.pontifex-oi-table tbody').html('<tr><td colspan="7" class="pontifex-oi-loading">Laden...</td></tr>');
            $('.pontifex-oi-aria-live').text('Gegevens worden geladen, even geduld a.u.b.');

            $.ajax({
                url: ajaxUrl,
                method: 'POST',
                dataType: 'json',
                data: { action: 'pontifex_oi_get_planning', filters },
                success: function (response) {
                    if (response.success && response.data && Array.isArray(response.data.planning) && response.data.planning.length) {
                        let rows = '';
                        $.each(response.data.planning, function (i, row) {
                            let dataAttrs = '';
                            Object.keys(row).forEach(function (key) {
                                dataAttrs += ' data-' + key + '="' + (row[key] !== null ? String(row[key]).replace(/"/g, '&quot;') : '') + '"';
                            });

                            rows += '<tr>' +
                                      '<td>' + (row.date     || '') + '</td>' +
                                      '<td>' + (row.time     || '') + '</td>' +
                                      '<td>' + (row.location || '') + '</td>' +
                                      '<td>' + (row.province || '') + '</td>' +
                                      '<td>' + (row.spots    || '') + '</td>' +
                                      '<td>' + (row.price    || '') + '</td>' +
                                      '<td>' + (
                                          row.spots && row.spots.toLowerCase() !== 'vol'
                                              ? '<a href="#" class="pontifex-oi-aanmelden"' + dataAttrs + '>Kandidaat aanmelden</a>'
                                              : '<span class="pontifex-oi-vol">VOL</span>' 
                                      ) + '</td>' +
                                    '</tr>';
                        });

                        $('.pontifex-oi-table tbody').html(rows);
                        $('.pontifex-oi-aria-live').text(response.data.planning.length + ' resultaten geladen.');

                        updatePagination(response.data.current_page || 1, response.data.total_pages || 1);
                    } else {
                        $('.pontifex-oi-table tbody').html('<tr><td colspan="7">Geen resultaten gevonden voor deze filters.</td></tr>');
                        $('.pontifex-oi-aria-live').text('Geen resultaten gevonden.');
                        updatePagination(1, 1);
                    }
                },
                error: function (xhr) {
                    console.error('AJAX error:', xhr.status, xhr.responseText);
                    $('.pontifex-oi-table tbody').html('<tr><td colspan="7">Fout bij laden van data.</td></tr>');
                    $('.pontifex-oi-aria-live').text('Fout bij laden van data.');
                }
            });
        }

        function updatePagination(current, total) {
            const $nav = $('.pontifex-oi-pagination-wrapper nav');
            if (!$nav.length) return;

            const windowSize = 1;
            const start = Math.max(2, current - windowSize);
            const end   = Math.min(total - 1, current + windowSize);

            let html = '';

            html += (current > 1)
                ? '<a href="#" data-page="' + (current - 1) + '" class="pontifex-oi-page-prev">&laquo;</a>'
                : '<span class="pontifex-oi-page-disabled">&laquo;</span>';

            html += '<a href="#" data-page="1" class="' + (current === 1 ? 'pontifex-oi-page-active' : '') + '">1</a>';

            if (start > 2) html += '<span>...</span>';

            for (let i = start; i <= end; i++) {
                html += '<a href="#" data-page="' + i + '" class="' + (current === i ? 'pontifex-oi-page-active' : '') + '">' + i + '</a>';
            }

            if (end < total - 1) html += '<span>...</span>';

            if (total > 1) {
                html += '<a href="#" data-page="' + total + '" class="' + (current === total ? 'pontifex-oi-page-active' : '') + '">' + total + '</a>';
            }

            html += (current < total)
                ? '<a href="#" data-page="' + (current + 1) + '" class="pontifex-oi-page-next">&raquo;</a>'
                : '<span class="pontifex-oi-page-disabled">&raquo;</span>';

            $nav.html(html);
        }

        // Klik "Kandidaat aanmelden"
        $(document).on('click', '.pontifex-oi-aanmelden', function (e) {
            e.preventDefault();

            let params = {};

            // data-* attributes uit de link
            $.each(this.attributes, function () {
                if (this.name.indexOf('data-') === 0) {
                    const key = this.name.replace('data-', '');
                    params[key] = this.value;
                }
            });

            // Labels uit selects
            const getLabel = (name) => {
                const $opt = $(`select[name="${name}"] option:selected`);
                return $opt.length ? $opt.text() : '';
            };

            params.exam_label     = getLabel('exam_type');
            params.language_label = getLabel('language');
            let matLabel          = getLabel('material');
            if (!matLabel || matLabel.trim() === '') matLabel = 'Geen keuze';
            params.material_label = matLabel;

            // Filters optioneel toevoegen (overschrijven voorkomen)
            $('.pontifex-oi-filter').each(function () {
                const n = $(this).attr('name');
                const v = $(this).val();
                if (!params.hasOwnProperty(n) || params[n] === '') {
                    if (v !== '') params[n] = v;
                }
            });

            if (bothStepsSamePage) {
                // Geen redirect, maar stap 2 tonen
                gekozenPlanning = params;
                showStep(2);
                fillOrderSummary();
            } else {
                // Losse inschrijfpagina
                const query = $.param(params);
                window.location.href = registrationPageUrl + '?' + query;
            }
        });

        // Init showStep als beide stappen op één pagina staan
        if (bothStepsSamePage) {
            showStep(getStepFromUrl());
        }
    }

    // ===================== STEP 2 (REGISTRATION) =====================
    if (isRegistrationPage || bothStepsSamePage) {

        // Kandidaten toevoegen/verwijderen
        let candidateCount  = $('.pontifex-oi-candidate-row').length || 1;
        const maxCandidates = 4;
        
        $('.pontifex-oi-candidate-addrow').on('click keydown', '.pontifex-oi-add-candidate', function (e) {
            if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ') return;
            e.preventDefault();
            if (candidateCount >= maxCandidates) return;
            candidateCount++;
        
            const idx = candidateCount;
            const row = `
                <div class="pontifex-oi-candidate-row">
                    <div>
                        <label for="candidate_fullname_${idx}">Naam en achternaam <span class="required">*</span></label>
                        <input type="text" id="candidate_fullname_${idx}" name="candidate_fullname[]" required placeholder="Bijv. Jan Jansen">
                    </div>
                    <div>
                        <input type="text" placeholder="Tussenvoegsel (optioneel)" name="candidate_infix[]">
                    </div>
                    <div>
                        <input type="text" placeholder="Achternaam" name="candidate_lastname[]" required>
                    </div>
                    <div style="position:relative; min-width:180px;">
                        <label for="candidate_birthdate_${idx}">Geboortedatum <span class="required">*</span></label>
                        <input type="date" id="candidate_birthdate_${idx}" name="candidate_birthdate[]" required placeholder="jjjj-mm-dd">
                        <button type="button" class="pontifex-oi-remove-candidate" title="Kandidaat verwijderen">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            `;
            $('.pontifex-oi-candidates-list').append(row);
            if (candidateCount >= maxCandidates) $('.pontifex-oi-add-candidate').hide();
            updateRemoveButtons();
            fillOrderSummary();
        });
        
        // Verwijder kandidaat
        $(document).on('click', '.pontifex-oi-remove-candidate', function (e) {
            e.preventDefault();
            $(this).closest('.pontifex-oi-candidate-row').remove();
            candidateCount--;
            if (candidateCount < maxCandidates) $('.pontifex-oi-add-candidate').show();
            updateRemoveButtons();
            fillOrderSummary();
        });
        
        function updateRemoveButtons() {
            $('.pontifex-oi-candidate-row .pontifex-oi-remove-candidate').hide();
            if ($('.pontifex-oi-candidate-row').length > 1) {
                $('.pontifex-oi-candidate-row .pontifex-oi-remove-candidate').show();
            }
        }

        function fillOrderSummary() {
            if (!Object.keys(gekozenPlanning).length) return;

            const btwRate = 0.21;
            const aantal  = $('.pontifex-oi-candidate-row').length || 1;

            const examTxt = gekozenPlanning.exam_label     || gekozenPlanning.exam_type || gekozenPlanning.exam || '';
            const langTxt = gekozenPlanning.language_label || gekozenPlanning.language  || '';
            const matTxt  = (gekozenPlanning.material_label && gekozenPlanning.material_label.trim() !== '') ? gekozenPlanning.material_label : 'Geen keuze';
            const locTxt  = gekozenPlanning.location || '';
            const dateTxt = gekozenPlanning.date     || '';
            const timeTxt = gekozenPlanning.time     || '';

            let unitPrice = parseFloat(String(gekozenPlanning.price || '')
                .replace('€','').replace(/\s/g,'').replace(',','.')); 

            let prijsExcl = '', btwBedrag = '', totaal = ''; 
            if (!isNaN(unitPrice)) {
                const excl = unitPrice * aantal;
                const btw  = excl * btwRate;
                const tot  = excl + btw;

                prijsExcl = formatNum(excl);
                btwBedrag = formatNum(btw);
                totaal    = formatNum(tot);
            }

            const html = ` 
                <h2 class="pontifex-oi-section-label">Betaalgegevens</h2>
                <div class="besteloverzicht-stap2">
                    <div class="bo-item"><strong>Examen:</strong>       <span>${examTxt}</span></div>
                    <div class="bo-item"><strong>Taal:</strong>          <span>${langTxt}</span></div>
                    <div class="bo-item"><strong>Lesmateriaal:</strong>  <span>${matTxt}</span></div>
                    <div class="bo-item"><strong>Locatie:</strong>       <span>${locTxt}</span></div>
                    <div class="bo-item"><strong>Datum:</strong>         <span>${dateTxt}</span></div>
                    <div class="bo-item"><strong>Tijd:</strong>          <span>${timeTxt}</span></div>

                    <div class="bo-item"><strong>Aantal:</strong>        <span>${aantal}</span></div>
                    <div class="bo-item"><strong>Prijs:</strong>         <span>${prijsExcl}</span></div>
                    <div class="bo-item"><strong>BTW (21%):</strong>     <span>${btwBedrag}</span></div>
                    <div class="bo-item totaal"><strong>Totaal:</strong> <span>${totaal}</span></div>
                </div>

                <div class="pontifex-oi-terms">
                    <label>
                        <input type="checkbox" id="pontifex-oi-accept" required>
                        Door je inschrijving ga je akkoord met onze
                        <a href="https://certirpo.conceptwebactueel-6.nl/algemene-voorwaarden/" target="_blank" rel="noopener">algemene voorwaarden</a>.
                    </label>
                </div>
                <button type="submit" class="pontifex-oi-submit" disabled>Inschrijven</button>
            `;
            $('.pontifex-oi-order-summary').html(html);
        }

        // Checkbox enable submit
        $(document).on('change', '#pontifex-oi-accept', function () {
            $('.pontifex-oi-submit').prop('disabled', !this.checked);
        });

        // Terug naar planning
        $(document).on('click keydown', '.pontifex-oi-back-link', function (e) {
            if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ') return;
            e.preventDefault();
            if (bothStepsSamePage) {
                showStep(1);
            } else {
                window.location.href = planningPageUrl;
            }
        });

        // Init voor losse registratiepagina
        if (isRegistrationPage) {
            readParamsToPlanning();
            updateRemoveButtons();
            fillOrderSummary();
        }
    }
});