/* global PontifexOiAjax */
jQuery(function ($) {
    'use strict';

    // ===================== CONFIG & GLOBALS =====================
    const ajaxUrl = (typeof PontifexOiAjax !== 'undefined') ? PontifexOiAjax.ajax_url : '';
    const registrationPageUrl = '/cursus-inschrijven/';
    const planningPageUrl = '/cursus-zoeken/';

    let gekozenPlanning = {};

    // Alle mogelijke lesmateriaal opties (uit backend)
    const materialOptions = {};
    $('select[name="material"] option').each(function() {
        materialOptions[$(this).val()] = $(this).text();
    });

    const examWeekend = ['vca-basis-weekend', 'vca-vol-weekend'];
    const materialTaalMatrix = {
        'nl': ['1', '2', '4', '5', '6', '7'],
        'en': ['1', '4', '5', '7'],
        '':   ['1', '2', '4', '5', '6', '7']
    };
    const materialWeekend = ['1', '4'];

    if (typeof window._pontifex_first_load === 'undefined') {
        window._pontifex_first_load = true;
    }

    // ---- BEGIN: KEUZES ONTHOUDEN EN STANDAARDEN ----

    function saveFilterState() {
        localStorage.setItem('exam_type', $('select[name="exam_type"]').val());
        localStorage.setItem('language', $('select[name="language"]').val());
        localStorage.setItem('material', $('select[name="material"]').val());
    }

    function loadFilterState() {
        const examStored = localStorage.getItem('exam_type');
        if (examStored && $('select[name="exam_type"] option[value="' + examStored + '"]').length) {
            $('select[name="exam_type"]').val(examStored);
        }

        const langStored = localStorage.getItem('language');
        if (langStored && $('select[name="language"] option[value="' + langStored + '"]').length) {
            $('select[name="language"]').val(langStored);
        }

        const matStored = localStorage.getItem('material');
        if (matStored && $('select[name="material"] option[value="' + matStored + '"]').length) {
            $('select[name="material"]').val(matStored);
        }
    }

    // Zet bij eerste binnenkomst de defaults indien localStorage leeg of ongeldig is
    function setDefaultFiltersIfNeeded() {
        const examStored = localStorage.getItem('exam_type');
        if (!examStored || !$('select[name="exam_type"] option[value="' + examStored + '"]').length) {
            $('select[name="exam_type"]').val('los-examen-vca-basis');
        }

        const langStored = localStorage.getItem('language');
        if (!langStored || !$('select[name="language"] option[value="' + langStored + '"]').length) {
            $('select[name="language"]').val('nl');
        }

        const matStored = localStorage.getItem('material');
        if (!matStored || !$('select[name="material"] option[value="' + matStored + '"]').length) {
            $('select[name="material"]').val('1');
        }
    }

    // ---- EINDE ONTHOUDEN ----

    // ------------------ Core filter functie -------------------
    function updateFiltersState() {
        const $exam = $('select[name="exam_type"]');
        const $lang = $('select[name="language"]');
        const $mat  = $('select[name="material"]');

        const examVal    = $exam.val();
        const langVal    = $lang.val();
        const currentMat = $mat.val();

        if (window._pontifex_is_updating) return;
        window._pontifex_is_updating = true;

        if (!examVal) {
            $lang.val('').prop('disabled', true).find('option').show();
            $mat.val('').prop('disabled', true).find('option').show();
            updateFilterCombinationPrice();
            window._pontifex_is_updating = false;
            saveFilterState();
            return;
        }

        $lang.prop('disabled', false);
        if (examWeekend.includes(examVal)) {
            $lang.find('option').each(function() {
                const v = $(this).val();
                $(this).toggle(v === '' || v === 'nl');
            });
            if (langVal !== 'nl') $lang.val('nl').trigger('change');
        } else {
            $lang.find('option').show();
            if (!langVal) $lang.val('');
        }

        $mat.prop('disabled', false);
        let allowed = materialTaalMatrix[$lang.val()] || materialTaalMatrix[''];
        if (examWeekend.includes(examVal)) allowed = materialWeekend;

        $mat.empty();
        if (materialOptions['']) {
            $mat.append($('<option>', { value:'', text: materialOptions[''] }));
        }
        $.each(materialOptions, function(val, txt) {
            if (val && allowed.includes(val)) {
                $mat.append($('<option>', { value:val, text:txt }));
            }
        });

        if (examWeekend.includes(examVal)) {
            const first = allowed.find(v => v) || '';
            $mat.val(first);
        } else {
            if (allowed.includes(currentMat)) {
                $mat.val(currentMat);
            } else if (window._pontifex_first_load) {
                const first = allowed.find(v => v) || '';
                $mat.val(first);
            } else {
                $mat.val('');
            }
        }

        $mat.trigger('change');
        window._pontifex_first_load = false;
        updateFilterCombinationPrice();
        window._pontifex_is_updating = false;

        saveFilterState();
    }

    // === Initialiseren ===
    loadFilterState();
    setDefaultFiltersIfNeeded();
    updateFiltersState();
    updateAllDynamicPrices();

    // === Event listeners ===
    $(document).on('change', 'select[name="exam_type"], select[name="language"], select[name="material"]', function() {
        updateFiltersState();
        updateAllDynamicPrices();
        updateFilterCombinationPrice();
        saveFilterState();
    });

    // ===================== HELPERS =====================
    function debounce(fn, delay) {
        let timer = null;
        return function() {
            clearTimeout(timer);
            timer = setTimeout(() => fn.apply(this, arguments), delay);
        };
    }

    function fetchPrice(exam, lang, mat, cb) {
        $.ajax({
            url: ajaxUrl,
            method: 'POST',
            dataType: 'json',
            data: {
                action: 'pontifex_oi_get_price',
                exam_type: exam,
                language: lang,
                material: mat
            },
            success(resp) {
                cb(resp.success && resp.data && resp.data.price ? resp.data.price : '');
            },
            error() {
                cb('');
            }
        });
    }

    // ===================== FILTERCOMBI PRIJS =====================
    function updateFilterCombinationPrice() {
        const exam     = $('select[name="exam_type"]').val();
        const language = $('select[name="language"]').val();
        const material = $('select[name="material"]').val();
        const $span    = $('.pontifex-oi-dynamic-price-filters');

        if (!$span.length) return;

        $span.html('<span class="pontifex-oi-price-loader" style="min-width:40px;">...</span>');

        fetchPrice(exam, language, material, price => {
            if (price && price !== '0' && price !== '0,00' && price !== '€0,00') {
                $span.html(price);
            } else if (!exam) {
                $span.html('-');
            } else {
                $span.html('Niet beschikbaar');
            }
        });
    }

    // ===================== DYNAMISCHE PRIJZEN IN TABEL =====================
    function updateAllDynamicPrices() {
        const exam     = $('select[name="exam_type"]').val();
        const language = $('select[name="language"]').val();
        const material = $('select[name="material"]').val();

        $('.pontifex-oi-dynamic-price').each(function() {
            const $span = $(this);
            const finalExam = exam || $span.data('exam') || '';
            const finalLang = language || $span.data('language') || '';
            const finalMat = material || $span.data('material') || '';

            $span.html('<span class="pontifex-oi-price-loader" style="min-width:40px;">...</span>');

            fetchPrice(finalExam, finalLang, finalMat, price => {
                if (price && price !== '0' && price !== '0,00') {
                    $span.html(price);
                } else {
                    $span.html('-');
                }
            });
        });
    }

    // ===================== STEP 1 (PLANNING) =====================
    const hasStep1           = $('#step-1').length > 0;
    const hasStep2           = $('#step-2').length > 0;
    const bothStepsSamePage  = hasStep1 && hasStep2;
    const isPlanningPage     = $('.pontifex-oi-filters').length > 0;
    const isRegistrationPage = hasStep2 && !hasStep1;

    if (isPlanningPage) {
        // a11y live-region
        if (!$('.pontifex-oi-aria-live').length) {
            $('<div>', {
                class: 'pontifex-oi-aria-live',
                'aria-live': 'polite',
                'aria-atomic': 'true',
                style: 'position:absolute;clip:rect(1px,1px,1px,1px);width:1px;height:1px;overflow:hidden;'
            }).appendTo('body');
        }

        $('.pontifex-oi-filters').on('change', '.pontifex-oi-filter', debounce(function() {
            const name = $(this).attr('name');
            if (name === 'exam_type' || name === 'language') getSelectData(name);

            const params = new URLSearchParams(window.location.search);
            $('.pontifex-oi-filter').each(function() {
                const v = $(this).val();
                v ? params.set($(this).attr('name'), v) : params.delete($(this).attr('name'));
            });
            history.replaceState(null, '', '?' + params);
            updatePontifexTable();
        }, 250));

        $(document).on('click', '.pontifex-oi-reset-filter', function(e) {
            e.preventDefault();
            // Reset filters to 'Toon alles'
            $('select[name="month"], select[name="province"], select[name="location"], select[name="timeslot"]').each(function() {
                $(this).val('').trigger('change');
            });
            history.replaceState(null, '', location.pathname);
            updatePontifexTable(1); // Re-fetch table data after reset
        });

        $('.pontifex-oi-pagination-wrapper').on('click', 'nav a', function(e) {
            e.preventDefault();
            updatePontifexTable($(this).data('page'));
        });

        function updatePontifexTable(page = 1) {
            const filters = {};
            $('.pontifex-oi-filter').each(function() {
                const v = $(this).val();
                if (v) filters[$(this).attr('name')] = v;
            });
            filters.per_page = $('#pontifex-oi-results-per-page').val();
            filters.page = page;

            $('.pontifex-oi-table tbody').html('<tr><td colspan="7" class="pontifex-oi-loading">Laden…</td></tr>');
            $('.pontifex-oi-aria-live').text('Laden, even geduld aub…');

            $.post(ajaxUrl, { action: 'pontifex_oi_get_planning', filters }, function(resp) {
                if (resp.success && resp.data.planning.length) {
                    let rows = '';
                    resp.data.planning.forEach(row => {
                        let attrs = '';
                        Object.entries(row).forEach(([k, v]) => {
                            attrs += ` data-${k}="${v || ''}"`;
                        });

                        const currentExam = row.exam || filters.exam_type || '';
                        const currentLang = row.language || filters.language || '';
                        const currentMat = row.material || filters.material || '';

                        rows += `
                        <tr>
                          <td>${row.date || ''}</td>
                          <td>${row.time || ''}</td>
                          <td>${row.location || ''}</td>
                          <td>${row.province || ''}</td>
                          <td>${row.spots || ''}</td>
                          <td>
                            <span class="pontifex-oi-dynamic-price"
                                  data-date="${row.date || ''}"
                                  data-time="${row.time || ''}"
                                  data-location="${row.location || ''}"
                                  data-exam="${currentExam}"
                                  data-language="${currentLang}"
                                  data-material="${currentMat}">
                              <span class="pontifex-oi-price-loader" style="min-width:40px;">…</span>
                            </span>
                          </td>
                          <td>${row.spots && row.spots.toLowerCase() !== 'vol'
                ? `<a href="#" class="pontifex-oi-aanmelden"${attrs}>Kandidaat aanmelden</a>`
                : `<span class="pontifex-oi-vol">VOL</span>`}
                          </td>
                        </tr>`;
                    });
                    $('.pontifex-oi-table tbody').html(rows);
                    $('.pontifex-oi-aria-live').text(`${resp.data.planning.length} resultaten geladen.`);
                    updatePagination(resp.data.current_page, resp.data.total_pages);

                    // Prijzen updaten na tabel update
                    setTimeout(() => {
                        updateAllDynamicPrices();
                    }, 100);
                } else {
                    $('.pontifex-oi-table tbody').html('<tr><td colspan="7">Geen resultaten gevonden.</td></tr>');
                    $('.pontifex-oi-aria-live').text('Geen resultaten gevonden.');
                    updatePagination(1, 1);
                }
            }, 'json');
        }

        function updatePagination(cur, tot) {
            const $nav = $('.pontifex-oi-pagination-wrapper nav');
            if (!$nav.length) return;
            let html = '';
            html += cur > 1 ? `<a href="#" data-page="${cur - 1}">&laquo;</a>` : '<span>&laquo;</span>';
            html += `<a href="#" data-page="1"${cur === 1 ? ' class="pontifex-oi-page-active"' : ''}>1</a>`;
            const start = Math.max(2, cur - 1), end = Math.min(tot - 1, cur + 1);
            if (start > 2) html += '<span>…</span>';
            for (let i = start; i <= end; i++) {
                html += `<a href="#" data-page="${i}"${cur === i ? ' class="pontifex-oi-page-active"' : ''}>${i}</a>`;
            }
            if (end < tot - 1) html += '<span>…</span>';
            if (tot > 1) html += `<a href="#" data-page="${tot}"${cur === tot ? ' class="pontifex-oi-page-active"' : ''}>${tot}</a>`;
            html += cur < tot ? `<a href="#" data-page="${cur + 1}">&raquo;</a>` : '<span>&raquo;</span>';
            $nav.html(html);
        }
    }

    // ===================== STEP 2 (REGISTRATION) =====================
    if (isRegistrationPage || bothStepsSamePage) {
        // Functie om parameters uit URL te lezen en formuliervelden te vullen
        function fillRegistrationFormFromUrl() {
            const params = new URLSearchParams(window.location.search);
            const fields = ['exam_type', 'language', 'material', 'date', 'time', 'location', 'province', 'spots', 'price'];
            fields.forEach(field => {
                const val = params.get(field);
                if (val !== null && $(`#${field}`).length) {
                    $(`#${field}`).val(val);
                }
            });
        }
        fillRegistrationFormFromUrl();
    }

    // Hulpfunctie om geselecteerde optie terug te geven
    function getSelectData(name, fallback = '') {
        const $select = $(`select[name="${name}"]`);
        const $options = $select.find('option');
        let $selectedOption = $select.find('option:selected');

        if ($selectedOption.length === 0 || ($selectedOption.val() === '' && name !== 'material')) {
            const $firstValidOption = $options.filter(function() {
                return $(this).val() !== '';
            }).first();

            if ($firstValidOption.length) {
                $firstValidOption.prop('selected', true);
                $selectedOption = $firstValidOption;
                $select.trigger('change');
            } else {
                $selectedOption = $options.first();
            }
        }

        return {
            value: $selectedOption.val() || '',
            label: $selectedOption.text() || fallback
        };
    }

    // Hulpfunctie voor getallen formatteren
    function formatNum(n) {
        return n.toFixed(2).replace('.', ',');
    }

    // Functie om stappen te tonen (1 of 2)
    function showStep(step) {
        if (step == 2) {
            $('#step-1').hide();
            $('#step-2').show();
            $('.pontifex-oi-stepper').text('Stap 2: Bestellen & Inschrijven');
            history.replaceState(null, '', window.location.pathname + '?step=2');
        } else {
            $('#step-2').hide();
            $('#step-1').show();
            $('.pontifex-oi-stepper').text('Stap 1: Examen & planning');
            history.replaceState(null, '', window.location.pathname);
        }
    }

    // Functie om stap uit URL te lezen
    function getStepFromUrl() {
        const url = new URL(window.location.href);
        return url.searchParams.get('step') || '1';
    }

    // Prevent infinite redirects
    let isRedirecting = false;

    // Event listener voor de "Kandidaat aanmelden" knop
    $(document).on('click', '.pontifex-oi-aanmelden', function(e) {
        e.preventDefault();

        if (isRedirecting) return;
        isRedirecting = true;

        // PAK HIER DE FILTERSELECTS BOVENAAN!
        const examVal = $('#exam_type-select').val() || '';
        const langVal = $('#language-select').val() || '';
        const matVal = $('#material-select').val() || '';

        // Haal de gegevens van de geselecteerde rij op
        const rowData = $(this).closest('tr');
        const urlParams = new URLSearchParams(window.location.search);

        urlParams.set('exam_type', examVal);
        urlParams.set('language', langVal);
        urlParams.set('material', matVal);
        urlParams.set('date', rowData.find('td').eq(0).text().trim());
        urlParams.set('time', rowData.find('td').eq(1).text().trim());
        urlParams.set('location', rowData.find('td').eq(2).text().trim());
        urlParams.set('province', rowData.find('td').eq(3).text().trim());
        urlParams.set('spots', rowData.find('td').eq(4).text().trim());
        urlParams.set('price', rowData.find('.pontifex-oi-dynamic-price').text().trim());

        window.location.href = registrationPageUrl + '?' + urlParams.toString();
    });

    // Functie om de parameters uit de URL te lezen en in te vullen op de registratiepagina
    function readParamsToPlanning() {
        const params = new URLSearchParams(window.location.search);
        gekozenPlanning = {
            exam_type: params.get('exam_type') || '',
            exam_label: params.get('exam_label') || '',
            language: params.get('language') || '',
            language_label: params.get('language_label') || '',
            material: params.get('material') || '',
            material_label: params.get('material_label') || '',
            date: params.get('date') || '',
            time: params.get('time') || '',
            location: params.get('location') || '',
            province: params.get('province') || '',
            spots: params.get('spots') || '',
            price: params.get('price') || ''
        };
    }

    // Lees de URL parameters als de pagina geladen wordt
    if (window.location.pathname === registrationPageUrl) {
        readParamsToPlanning();
        updateRegistrationPage();
    }

    // Functie om de gegevens in Stap 2 in te vullen
    function updateRegistrationPage() {
        if (gekozenPlanning) {
            $('#exam_type').val(gekozenPlanning.exam_type);
            $('#language').val(gekozenPlanning.language);
            $('#material').val(gekozenPlanning.material);
            $('#date').val(gekozenPlanning.date);
            $('#time').val(gekozenPlanning.time);
            $('#location').val(gekozenPlanning.location);
            $('#province').val(gekozenPlanning.province);
            $('#spots').val(gekozenPlanning.spots);
            $('#price').val(gekozenPlanning.price);
        }
    }

    // ===================== MOLLIE BETALING: BESTELLING PLAATSEN BUTTON =====================
    $(document).on('click', '.pontifex-oi-submit-order', function(e) {
        e.preventDefault();

        var $btn = $(this);
        var $form = $btn.closest('form');

        // Verwijder oude validatie styling
        $form.find('input, select, textarea').removeClass('invalid-field');

        // Validatie: verplichte velden checken
        var isValid = true;
        var firstInvalid = null;

        // Zoek alle verplichte velden binnen het formulier
        $form.find('[required]').each(function() {
            var $field = $(this);
            var val = $field.val();

            // Check op leeg (trim voor tekstvelden)
            if (typeof val === 'string' && val.trim() === '') {
                isValid = false;
                $field.addClass('invalid-field');
                if (!firstInvalid) {
                    firstInvalid = $field;
                }
            }
        });

        if (!isValid) {
            alert('Vul alle verplichte velden correct in.');
            if (firstInvalid) firstInvalid.focus();
            return; // Stop uitvoering hier
        }

        // Check of bedrag geldig is
        var amountRaw = $form.find('#payment_amount').val() || '';
        var amount = (typeof amountRaw === 'string')
            ? parseFloat(amountRaw.replace(',', '.').replace('€','').replace(/[^0-9.]/g, ''))
            : parseFloat(amountRaw);

        if (!amount || isNaN(amount) || amount < 1) {
            alert('Geen geldig bedrag gevonden om te betalen.');
            return;
        }

        $btn.prop('disabled', true).text('Even geduld…');

        // Verzamel ALLE kandidaatvelden als array
        var candidate_fullname = $('input[name="candidate_fullname[]"]').map(function(){return this.value;}).get();
        var candidate_infix = $('input[name="candidate_infix[]"]').map(function(){return this.value;}).get();
        var candidate_lastname = $('input[name="candidate_lastname[]"]').map(function(){return this.value;}).get();
        var candidate_birthdate = $('input[name="candidate_birthdate[]"]').map(function(){return this.value;}).get();

        // Verzamel overige bestelvelden
        var data = {
            action: 'pontifex_oi_process_payment',
            amount: amount,
            // Kandidaten arrays:
            candidate_fullname: candidate_fullname,
            candidate_infix: candidate_infix,
            candidate_lastname: candidate_lastname,
            candidate_birthdate: candidate_birthdate,
            // Voeg hier ALLE andere velden toe!
            order_initials: $form.find('[name="order_initials"]').val(),
            order_infix: $form.find('[name="order_infix"]').val(),
            order_lastname: $form.find('[name="order_lastname"]').val(),
            order_postcode: $form.find('[name="order_postcode"]').val(),
            order_housenumber: $form.find('[name="order_housenumber"]').val(),
            order_street: $form.find('[name="order_street"]').val(),
            order_city: $form.find('[name="order_city"]').val(),
            order_phone: $form.find('[name="order_phone"]').val(),
            order_email: $form.find('[name="order_email"]').val(),
            order_company: $form.find('[name="order_company"]').val(),
            order_vat: $form.find('[name="order_vat"]').val(),
            // Betaalgegevens uit hidden of selectvelden
            exam_type: $form.find('[name="exam_type"]').val(),
            language: $form.find('[name="language"]').val(),
            material: $form.find('[name="material"]').val(),
            date: $form.find('[name="date"]').val(),
            time: $form.find('[name="time"]').val(),
            location: $form.find('[name="location"]').val(),
            province: $form.find('[name="province"]').val(),
            spots: $form.find('[name="spots"]').val(),
            price: $form.find('[name="price"]').val()
        };

        $.ajax({
            url: PontifexOiAjax.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: data,
            success: function(resp) {
                if (resp.success && resp.data && resp.data.payment_url) {
                    window.location.href = resp.data.payment_url;
                } else {
                    alert(resp.data && resp.data.message ? resp.data.message : 'Betaling starten is mislukt. Probeer het later nog eens.');
                    $btn.prop('disabled', false).text('Bestelling plaatsen');
                }
            },
            error: function() {
                alert('Er ging iets mis bij het starten van de betaling. Probeer het later nog eens.');
                $btn.prop('disabled', false).text('Bestelling plaatsen');
            }
        });
    });

    // ===================== KANDIDAAT TOEVOEGEN / VERWIJDEREN + PRIJZEN UPDATEN =====================
    // Maximaal 4 kandidaten
    const maxCandidates = 4;

    function updateCandidateControls() {
        const $rows = $('.pontifex-oi-candidates-list .pontifex-oi-candidate-row');
        if ($rows.length <= 1) {
            $rows.find('.pontifex-oi-remove-candidate').hide();
        } else {
            $rows.find('.pontifex-oi-remove-candidate').show();
        }
    }

    function updateCandidateCountAndPrice() {
        const $rows = $('.pontifex-oi-candidates-list .pontifex-oi-candidate-row');
        const count = $rows.length;

        // Update teller in DOM
        $('#candidate-count').text(count);

        // Basisprijs halen (origineel, zonder rekening te houden met meerdere kandidaten)
        let basisPrijsRaw = $('#payment_amount').data('base-price');
        if (!basisPrijsRaw) {
            basisPrijsRaw = $('#payment_amount').val();
            $('#payment_amount').data('base-price', basisPrijsRaw);
        }
        let basisPrijs = parseFloat(String(basisPrijsRaw).replace(',', '.').replace(/[^0-9.]/g, ''));
        if (isNaN(basisPrijs)) basisPrijs = 0;

        const totaalPrijs = basisPrijs * count;

        // Prijs tonen in overzicht (optioneel, als je #total-price hebt)
        if ($('#total-price').length) {
            $('#total-price').text('€' + totaalPrijs.toFixed(2).replace('.', ','));
        }

        // Prijs in hidden veld updaten
        $('#payment_amount').val(totaalPrijs.toFixed(2).replace('.', ','));
    }

    // Kandidaat toevoegen knop
    $(document).on('click', '.pontifex-oi-add-candidate', function() {
        const $list = $('.pontifex-oi-candidates-list');
        const count = $list.find('.pontifex-oi-candidate-row').length;
        if (count >= maxCandidates) {
            alert('Maximaal ' + maxCandidates + ' kandidaten toegestaan.');
            return;
        }

        // Nieuwe rij klonen van de eerste rij
        const $firstRow = $list.find('.pontifex-oi-candidate-row').first();
        const $newRow = $firstRow.clone();

        // Velden leegmaken
        $newRow.find('input').val('');

        // Id's en labels updaten (voor accessibility)
        $newRow.find('label').each(function() {
            const oldFor = $(this).attr('for');
            if (oldFor) {
                const newFor = oldFor.replace(/\d+$/, count + 1);
                $(this).attr('for', newFor);
            }
        });
        $newRow.find('input').each(function() {
            const oldId = $(this).attr('id');
            if (oldId) {
                const newId = oldId.replace(/\d+$/, count + 1);
                $(this).attr('id', newId);
            }
        });

        // Knop "verwijderen" tonen
        $newRow.find('.pontifex-oi-remove-candidate').show();

        $list.append($newRow);
        updateCandidateControls();
        updateCandidateCountAndPrice();
    });

    // Kandidaat verwijderen knop
    $(document).on('click', '.pontifex-oi-remove-candidate', function() {
        const $row = $(this).closest('.pontifex-oi-candidate-row');
        $row.remove();
        updateCandidateControls();
        updateCandidateCountAndPrice();
    });

    // Init op paginalaad
    updateCandidateControls();
    updateCandidateCountAndPrice();

    // ===================== TERUG NAAR PLANNING (STAP 1) =====================
    $('#back-to-planning').on('click keypress', function(e) {
        if (e.type === 'click' || e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            $('#step-2').hide();
            $('#step-1').show();
            $('.pontifex-oi-stepper').text('Stap 1: Examen & planning');
            history.replaceState(null, '', window.location.pathname);
        }
    });

});