// pagination.js
(function(window, $) {
  'use strict';

  const PontifexOI = window.PontifexOI = window.PontifexOI || {};

  /**
   * Render paginatie HTML in de opgegeven container.
   * @param {number} curPage - De huidige pagina (1-based)
   * @param {number} totPages - Totaal aantal pagina's
   * @param {string|HTMLElement|jQuery} container - Selector of element waar de nav in moet komen (default: '.pontifex-oi-pagination-wrapper nav')
   */
  function renderPagination(curPage, totPages, container = '.pontifex-oi-pagination-wrapper nav') {
    let html = '';

    // Vorige pijl
    if (curPage > 1) {
      html += '<a href="#" data-page="' + (curPage - 1) + '" aria-label="Vorige pagina">«</a>';
    } else {
      html += '<span class="pontifex-oi-page-disabled" aria-hidden="true">«</span>';
    }

    // Toon max 7 pagina’s rondom huidige pagina
    const maxLinks = 7;
    let start = Math.max(1, curPage - Math.floor(maxLinks / 2));
    let end = Math.min(totPages, start + maxLinks - 1);
    if (end - start < maxLinks - 1) start = Math.max(1, end - maxLinks + 1);

    for (let i = start; i <= end; i++) {
      if (i === curPage) {
        html += '<a href="#" data-page="' + i + '" class="pontifex-oi-page-active">' + i + '</a>';
      } else {
        html += '<a href="#" data-page="' + i + '">' + i + '</a>';
      }
    }

    // Volgende pijl
    if (curPage < totPages) {
      html += '<a href="#" data-page="' + (curPage + 1) + '" aria-label="Volgende pagina">»</a>';
    } else {
      html += '<span class="pontifex-oi-page-disabled" aria-hidden="true">»</span>';
    }

    // Renderen in DOM
    if (typeof $ !== "undefined" && typeof container === "string") {
      $(container).html(html);
    } else if (container instanceof HTMLElement) {
      container.innerHTML = html;
    }
  }

  /**
   * Event handler voor klik op paginatie-links
   * @param {function} onPageChange - Callback met nieuwe pagina nummer
   * @param {string} container - Selector container waar event op wordt geregistreerd
   */
  function initPaginationEvents(onPageChange, container = '.pontifex-oi-pagination-wrapper nav') {
    if (typeof $ === "undefined") return;
    $(document).on('click', `${container} a[data-page]`, function (e) {
      e.preventDefault();
      const page = parseInt($(this).data('page'), 10);
      if (page && typeof onPageChange === "function") {
        onPageChange(page);
      }
    });
  }

  /**
   * Automatische init bij DOM ready: rendert paginatie en bind events
   */
  function autoInit() {
    if (typeof $ === "undefined") return;
    $(function(){
      const $table = $('#pontifex-oi-table');
      if ($table.length === 0) return;

      const curPage = parseInt($table.data('current-page'), 10) || 1;
      const totPages = parseInt($table.data('total-pages'), 10) || 1;

      PontifexOI.renderPagination(curPage, totPages);
      PontifexOI.initPaginationEvents(function(page){
        const params = new URLSearchParams(window.location.search);
        params.set('page', page);
        window.location.search = params.toString();
      });
    });
  }

  // Expose functies in globale namespace
  PontifexOI.renderPagination = renderPagination;
  PontifexOI.initPaginationEvents = initPaginationEvents;
  PontifexOI.autoInitPagination = autoInit;

  // Automatisch initialiseren
  autoInit();

})(window, window.jQuery);