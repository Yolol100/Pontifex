// assets/js/price.js
(function(window) {
  'use strict';

  const PontifexOI = window.PontifexOI = window.PontifexOI || {};

  /**
   * Parse price string naar float (bijv. "€1.234,56" → 1234.56)
   * @param {string} str
   * @returns {number}
   */
  function parsePrice(str) {
    if (!str) return 0;
    return parseFloat(str.replace(/[^\d,.-]/g, '').replace(',', '.')) || 0;
  }

  /**
   * Berekent de totaalprijs van een examen + eventueel materiaal
   * @param {string} exam - exam_type
   * @param {string} lang - taal
   * @param {string} mat  - materiaalcode
   * @returns {number}
   */
  function calculatePrice(exam, lang, mat) {
    const config = window.PontifexOIConfigData || {};
    const EXAM_PRODUCTS = config.examProducts || {};
    const MATERIAL_PRODUCTS = config.materialProducts || {};
    const MATERIAL_COMBIS = config.materialCombis || {};
    const EXAM_WEEKEND = config.examWeekend || [];

    if (EXAM_WEEKEND.includes(exam)) {
      return 245;
    }

    let total = 0;

    if (EXAM_PRODUCTS[exam]) {
      total += EXAM_PRODUCTS[exam].prices[lang] ?? EXAM_PRODUCTS[exam].prices['nl'] ?? 0;
    }

    if (!mat || mat === '1') {
      return total;
    }

    let combiKey = mat;
    if (['2', '4', '5', '6', '7'].includes(mat)) {
      const suffix = exam.includes('vca-vol') ? 'vol' : 'basis';
      combiKey = `${mat}_${suffix}`;
    }

    if (MATERIAL_COMBIS[combiKey]) {
      MATERIAL_COMBIS[combiKey].forEach(id => {
        total += MATERIAL_PRODUCTS[id]?.price ?? 0;
      });
    }

    return total;
  }

  /**
   * Haal de prijs op (lokale berekening of via AJAX indien ajaxUrl opgegeven)
   * @param {string} exam
   * @param {string} lang
   * @param {string} mat
   * @param {function} cb - callback met prijs string (bijv. "€129,00")
   * @param {string} ajaxUrl - ajax endpoint (optioneel)
   */
  function fetchPrice(exam, lang, mat, cb, ajaxUrl = '') {
    const config = window.PontifexOIConfigData || {};
    const EXAM_WEEKEND = config.examWeekend || [];

    if (EXAM_WEEKEND.includes(exam)) {
      cb('€245,00');
      return;
    }

    const localPrice = calculatePrice(exam, lang, mat);

    if (!ajaxUrl) {
      cb('€' + localPrice.toFixed(2).replace('.', ','));
      return;
    }

    // AJAX ophalen
    if (typeof window.jQuery === "undefined") {
      // fallback met fetch API
      fetch(ajaxUrl, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
          action: 'pontifex_oi_get_price',
          exam_type: exam,
          language: lang,
          material: mat
        })
      }).then(resp => resp.json()).then(resp => {
        if (resp.success && resp.data && resp.data.price && resp.data.price !== '') {
          cb(resp.data.price);
        } else {
          cb('€' + localPrice.toFixed(2).replace('.', ','));
        }
      }).catch(() => {
        cb('€' + localPrice.toFixed(2).replace('.', ','));
      });
    } else {
      // met jQuery ajax
      window.jQuery.ajax({
        url: ajaxUrl,
        method: 'POST',
        dataType: 'json',
        data: { 
          action: 'pontifex_oi_get_price', 
          exam_type: exam, 
          language: lang, 
          material: mat 
        },
        success: function (resp) {
          if (resp.success && resp.data && resp.data.price && resp.data.price !== '') {
            cb(resp.data.price);
          } else {
            cb('€' + localPrice.toFixed(2).replace('.', ','));
          }
        },
        error: function () {
          cb('€' + localPrice.toFixed(2).replace('.', ','));
        }
      });
    }
  }

  // Exporteer functies in globale namespace
  PontifexOI.calculatePrice = calculatePrice;
  PontifexOI.fetchPrice = fetchPrice;
  PontifexOI.parsePrice = parsePrice;

})(window);