<?php
/**
 * Plugin Name: Pontifex OI
 * Description: Koppeling met Pontifex Open Inschrijvingen (SOAP-API).
 * Version: 1.0.0
 * Author: [Jouw Naam]
 * Text Domain: pontifex-oi
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.1
 *
 * @package PontifexOI
 */

defined('ABSPATH') || exit;

// -- Autoload/Includes (no Composer) --
require_once __DIR__ . '/includes/api/class-soap-client.php';            // SOAP Client
require_once __DIR__ . '/includes/public/class-frontend.php';            // Frontend functionaliteit
require_once __DIR__ . '/includes/helpers/functions-select.php';         // Helper functies
require_once __DIR__ . '/includes/helpers/class-payment-helpers.php';    // Betalingshelper functies
require_once __DIR__ . '/includes/public/class-payment-success-shortcode.php'; // Betalingssucces shortcode
require_once __DIR__ . '/includes/admin/class-admin.php';                // Admin functionaliteit

// Mollie API integratie
require_once __DIR__ . '/vendor/autoload.php';  // Dit pad kan anders zijn afhankelijk van je installatie

// Prevent dubbele loading
if (defined('PONTIFEX_OI_VERSION')) {
    return;
}
define('PONTIFEX_OI_VERSION', '1.0.0');
define('PONTIFEX_OI_PATH', plugin_dir_path(__FILE__));
define('PONTIFEX_OI_URL', plugin_dir_url(__FILE__));

// Basis vertaling laden
add_action('plugins_loaded', function () {
    load_plugin_textdomain('pontifex-oi', false, basename(dirname(__FILE__)) . '/languages');
}, 1);

// Plugin bootstrapping: alles zo veel mogelijk uit main file houden
add_action('plugins_loaded', function () {
    // Start admin
    if (is_admin()) {
        if (class_exists('\PontifexOI\Admin\Admin')) {
            \PontifexOI\Admin\Admin::get_instance();
        }
    }

    // Start frontend/public óók bij AJAX
    if (class_exists('\PontifexOI\PublicPart\Frontend')) {
        \PontifexOI\PublicPart\Frontend::get_instance();
    }

    // API altijd beschikbaar (voor AJAX, REST, SOAP-ops)
    if (class_exists('\PontifexOI\Api\ApiController')) {
        \PontifexOI\Api\ApiController::get_instance();
    }

}, 20);

// Voeg de shortcode voor betalingssucces toe aan de frontend
add_action('init', function () {
    if (class_exists('\PontifexOI\PublicPart\PaymentSuccessShortcode')) {
        \PontifexOI\PublicPart\PaymentSuccessShortcode::register_shortcode();
    }
});

// Deactivation/activation hooks voor toekomstige extensies (bv. cronjobs flushen)
register_activation_hook(__FILE__, function () {
    flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('pontifex_oi_cronjob_event');
});