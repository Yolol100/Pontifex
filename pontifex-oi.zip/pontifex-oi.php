<?php
/**
 * Plugin Name: Pontifex OI
 * Description: Koppeling met Pontifex Open Inschrijvingen (SOAP-API).
 * Version: 1.0.0
 * Author: [Jouw Naam]
 * Text Domain: pontifex-oi
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.1
 *
 * @package PontifexOI
 */

defined('ABSPATH') || exit;

if (!defined('PONTIFEX_OI_VERSION')) {
    define('PONTIFEX_OI_VERSION', '1.0.0');
    define('PONTIFEX_OI_PATH', plugin_dir_path(__FILE__));
    define('PONTIFEX_OI_URL', plugin_dir_url(__FILE__));
}

// Includes
require_once PONTIFEX_OI_PATH . 'includes/api/class-soap-client.php';             // SOAP Client
require_once PONTIFEX_OI_PATH . 'includes/public/class-frontend.php';             // Frontend functionaliteit
require_once PONTIFEX_OI_PATH . 'includes/helpers/functions-select.php';          // Helper functies
require_once PONTIFEX_OI_PATH . 'includes/helpers/class-payment-helpers.php';     // Betalingshelper functies
require_once PONTIFEX_OI_PATH . 'includes/public/class-payment-success-shortcode.php'; // Betalingssucces shortcode
require_once PONTIFEX_OI_PATH . 'includes/admin/class-admin.php';                 // Admin functionaliteit

// Mollie API integratie
require_once PONTIFEX_OI_PATH . 'vendor/autoload.php';  // Pas pad aan indien nodig

// Load translations
add_action('plugins_loaded', function () {
    load_plugin_textdomain('pontifex-oi', false, basename(dirname(__FILE__)) . '/languages');
}, 1);

// Plugin bootstrap
add_action('plugins_loaded', function () {
    // Admin starten
    if (is_admin()) {
        if (class_exists('\PontifexOI\Admin\Admin')) {
            \PontifexOI\Admin\Admin::get_instance();
        }
    }

    // Frontend starten ook voor AJAX
    if (class_exists('\PontifexOI\PublicPart\Frontend')) {
        \PontifexOI\PublicPart\Frontend::get_instance();
    }

}, 20);

// Registreer betalingssucces shortcode
add_action('init', function () {
    if (class_exists('\PontifexOI\PublicPart\PaymentSuccessShortcode')) {
        \PontifexOI\PublicPart\PaymentSuccessShortcode::register_shortcode();
    }
});

// Hooks voor activation en deactivation
register_activation_hook(__FILE__, function () {
    flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('pontifex_oi_cronjob_event');
});