<?php
/**
 * Prevents direct file access.
 */
if (!defined('ABSPATH')) {
	exit;
}
/**
 * Handles the redirection for exam registration and renders the exam planning interface.
 */
// use function PontifexOI\Helpers\render_select; // DEZE REGEL IS VERWIJDERD
$registration_url = $args['registration_url'] ?? (
	function_exists('get_permalink')
	? ( ($id=(int)get_option('pontifex_oi_registration_page_id')) ? get_permalink($id) : home_url('/cursus-inschrijven/') )
	: '/cursus-inschrijven/'
);
// Afhandeling van de 'go'-redirect bij GET-request (vervolgens naar de inschrijfpagina)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['go'])) {
	$query = http_build_query(array_filter([
		'go' => 1,
		'exam_type' => $_GET['exam_type'] ?? '',
		'language' => $_GET['language'] ?? '',
		'material' => $_GET['material'] ?? '',
		'date' => $_GET['date'] ?? '',
		'time' => $_GET['time'] ?? '',
		'location' => $_GET['location'] ?? '',
		'province' => $_GET['province'] ?? '',
		'spots' => $_GET['spots'] ?? '',
		'price' => $_GET['price'] ?? '', // (laat in form leeg; server berekent)
	]));
	// Redirect naar de registratie-URL met de geselecteerde parameters
	wp_redirect( trailingslashit($registration_url) . '?' . $query );
	exit;
}
// Standaardwaarden en initialisatie van filters
$exam_type = $args['filters']['exam_type'] ?? $_GET['exam_type'] ?? 'los-examen-vca-basis';
if (empty($exam_type)) $exam_type = 'los-examen-vca-basis';
$language = $args['filters']['language'] ?? $_GET['language'] ?? 'nl';
if (empty($language)) $language = 'nl';
$material = $args['filters']['material'] ?? $_GET['material'] ?? '1';
if (empty($material)) $material = '1';
// Ophalen van filteropties
$examTypes = array_filter($args['exam_types'] ?? [], fn($et) => !empty($et['id']) || $et['id'] === '');
$languages = $args['languages'] ?? [];
$months = $args['months'] ?? [];
$provinces = $args['provinces'] ?? [];
$locations = $args['locations'] ?? [];
$timeslots = $args['timeslots'] ?? [];
// Hulpfunctie om een placeholder toe te voegen aan filter arrays
$add_placeholder = function (&$arr, $label) {
// Voorkomt dubbele placeholders als de eerste optie leeg is
	if (!isset($arr[0]) || (isset($arr[0]['id']) && $arr[0]['id'] !== '')) {
		array_unshift($arr, ['id' => '', 'name' => $label]);
	}
};
// Placeholders toevoegen aan de arrays
$add_placeholder($languages, __('Kies taal','pontifex-oi'));
$add_placeholder($months, __('Kies maand','pontifex-oi'));
$add_placeholder($provinces, __('Kies provincie','pontifex-oi'));
$add_placeholder($locations, __('Kies locatie','pontifex-oi'));
$add_placeholder($timeslots, __('Kies dagdeel','pontifex-oi'));
// Bepalen of 'material' verborgen moet worden (niet gebruikt in dit template, maar logica is aanwezig)
$hide_material = in_array($exam_type, ['vca-basis-weekend','vca-vol-weekend'], true);
// Paginatie variabelen
$current_page = $args['current_page'] ?? 1;
$total_pages = $args['total_pages'] ?? 1;
?>
<div class="pontifex-oi-stepper" role="heading" aria-level="2" tabindex="0">
	<?php esc_html_e('Stap 1: Inplannen','pontifex-oi'); ?>
</div>
<section class="pontifex-oi-section">
	<div id="step-1" class="active">
		<div class="pontifex-oi-bestellen">
			<form class="pontifex-oi-filters" method="get" action="" aria-label="<?php esc_attr_e('Filter examens en planning','pontifex-oi'); ?>">
				<div class="pontifex-oi-filter-row">
					<div class="pontifex-oi-filter-group">
						<h2 class="select-exam-label"><?php esc_html_e('Selecteer een examen','pontifex-oi'); ?></h2>
						<div class="pontifex-oi-select-row">
							<div class="pontifex-oi-filter-single">
								<label for="exam_type-select"><?php esc_html_e('Examensoort','pontifex-oi'); ?></label>
								<select id="exam_type-select" name="exam_type" class="pontifex-oi-filter" data-filter="exam_type" required>
									<option value=""><?php echo esc_html__('Kies examensoort','pontifex-oi'); ?></option>
									<?php foreach($examTypes as $opt): ?>
										<option value="<?php echo esc_attr($opt['id']); ?>"
											<?php if ($exam_type === $opt['id'] || (empty($exam_type) && $opt['name'] === 'VCA Basis')) echo 'selected'; ?>>
											<?php echo esc_html($opt['name']); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
							<div class="pontifex-oi-filter-single">
								<label for="language-select"><?php esc_html_e('Taal','pontifex-oi'); ?></label>
								<select id="language-select" name="language" class="pontifex-oi-filter" data-filter="language" required>
									<?php foreach($languages as $opt): ?>
										<option value="<?php echo esc_attr($opt['id']); ?>"
											<?php
											if ($language === $opt['id'] || (empty($language) && strtolower($opt['name']) === 'nederlands')) echo 'selected';
											?>>
											<?php echo esc_html($opt['name']); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
							<div class="pontifex-oi-filter-single">
								<label for="material-select"><?php esc_html_e('Soort examen','pontifex-oi'); ?></label>
								<select
									id="material-select"
									name="material"
									class="pontifex-oi-filter"
									data-filter="material"
									data-selected-value="<?php echo esc_attr($material); ?>"
								>
									<option value=""><?php esc_html_e('Kies soort examen','pontifex-oi'); ?></option>
								</select>
							</div>
						</div>
					</div>
				</div>
				<h2 class="select-date-label"><?php esc_html_e('Kies een datum en locatie','pontifex-oi'); ?></h2>
				<div class="pontifex-oi-filter-row -no-gap">
					<?php foreach ([
						['month','Maand',$months],
						['province','Provincie',$provinces],
						['location','Locatie',$locations],
						['timeslot','Dagdeel',$timeslots]
					] as list($field,$label,$options)): ?>
						<div class="pontifex-oi-filter-group">
							<div class="pontifex-oi-filter-single">
								<label for="<?php echo $field; ?>-select"><?php echo esc_html__($label,'pontifex-oi'); ?></label>
								<select id="<?php echo $field; ?>-select" name="<?php echo $field; ?>" class="pontifex-oi-filter" data-filter="<?php echo $field; ?>">
									<?php foreach($options as $opt): ?>
										<option value="<?php echo esc_attr($opt['id']); ?>"
											<?php selected($args['filters'][$field] ?? '', $opt['id']); ?>>
											<?php echo esc_html($opt['name']); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</form>
			<table id="pontifex-oi-table"
				class="pontifex-oi-table pontifex-oi-table-custom"
				role="table"
				data-current-page="<?php echo esc_attr($current_page); ?>"
				data-total-pages="<?php echo esc_attr($total_pages); ?>">
				<thead>
					<tr>
						<th><?php esc_html_e('Datum','pontifex-oi'); ?></th>
						<th><?php esc_html_e('Tijd','pontifex-oi'); ?></th>
						<th><?php esc_html_e('Locatie','pontifex-oi'); ?></th>
						<th><?php esc_html_e('Provincie','pontifex-oi'); ?></th>
						<th><?php esc_html_e('Plekken','pontifex-oi'); ?></th>
						<th><?php esc_html_e('Prijs','pontifex-oi'); ?></th>
						<th><?php esc_html_e('Aanmelden','pontifex-oi'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if (!empty($args['planning'])): ?>
						<?php foreach($args['planning'] as $row):
							$row_exam = !empty($row['exam']) ? $row['exam'] : $exam_type;
							$row_language = !empty($row['language']) ? $row['language'] : $language;
							$row_material = '1';
						?>
							<tr>
								<td><?php echo esc_html($row['date'] ?? '-'); ?></td>
								<td><?php echo esc_html($row['time'] ?? '-'); ?></td>
								<td><?php echo esc_html($row['location'] ?? '-'); ?></td>
								<td><?php echo esc_html($row['province'] ?? '-'); ?></td>
								<td><?php echo esc_html($row['spots'] ?? '-'); ?></td>
								<td>
									<span class="pontifex-oi-dynamic-price"
										data-date="<?php echo esc_attr($row['date'] ?? ''); ?>"
										data-time="<?php echo esc_attr($row['time'] ?? ''); ?>"
										data-location="<?php echo esc_attr($row['location'] ?? ''); ?>"
										data-exam="<?php echo esc_attr($row_exam); ?>"
										data-language="<?php echo esc_attr($row_language); ?>"
										data-material="<?php echo esc_attr($row_material); ?>">
										<span class="pontifex-oi-price-loader" aria-hidden="true">…</span>
										<span class="pontifex-oi-price-amount"></span>
									</span>
								</td>
								<td>
									<?php if (strtoupper($row['spots'] ?? '') !== 'VOL'): ?>
										<form method="get" class="pontifex-oi-aanmeld-form" action="<?php echo esc_url($registration_url); ?>">
											<input type="hidden" name="go" value="1">
											<input type="hidden" name="exam_type" value="<?php echo esc_attr($row_exam); ?>">
											<input type="hidden" name="language" value="<?php echo esc_attr($row_language); ?>">
											<input type="hidden" name="material" value="<?php echo esc_attr($row_material); ?>">
											<input type="hidden" name="date" value="<?php echo esc_attr($row['date'] ?? ''); ?>">
											<input type="hidden" name="time" value="<?php echo esc_attr($row['time'] ?? ''); ?>">
											<input type="hidden" name="location" value="<?php echo esc_attr($row['location'] ?? ''); ?>">
											<input type="hidden" name="province" value="<?php echo esc_attr($row['province'] ?? ''); ?>">
											<input type="hidden" name="spots" value="<?php echo esc_attr($row['spots'] ?? ''); ?>">
											<input type="hidden" name="price" value="" class="pontifex-oi-price-input"> <button type="submit" class="pontifex-oi-aanmelden"><?php esc_html_e('Kandidaat aanmelden','pontifex-oi'); ?></button>
										</form>
									<?php else: ?>
										<span class="pontifex-oi-vol"><?php esc_html_e('VOL','pontifex-oi'); ?></span>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php else: ?>
						<tr><td colspan="7"><?php esc_html_e('Geen resultaten gevonden','pontifex-oi'); ?></td></tr>
					<?php endif; ?>
				</tbody>
			</table>
			<div class="pontifex-oi-aria-live is-visually-hidden" aria-live="polite" aria-atomic="true"></div>
			<div id="pontifex-oi-cards-container" class="pontifex-oi-cards-container">
			</div>
			<?php
			$total = isset($args['total_results']) ? (int) $args['total_results'] : 0;
			?>
			<div class="pontifex-oi-pagination-wrapper"
				role="region"
				aria-label="<?php esc_attr_e("Navigatie resultatenpagina's",'pontifex-oi'); ?>"
				data-total-results="<?php echo esc_attr($total); ?>">
				<div class="-left">
					<label class="pontifex-oi-rows">
						<span><?php esc_html_e('Rijen per pagina','pontifex-oi'); ?></span>
						<select id="pontifex-oi-results-per-page" class="pontifex-oi-rows-select"
							aria-controls="pontifex-oi-table"
							aria-label="<?php esc_attr_e('Aantal resultaten per pagina','pontifex-oi'); ?>">
							<option value="7" <?php selected(7, (int)$args['per_page']); ?>>7</option>
							<option value="12" <?php selected(12, (int)$args['per_page']); ?>>12</option>
							<option value="25" <?php selected(25, (int)$args['per_page']); ?>>25</option>
							<option value="50" <?php selected(50, (int)$args['per_page']); ?>>50</option>
						</select>
					</label>
				</div>
				<div class="-right">
					<nav class="pontifex-oi-pagination-nav"
						aria-label="<?php echo esc_attr__('Paginanavigatie','pontifex-oi'); ?>"
						aria-live="polite"
						aria-atomic="true"></nav>
				</div>
			</div>
		</div>
	</div>
</section>