// --- Material Select Logic ---
(function(window, $) {
	'use strict';
	const cfg = window.PontifexOIConfigData || {};
	if (!window.PontifexOI) window.PontifexOI = {};
	const PontifexOI = window.PontifexOI;

	function getExam() {
		return $('select[name="exam_type"]').val() || '';
	}

	function getLanguage() {
		return $('select[name="language"]').val() || '';
	}

	function $materialSel() {
		return $('select[name="material"]');
	}

	/**
	 * 🟢 NIEUWE FUNCTIE: Selecteert alle relevante materiaal dropdowns.
	 */
	function $materialSelAll() {
		return $('#material-select, #sidebar-material, select[name="material"]'); // Voeg ook de oorspronkelijke selector toe voor compatibiliteit
	}

	function handleMaterialChange() {
		if (PontifexOI.updateAllDynamicPrices) PontifexOI.updateAllDynamicPrices();
		if (PontifexOI.updateFormInputsInTableRows) PontifexOI.updateFormInputsInTableRows();
	}

	/**
	 * 🟢 AANGEPASTE LOGICA: Interne definitie en filtering van opties.
	 * Gebruikt nu `data-selected-value` voor robuuste selectieherstel op alle elementen.
	 */
	function populateMaterialSelect() {
		// Oorspronkelijke $sel is vervangen door $all
		const $all = $materialSelAll();
		if (!$all.length) return;

		const exam = getExam();
		const lang = getLanguage() || (cfg.defaultLanguage || 'nl'); // Gebruik const voor lang

		// Basisopties hardgecodeerd
		let options = [
			{ id: '1', label: 'Los examen' },
			{ id: '2', label: 'Examen + boek' },
			{ id: '4', label: 'Examen + e-learning' },
			{ id: '5', label: 'Examen + proefexamens' },
			{ id: '6', label: 'Examen + boek + proefexamens' },
			{ id: '7', label: 'Examen + e-learning + proefexamens' }
		];

		// Weekendoptie toevoegen bij VCA Basis/VOL EN NL/EN
		const isBasisOfVol = exam === 'los-examen-vca-basis' || exam === 'los-examen-vca-vol';
		const isNlOfEn = (lang === 'nl' || lang === 'en');
		if (isBasisOfVol && isNlOfEn) {
			options.push({ id: 'cursus-weekend', label: 'Weekendcursus met examen' });
		}

		// ➤ Filter: proefexamen-opties uitsluiten bij niet-NL
		if (lang !== 'nl') {
			options = options.filter(opt => {
				const label = String(opt.label).toLowerCase();
				return !label.includes('proefexamen');
			});
		}

		// HTML bouwen: Placeholder NIET selected
		let html = '<option value="" disabled>Maak een keuze</option>';
		options.forEach(opt => {
			html += `<option value="${opt.id}">${opt.label}</option>`;
		});

		// 1. Itereer over alle select-elementen en bewaar/herstel afzonderlijk
		$all.each(function() {
			const $sel = $(this);
			const keepVal =
				$sel.val() ||
				$sel.attr('data-selected-value') ||
				''; // Controleer de huidige waarde en data-attribuut

			$sel.html(html).prop('disabled', false); // Vul de opties

			// 2. herstel indien mogelijk of selecteer placeholder
			if (keepVal && $sel.find(`option[value="${keepVal}"]`).length) {
				$sel.val(keepVal); // Herstel de eerdere/data-selected waarde
			} else {
				$sel.val(''); // Anders placeholder
			}
		});

		// De prijs-updates moeten nog steeds gebeuren, idealiter na de wijziging
		if (PontifexOI.updateAllDynamicPrices) PontifexOI.updateAllDynamicPrices();
		if (PontifexOI.updateFormInputsInTableRows) PontifexOI.updateFormInputsInTableRows();
	}

	// 1. Aangepast: if ($('.pontifex-oi-registration').length) verwijderd
	$(document).ready(() => {
		populateMaterialSelect();
		handleMaterialChange(); // ← direct initialiseren
		$materialSel().on('change', handleMaterialChange);
	});

	// Boven bestaande binds laten staan; alleen extra selectors toevoegen:

	// Her-render materiaalopties bij examenwijziging (alle varianten)
	$(document).on('change',
		'select[name="exam_type"], #exam_type-select, #sidebar-exam_type',
		function () { populateMaterialSelect(); }
	);

	// Her-render materiaalopties én extra-materiaal bij taalwijziging (alle varianten)
	$(document).on('change',
		'select[name="language"], #language-select, #sidebar-language',
		function () {
			populateMaterialSelect();
			// Extra-materiaal lijst hangt ook van taal af (proefexamens in NL)
			if (typeof renderExtraMaterial === 'function') renderExtraMaterial();
		}
	);

	$(document).on('submit', '.pontifex-oi-aanmeld-form', function() {
		const val = $materialSel().val() || '1'; // Gebruik $materialSel() om de hoofdselect te pakken, of de eerste.
		$(this).find('input[name="material"]').val(val);
	});
})(window, jQuery);

// --- Extra Material Checkboxes Logic ---
// ... (Dit blok is ongewijzigd, maar hieronder de rest van de code ter referentie) ...
(function(window, $) {
	'use strict';
	if (!$('#extra-material-checkboxes').length) {
		return;
	}

	const PontifexOI = window.PontifexOI = window.PontifexOI || {};
	const cfg = window.PontifexOIConfigData || window.PontifexOIConfig || {};
	const extraOptions = (cfg && cfg.extraOptions) || {};
	const examWeekend = ['vca-basis-weekend', 'vca-vol-weekend'];
	const $prov = $('#province');
	const $loc = $('#location');
	const $totalPrice = $('#total-price');
	const $paymentAmount = $('#payment_amount');
	const $container = $('#extra-material-checkboxes');

	const getExamLangFromDOM = () => {
		const examVal = PontifexOI.normalizeExam(
			$('select[name="exam_type"]').val() ||
			$('#exam_type').val() ||
			PontifexOI.getUrlParams().exam_type || ''
		);
		const langVal = $('select[name="language"]').val() ||
			$('#language').val() ||
			PontifexOI.getUrlParams().language || '';
		return {
			examVal,
			langVal
		};
	};

	const buildCheckboxList = (exam, lang) => {
		// extraOptions is nu flat array uit PHP → geen keys per exam/lang meer
		const raw = Object.values(extraOptions) || [];
		// Filter weekend option
		const filteredWeekend = raw.filter(opt => opt.id !== 'cursus-weekend' || PontifexOI.isWeekendAllowed(exam, lang));
		// Filter practice/proefexamens for non-NL languages (safety filter, should already be filtered by PHP/JS)
		const finalFiltered = filteredWeekend.filter(opt => {
			const isProefOpt = /proefexamen|practice/i.test(opt.id) || /proefexamen|practice/i.test(opt.label);
			if (isProefOpt && lang !== 'nl') {
				return false;
			}
			return true;
		});
		return finalFiltered;
	};

	const weekendChecked = () =>
		$('#extra-material-checkboxes input[value="cursus-weekend"]').is(':checked');

	const updateWeekendLocks = () => {
		if (!$prov.length || !$loc.length) return;
		const {
			examVal
		} = getExamLangFromDOM();
		const isBasisOfVol = examVal === 'los-examen-vca-basis' || examVal === 'los-examen-vca-vol';
		const isWeekendExamType = (examVal === 'vca-basis-weekend' || examVal === 'vca-vol-weekend');
		if ((weekendChecked() && isBasisOfVol) || isWeekendExamType) {
			if ($prov.data('prev') === undefined) $prov.data('prev', $prov.val());
			if ($loc.data('prev') === undefined) $loc.data('prev', $loc.val());
			$prov.val('Zuid-Holland');
			$loc.val('Den Haag');
			$('.besteloverzicht-stap2 .bo-item strong').each(function() {
				const label = $(this).text().trim().toLowerCase();
				if (label.startsWith('provincie')) $(this).next('span').text('Zuid-Holland');
				if (label.startsWith('locatie')) $(this).next('span').text('Den Haag');
			});
		} else {
			if ($prov.data('prev') !== undefined) $prov.val($prov.data('prev'));
			if ($loc.data('prev') !== undefined) $loc.val($loc.data('prev'));
			$prov.removeData('prev');
			$loc.removeData('prev');
			$('.besteloverzicht-stap2 .bo-item strong').each(function() {
				const label = $(this).text().trim().toLowerCase();
				if (label.startsWith('provincie')) $(this).next('span').text($prov.val() || '-');
				if (label.startsWith('locatie')) $(this).next('span').text($loc.val() || '-');
			});
		}
	};

	const updateOrderSummaryText = () => {
		const {
			examVal
		} = getExamLangFromDOM();
		const isWeekendExamType = (examVal === 'vca-basis-weekend' || examVal === 'vca-vol-weekend');
		const weekendOn = isWeekendExamType || (
			weekendChecked() && (examVal === 'los-examen-vca-basis' || examVal === 'los-examen-vca-vol')
		);
		const $targets = $('.besteloverzicht-stap2 .bo-item, .besteloverzicht .bo-item, .bo-item--exam, [data-summary="exam"]');
		$targets.each(function() {
			const $row = $(this);
			const $strong = $row.find('strong,label,.bo-label').first();
			const labelTxt = ($strong.text() || '').toLowerCase();
			if (!labelTxt.includes('examensoort') && !labelTxt.includes('examen')) return;
			const $val = $row.find('span,.bo-value').first();
			if (!$val.length) return;
			const base = $val.text().trim().replace(/\s+met.*$/i, '');
			$val.text(weekendOn ? `WeekendCursus met examen` : `${base} met examen`);
		});
	};

	const updateTotalPriceWithCheckboxes = () => {
		if (!$totalPrice.length || !$paymentAmount.length) return;
		const {
			examVal
		} = getExamLangFromDOM();
		const isWeekendExamType = (examVal === 'vca-basis-weekend' || examVal === 'vca-vol-weekend');
		const weekendOn = isWeekendExamType || (
			weekendChecked() && (examVal === 'los-examen-vca-basis' || examVal === 'los-examen-vca-vol')
		);
		let finalPrice = 0;
		if (weekendOn) {
			finalPrice = 245;
			$paymentAmount.data('base-price', '245.00');
		} else {
			let basePrice = PontifexOI.parsePrice($paymentAmount.data('original-base-price') || $paymentAmount.data('base-price') || $paymentAmount.val());
			if (!$paymentAmount.data('original-base-price')) {
				$paymentAmount.data('original-base-price', basePrice.toFixed(2));
			}
			let extraTotal = 0;
			$('.extra-material-checkbox:checked').each(function() {
				const id = String($(this).val());
				if (id !== 'cursus-weekend') {
					extraTotal += parseFloat($(this).data('price')) || 0;
				}
			});
			finalPrice = basePrice + extraTotal;
		}
		const candidateCount = $('.pontifex-oi-candidates-list .pontifex-oi-candidate-row').length || 1;
		const totalAmount = finalPrice * candidateCount;
		$totalPrice.text(`€${totalAmount.toFixed(2).replace('.', ',')}`);
		$paymentAmount.val(Number(totalAmount).toFixed(2));
		console.log('updateTotalPriceWithCheckboxes:', {
			examVal,
			weekendOn,
			finalPrice,
			candidateCount,
			totalAmount
		});
	};

	const renderExtraMaterial = () => {
		if (!$container.length) return;
		const {
			examVal,
			langVal
		} = getExamLangFromDOM();
		const options = buildCheckboxList(examVal, langVal);
		let html = '<strong>Extra lesmateriaal nodig?</strong><div>';
		if (options.length) {
			options.forEach(opt => {
				const priceStr = Number(opt.price).toFixed(2).replace('.', ',');
				html += `<label style="display:block;margin:.3em 0;">
<input type="checkbox" class="extra-material-checkbox" name="extra_options[]" value="${opt.id}" data-price="${opt.price}" aria-label="${opt.label} (€${priceStr})">
${opt.label} (€${priceStr})
</label>`;
			});
		} else {
			html += 'Geen extra lesmateriaal beschikbaar.';
		}
		html += '</div>';
		$container.html(html);
		// ⬅️ Nieuw: selecteer wat gebruiker in stap 1 koos
		const selectedFromStep1 = (new URLSearchParams(window.location.search)).get('material') || '1';
		if (selectedFromStep1 && selectedFromStep1 !== '1') {
			const $match = $container.find(`.extra-material-checkbox[value="${selectedFromStep1}"]`);
			if ($match.length) {
				$match.prop('checked', true).trigger('change');
			}
		}
		$container.show();
		$container.off('change.material').on('change.material', '.extra-material-checkbox', () => {
			const examVal = $('select[name="exam_type"]').val() || '';
			const weekendChecked = $('.extra-material-checkbox[value="cursus-weekend"]:checked').length > 0;
			const isBasisOrVol = ['los-examen-vca-basis', 'los-examen-vca-vol'].includes(examVal);
			console.log('Weekend checkbox changed:', {
				examVal,
				weekendChecked,
				isBasisOrVol
			});
			if (weekendChecked && isBasisOrVol) {
				console.log('Weekend selected - setting fixed price €245');
				const $paymentAmount = $('#payment_amount');
				if (!$paymentAmount.data('original-base-price')) {
					$paymentAmount.data('original-base-price', $paymentAmount.val());
				}
				const candidateCount = $('.pontifex-oi-candidates-list .pontifex-oi-candidate-row').length || 1;
				const weekendTotal = 245 * candidateCount;
				$('#total-price').text(`€${weekendTotal.toFixed(2).replace('.', ',')}`);
				$paymentAmount.val(weekendTotal.toFixed(2));
				$paymentAmount.data('base-price', '245.00');
				$('.pontifex-oi-dynamic-price').each(function() {
					const $el = $(this);
					$el.find('.pontifex-oi-price-amount').text('€245,00');
					$el.find('.pontifex-oi-price-loader').hide();
					$el.addClass('is-hydrated');
					const $row = $el.closest('tr, .pontifex-oi-card, .acc-item');
					const $priceInput = $row.find('input[name="price"], .pontifex-oi-price-input');
					if ($priceInput.length) {
						$priceInput.val('245.00');
					}
				});
			} else {
				console.log('Weekend deselected - restoring normal pricing');
				const $paymentAmount = $('#payment_amount');
				const originalPrice = $paymentAmount.data('original-base-price');
				if (originalPrice) {
					$paymentAmount.data('base-price', originalPrice);
					if (window.PontifexOI && typeof window.PontifexOI.updateAllDynamicPrices === 'function') {
						window.PontifexOI.updateAllDynamicPrices();
					}
				}
			}
			updateWeekendLocks();
			updateOrderSummaryText();
			if (window.PontifexOI && typeof window.PontifexOI.updateCandidateCountAndPrice === 'function') {
				window.PontifexOI.updateCandidateCountAndPrice();
			}
		});
		updateWeekendLocks();
		updateOrderSummaryText();
		updateTotalPriceWithCheckboxes();
	};

	$(document).on('change', '.extra-material-checkbox[value="cursus-weekend"], input[value="cursus-weekend"]', function() {
		const isChecked = $(this).is(':checked');
		const examType = $('select[name="exam_type"]').val() || '';
		const isBasisOrVol = ['los-examen-vca-basis', 'los-examen-vca-vol'].includes(examType);
		console.log('Weekend checkbox changed:', {
			isChecked,
			examType,
			isBasisOrVol,
			shouldUseWeekendPrice: isChecked && isBasisOrVol
		});
		if (isChecked && isBasisOrVol) {
			$('.pontifex-oi-dynamic-price').each(function() {
				const $el = $(this);
				const $loader = $el.find('.pontifex-oi-price-loader');
				const $amount = $el.find('.pontifex-oi-price-amount');
				$amount.text('€245,00');
				$loader.hide();
				$el.addClass('is-hydrated').attr('data-hydrated', '1');
				const $row = $el.closest('tr, .pontifex-oi-card, .acc-item');
				const $priceInput = $row.find('input[name="price"], .pontifex-oi-price-input');
				if ($priceInput.length) {
					$priceInput.val('245.00');
				}
			});
			const candidateCount = $('.pontifex-oi-candidates-list .pontifex-oi-candidate-row').length || 1;
			const weekendTotal = 245 * candidateCount;
			$('#total-price').text(`€${weekendTotal.toFixed(2).replace('.', ',')}`);
			$('#payment_amount').val(weekendTotal.toFixed(2));
			if (window.PontifexOI && window.PontifexOI.__priceCache) {
				window.PontifexOI.__priceCache = {};
			}
		} else {
			if (window.PontifexOI && typeof window.PontifexOI.updateAllDynamicPrices === 'function') {
				if (window.PontifexOI.__priceCache) {
					window.PontifexOI.__priceCache = {};
				}
				setTimeout(() => {
					window.PontifexOI.updateAllDynamicPrices();
				}, 100);
			}
		}
		if (window.PontifexOI && typeof window.PontifexOI.updateCandidateCountAndPrice === 'function') {
			window.PontifexOI.updateCandidateCountAndPrice();
		}
	});

	$(document).ready(() => {
		renderExtraMaterial();
		updateOrderSummaryText();
	});

	// De renderExtraMaterial wordt al aangeroepen via de 'select[name="language"]' handler in de Material Select Logic
	$(document).on('change', 'select[name="exam_type"]', renderExtraMaterial);
	$(document).on('change', '#extra-material-checkboxes input, select[name="exam_type"], select[name="language"]', updateOrderSummaryText);
	$(document).on('click', '.pontifex-oi-add-candidate, .pontifex-oi-remove-candidate', () => {
		PontifexOI.updateTotalPriceWithCheckboxes();
	});

	PontifexOI.updateExtraMaterialCheckboxes = renderExtraMaterial;
	PontifexOI.updateTotalPriceWithCheckboxes = updateTotalPriceWithCheckboxes;
})(window, jQuery);

// --- Debounce Logic ---
(function($) {
	'use strict';
	const debounce = (fn, wait = 150) => {
		let timeout;
		return (...args) => {
			clearTimeout(timeout);
			timeout = setTimeout(() => fn.apply(this, args), wait);
		};
	};

	function updateMaterial() {
		$(document).trigger('pontifex:recalc-total');
	}

	$(document).on('change', 'select[name="material"]', debounce(updateMaterial, 200));
})(jQuery);