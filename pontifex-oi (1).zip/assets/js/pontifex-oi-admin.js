jQuery(function ($) {
'use strict';
// Detect admin environment and skip if not in admin (prevents interference from admin logic on frontend)
if (!window.location.pathname.includes('/wp-admin/')) {
  console.log('[Pontifex OI] Not in admin — skipping admin logic');
  return;
}
console.log('[Pontifex OI] Admin detected — running admin logic');
// ===================== Globals & i18n =====================
const I18N = (window.POI_PRICES_DATA && POI_PRICES_DATA.i18n) || {};
// Utility function for translation (t(key, fallback))
const t = (k, d) => (I18N[k] || d || k);
// Retrieve ajaxurl and nonce from the localized script data
const ajaxurl = (window.PontifexOIAdmin && PontifexOIAdmin.ajaxUrl) || '';
const ajaxNonce = (window.PontifexOIAdmin && PontifexOIAdmin.nonce) || ''; // Haalt de nonce op
// Variable om de huidige AJAX-request op te slaan voor aborting
let currentSubmissionRequest;
// ===================== Utils =====================
const debounce = (fn, delay = 150) => {
let to;
return (...args) => {
clearTimeout(to);
to = setTimeout(() => fn.apply(null, args), delay);
};
};
// ===================== Prices UI State =====================
const $app = $('#pontifex-prices-app');
const $input = $('#pontifex_oi_prices');
let state = (() => {
try {
const raw = $app.data('initial');
const obj = raw ? JSON.parse(raw) : {};
return (obj && typeof obj === 'object') ? obj : {};
} catch (e) {
return {};
}
})();
function ensureState() {
if (!state || typeof state !== 'object') state = {};
if (!Array.isArray(state.courses)) state.courses = [];
if (state.courses.length === 0) {
state.courses.push({
name: '',
languages: {
nl: ''
},
_currentLang: 'nl'
});
}
state.courses.forEach(c => {
if (!c || typeof c !== 'object') return;
if (!c.languages || typeof c.languages !== 'object') c.languages = {
nl: ''
};
const keys = Object.keys(c.languages);
if (!c._currentLang || !c.languages[c._currentLang]) c._currentLang = keys[0] || 'nl';
});
}
const saveHidden = debounce(() => {
try {
$input.val(JSON.stringify(state));
} catch (_) {}
}, 150);
function addCourse(afterIndex) {
const course = {
name: '',
languages: {
nl: ''
},
_currentLang: 'nl'
};
if (typeof afterIndex === 'number') state.courses.splice(afterIndex + 1, 0, course);
else state.courses.push(course);
}
function renderPrices() {
ensureState();
$app.empty();
state.courses.forEach((course, idx) => {
const $row = $('<div class="pontifex-row" />');
const $name = $('<input type="text" class="pontifex-admin-input" />')
.attr('placeholder', t('course', 'Cursus'))
.val(course.name || '')
.on('input', function () {
course.name = $(this).val();
saveHidden();
});
const $select = $('<select class="pontifex-admin-input" />')
.on('change', function () {
course._currentLang = $(this).val();
$price.val(course.languages[course._currentLang] || '');
saveHidden();
});
Object.keys(course.languages).forEach(code => {
$select.append($('<option/>').attr('value', code).text(code.toUpperCase()));
});
$select.val(course._currentLang);
const $addLang = $('<button type="button" class="pontifex-icon-btn" title="' + t('add', 'Toevoegen') + '">+</button>')
.on('click', function () {
// IMPORTANT: Must use custom modal UI instead of prompt() in production apps
const code = prompt(t('add_lang_prompt', 'Voer taalcode in (bijv. nl, en, fr):'));
if (!code) return;
const key = code.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
if (!key) return;
if (Object.prototype.hasOwnProperty.call(course.languages, key)) {
console.error(t('lang_exists', 'Taal bestaat al.'));
return;
}
course.languages[key] = '';
course._currentLang = key;
renderPrices();
saveHidden();
});
const $remLang = $('<button type="button" class="pontifex-icon-btn" title="' + t('remove', 'Verwijderen') + '">−</button>')
.on('click', function () {
const keys = Object.keys(course.languages);
if (keys.length <= 1) {
console.error(t('need_one_lang', 'Minimaal één taal nodig.'));
return;
}
// IMPORTANT: Must use custom modal UI instead of confirm() in production apps
if (!confirm(t('confirm_remove_lang', 'Weet u zeker dat u deze taal wilt verwijderen?'))) return;
delete course.languages[course._currentLang];
course._currentLang = Object.keys(course.languages)[0];
renderPrices();
saveHidden();
});
const $langWrap = $('<div class="pontifex-lang-actions" />').append($select, $addLang, $remLang);
const $price = $('<input type="number" step="0.01" min="0" class="pontifex-admin-input" />')
.attr('placeholder', t('price', 'Prijs'))
.val(course.languages[course._currentLang] || '')
.on('input', function () {
course.languages[course._currentLang] = $(this).val();
saveHidden();
})
.on('blur', function () {
const val = $(this).val();
if (val !== '') {
let num = parseFloat(String(val).replace(',', '.'));
if (!isNaN(num) && num >= 0) {
const fix = num.toFixed(2);
$(this).val(fix);
course.languages[course._currentLang] = fix;
saveHidden();
}
}
});
const $addCourseBtn = $('<button type="button" class="pontifex-icon-btn" title="' + t('add', 'Toevoegen') + '">+</button>')
.on('click', function () {
addCourse(idx);
renderPrices();
saveHidden();
});
const $remCourseBtn = $('<button type="button" class="pontifex-icon-btn" title="' + t('remove', 'Verwijderen') + '">−</button>')
.on('click', function () {
if (state.courses.length <= 1) {
console.error(t('need_one_course', 'Minimaal één cursus nodig.'));
return;
}
// IMPORTANT: Must use custom modal UI instead of confirm() in production apps
if (!confirm(t('confirm_remove_course', 'Weet u zeker dat u deze cursus wilt verwijderen?'))) return;
state.courses.splice(idx, 1);
renderPrices();
saveHidden();
});
$row.append(
$('<div/>').append($name),
$('<div/>').append($langWrap),
$('<div/>').append($price),
$('<div class="pontifex-prices-actions-col"/>').append($addCourseBtn, ' ', $remCourseBtn)
);
$app.append($row);
});
$('.pontifex-add-course').off('click').on('click', function () {
addCourse();
renderPrices();
saveHidden();
});
saveHidden();
}
// ===================== Notices & UI =====================
function setupSuccessNotice() {
const $msg = $('#message.updated.notice-success');
if ($msg.length) {
setTimeout(() => {
$msg.addClass('hide').one('transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd', function () {
$(this).remove();
});
}, 3500);
}
}
    function setupTestModeToggle() {
        const $testToggle = $('#pontifex_oi_mollie_test_mode');
        const $toggleSwitch = $testToggle.parent('.pontifex-toggle-switch');
        const $toggleLabel = $('.pontifex-toggle-label');
        const $hiddenField = $('input[type="hidden"][name="pontifex_oi_mollie_test_mode"]');
  
        if ($testToggle.length && $toggleSwitch.length) {
            const apply = (checked) => {
                $toggleSwitch.toggleClass('checked', checked);
                $toggleLabel.text(checked ? t('enabled', 'ingeschakeld') : t('disabled', 'uitgeschakeld'));
              
                // ✅ FIX: Update the hidden field value
                if ($hiddenField.length) {
                    $hiddenField.val(checked ? '1' : '0');
                }
            };
          
            const initialState = $testToggle.prop('checked');
            apply(initialState);
          
            $testToggle.on('change', function () {
                apply(this.checked);
            });
        }
    }
function setupInputSelection() {
$(document).on('focus', '.pontifex-admin-input', function () {
$(this).select();
});
}
// ===================== Mollie Validatie =====================
function setupMollieValidation() {
$('form[action="options.php"]').on('submit', function (e) {
const $live = $('#pontifex_oi_mollie_live_api_key');
const $test = $('#pontifex_oi_mollie_test_api_key');
const liveVal = ($live.val() || '').trim();
const testVal = ($test.val() || '').trim();
// Log een waarschuwing, maar voorkom geen indiening (zachte validatie).
if ($live.length && liveVal && !liveVal.startsWith('live_')) {
console.warn(t('live_key_warning', 'Let op: De live key hoort meestal te beginnen met "live_".'));
}
if ($test.length && testVal && !testVal.startsWith('test_')) {
console.warn(t('test_key_warning', 'Let op: De test key hoort meestal te beginnen met "test_".'));
}
return true;
});
}
// ===================== SOAP AJAX Logic =====================
function setupSoapFetch() {
const $fetchBtn = $('#pontifex-soap-fetch-btn');
const $feedback = $('#pontifex-soap-fetch-feedback');
let feedbackTimeout;
if (!$fetchBtn.length) return;
function hideFeedback() {
$feedback.removeClass('active').one('transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd', () => {
$feedback.html('').hide();
});
}
function showFeedback(html) {
clearTimeout(feedbackTimeout);
// Zet meteen de nieuwe HTML klaar
$feedback.html(html).show();
// Voeg class iets vertraagd toe zodat CSS-transitie triggert
setTimeout(() => {
$feedback.addClass('active');
}, 50);
// Laat het bericht 8 seconden zichtbaar blijven
feedbackTimeout = setTimeout(() => {
hideFeedback();
}, 5000);
}
$fetchBtn.on('click', function (e) {
e.preventDefault();
$fetchBtn.prop('disabled', true).text(t('processing', 'Bezig...'));
$feedback.hide().removeClass('active'); // ✅ enkel reset, geen hideFeedback()
// NONCE TOEGEVOEGD: Verplichte nonce-check in de PHP handler
const data = {
action: 'pontifex_oi_fetch_soap_data',
nonce: ajaxNonce, // <-- BELANGRIJK: Nonce toevoegen
soap_url: $('#pontifex_oi_soap_url').val(),
user_id: $('#pontifex_oi_soap_user_id').val(),
company_id: $('#pontifex_oi_soap_company_id').val(),
hash: $('#pontifex_oi_soap_hash').val()
};
$.ajax({
url: ajaxurl,
method: 'POST',
dataType: 'json',
data: data,
success: (response) => {
$fetchBtn.prop('disabled', false).text(t('fetch_data', 'Haal gegevens op'));
const html = response && response.success ?
`<div class="pontifex-soap-feedback success"><span class="pontifex-feedback-icon">&#10003;</span> <span>${t('fetch_success', 'Gegevens succesvol opgehaald en opgeslagen.')}</span></div>` :
`<div class="pontifex-soap-feedback error"><span class="pontifex-feedback-icon">&#10060;</span> <span>${(response && response.data && response.data.message) || t('fetch_failed', 'Ophalen mislukt. Probeer opnieuw.')}</span></div>`;
showFeedback(html);
},
error: (xhr) => {
$fetchBtn.prop('disabled', false).text(t('fetch_data', 'Haal gegevens op'));
const errorMessage = (xhr?.responseJSON?.data?.message || t('fetch_failed', 'Ophalen mislukt. Probeer opnieuw.'));
showFeedback(`<div class="pontifex-soap-feedback error"><span class="pontifex-feedback-icon">&#10060;</span> <span>${errorMessage}</span></div>`);
}
});
});
}
// ===================== Inzendingen AJAX Logic =====================
// ---- helper: log response voor debugging ----
function logResponse(response) {
console.log('AJAX Response:', response);
console.log('Response type:', typeof response);
console.log('Response.data type:', typeof response?.data);
console.log('Response.data.rows type:', Array.isArray(response?.data?.rows) ? 'array' : typeof response?.data?.rows);
}
// ---- helper: render cards (UPDATED) ----
function renderCards(data) {
const $grid = $('#poi_sub_cardgrid');
$grid.empty();
if (!data || typeof data !== 'object' || !Array.isArray(data.rows)) {
data = {
rows: []
};
}
if (data.rows.length === 0) {
$grid.html(`
<div class="pontifex-oi-card-item">
<div class="pontifex-oi-card-body">
<strong>${t('no_submissions_found', 'Geen inzendingen gevonden.')}</strong><br/>
<em>${t('try_another_search', 'Probeer een andere zoekterm.')}</em>
</div>
</div>
`);
return;
}
data.rows.forEach((row, idx) => {
if (!row || typeof row !== 'object') return;
// Gebruik 'title' uit de data, anders een fallback
const title = row.title || `${t('submission', 'Inzending')} #${idx+1}`;
const fields = Array.isArray(row.fields) ? row.fields : [];
// Bouw alle velden onder elkaar
const bodyLines = fields.map(f => {
const label = (f && f.label) ? f.label : '';
const value = (f && f.value) ? f.value : '';
// Gebruik een check voor lege label/waarde om lege divs te vermijden
if (!label && !value) return '';
return `<div><strong>${label}:</strong> ${value}</div>`;
}).join('');
const card = `
<div class="pontifex-oi-card-item">
<div class="pontifex-oi-card-header">${title}</div>
<div class="pontifex-oi-card-body">
${bodyLines}
</div>
</div>
`;
$grid.append(card);
});
}
function setupSubmissionsAjax() {
if (!$('#poi_sub_cardgrid').length) return;
// 🔍 DEBUG: Check localized script data availability
console.log('window.PontifexOIAdmin:', window.PontifexOIAdmin);
console.log('ajaxurl waarde:', ajaxurl);
const $grid = $('#poi_sub_cardgrid');
const $pagination = $('#poi_sub_pagination');
const $pageinfo = $('#poi_sub_pageinfo');
const $perPageSel = $('#poi_sub_perpage');
const $searchInput = $('#poi_sub_s');
let currentRequest = currentSubmissionRequest;
// ---- helper: ophalen via AJAX ----
function fetchSubmissions(page = 1) {
// Gebruik i18n voor loading message
$grid.attr('aria-busy', 'true').html(`
<div class="pontifex-oi-card-item pontifex-loading">
<div class="pontifex-oi-card-header">${t('loading', 'Laden...')}</div>
<div class="pontifex-oi-card-body">${t('please_wait', 'Even geduld...')}</div>
</div>
`);
// Abort de vorige request en sla de nieuwe op in de globale variabele
if (currentRequest && currentRequest.readyState !== 4) currentRequest.abort();
currentRequest = $.ajax({
url: ajaxurl,
method: 'POST',
dataType: 'json',
data: {
action: 'pontifex_oi_fetch_submissions',
nonce: ajaxNonce, // <-- BELANGRIJK: Nonce toevoegen
paged: page,
per_page: parseInt($perPageSel.val(), 10),
s: $searchInput.val() || ''
},
})
.done(function (response) {
logResponse(response);
$grid.removeAttr('aria-busy');
// CHECK IF RESPONSE HAS ERROR
if (!response.success) {
const errorMsg = response.data?.message || t('loading_error_generic', 'Er is een fout opgetreden. Probeer opnieuw.');
$grid.html(`
<div class="pontifex-oi-card-item">
<div class="pontifex-oi-card-header">${t('error', 'Fout')}</div>
<div class="pontifex-oi-card-body">${errorMsg}</div>
</div>
`);
return;
}
if (response.success && response.data) {
const data = {
rows: response.data.rows || [],
total: response.data.total || 0,
page: response.data.page || 1,
pages: response.data.pages || 1
};
renderCards(data);
// paginatie info
$pageinfo.text(`${data.page} / ${data.pages}`);
$pagination.toggle(data.pages > 1);
$pagination.find('[data-direction="prev"]').prop('disabled', data.page <= 1);
$pagination.find('[data-direction="next"]').prop('disabled', data.page >= data.pages);
} else {
// Fallback for unexpected success/no-data situations
$grid.html(`
<div class="pontifex-oi-card-item">
<div class="pontifex-oi-card-header">${t('no_data_header', 'Geen gegevens')}</div>
<div class="pontifex-oi-card-body">${t('no_submissions_found', 'Geen inzendingen gevonden.')}</div>
</div>
`);
}
})
.fail(function (xhr, status, err) {
if (status === 'abort') return;
console.error('Fout bij laden inzendingen:', err, xhr.status);
$grid.removeAttr('aria-busy').html(`
<div class="pontifex-oi-card-item">
<div class="pontifex-oi-card-header">${t('error', 'Fout')}</div>
<div class="pontifex-oi-card-body">
${t('loading_error_generic', `Er is een fout opgetreden (${xhr.status}). Probeer opnieuw.`)}
</div>
</div>
`);
});
// Update de globale variabele voor gebruik buiten deze scope
currentSubmissionRequest = currentRequest;
}
// ---- events ----
$('#poi_sub_apply').on('click', e => {
e.preventDefault();
fetchSubmissions(1);
});
$perPageSel.on('change', () => fetchSubmissions(1));
// Use the debounce utility function for search
$searchInput.on('input', debounce(() => fetchSubmissions(1), 400));
$searchInput.on('keypress', e => {
if (e.which === 13) {
e.preventDefault();
fetchSubmissions(1);
}
});
$pagination.find('button').on('click', function () {
const dir = $(this).data('direction');
// Use the page info to determine current page, then fetch
const pageText = $pageinfo.text().trim();
const match = pageText.match(/(\d+)\s*\/\s*(\d+)/);
let current = 1;
if (match) {
current = parseInt(match[1], 10);
}
fetchSubmissions(dir === 'next' ? current + 1 : current - 1);
});
// ---- init ----
fetchSubmissions(1);
}
// ===================== Save Button Protection =====================
function setupSaveButtonProtection() {
  const $form = $('form[action="options.php"]');
  const $btn = $('.pontifex-admin-submit');
  // Laat de button met rust bij pageload
  // Geen tekst wijzigen, niet (de)activeren
  $form.on('submit', function () {
    // Disable tijdens submit om dubbelklikken te voorkomen
    $btn.prop('disabled', true).text(t('saving', 'Opslaan...'));
  });
}
// ===================== Init =====================
function init() {
setupSuccessNotice();
setupTestModeToggle();
setupInputSelection();
setupMollieValidation();
setupSoapFetch();
setupSubmissionsAjax(); // De inzendingen functie
renderPrices();
setupSaveButtonProtection();
}
init();
});