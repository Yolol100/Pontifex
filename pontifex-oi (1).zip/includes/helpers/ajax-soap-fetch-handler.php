<?php
/**
 * Handler voor het ophalen en opslaan van SOAP planning via AJAX in de admin.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('pontifex_oi_fetch_soap_data_handler')) {
    function pontifex_oi_fetch_soap_data_handler() {
        // Step 1: Security Check - Verify user and nonce.
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Geen toegang.', 'pontifex-oi')]);
        }

        // Verify the security token (nonce) to prevent CSRF attacks.
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'pontifex_oi_admin')) {
            wp_send_json_error(['message' => __('Ongeldige beveiligingstoken.', 'pontifex-oi')]);
        }

        try {
            // Step 2: Load the SOAP client.
            if (!class_exists('\PontifexOI\Api\SoapClient')) {
                require_once dirname(__FILE__, 2) . '/api/class-soap-client.php';
            }

            // Step 3: Execute the SOAP request.
            $soap    = new \PontifexOI\Api\SoapClient();
            $updated = $soap->fetchAndStorePlanning();
            $count   = is_array($updated) ? count($updated) : 0;

            // Step 4: Return a clear response.
            if ($count === 0) {
                error_log('PontifexOI AJAX: geen nieuwe of gewijzigde planning-items.');
                wp_send_json_error([
                    'message' => __('Ophalen gelukt, maar er zijn geen nieuwe of gewijzigde items (0).', 'pontifex-oi')
                ]);
            } else {
                error_log('PontifexOI AJAX: ' . $count . ' planningen bijgewerkt via admin.');
                wp_send_json_success([
                    'message' => sprintf(__('Planning opgehaald en verwerkt: %d items.', 'pontifex-oi'), $count),
                    'count'   => $count
                ]);
            }

        } catch (\Exception $e) {
            error_log('PontifexOI AJAX fout: ' . $e->getMessage());
            wp_send_json_error(['message' => $e->getMessage()]);
        }

        wp_die();
    }
}