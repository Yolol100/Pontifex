<?php
declare(strict_types=1);

namespace PontifexOI\Helpers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Zorg dat de charset altijd UTF-8 is voor e-mails.
 */
add_filter('wp_mail_charset', static fn(): string => 'UTF-8');

/**
 * Laad de centrale productconfiguratie.
 */
require_once PONTIFEX_OI_PATH . 'includes/config/producten-prijzen.php';

final class MailHelpers
{
    /**
     * Labels voor examens
     */
    public static function get_exam_label(string|int $id): string
    {
        $exam_labels = [
            'los-examen-vca-basis' => 'VCA Basis',
            'los-examen-vca-vol'   => 'VCA Vol',
            'vca-basis-weekend'    => 'VCA Basis Cursus Weekend',
            'vca-vol-weekend'      => 'VCA Vol Cursus Weekend',
        ];
        return (string) ($exam_labels[$id] ?? $id);
    }

    /**
     * Labels voor talen
     */
    public static function get_language_label(string $id): string
    {
        $language_labels = [
            'nl' => 'Nederlands', 
            'en' => 'Engels',
            'de' => 'Duits',
            'fr' => 'Frans',
            'pl' => 'Pools',
            'ro' => 'Roemeens',
            'tr' => 'Turks'
        ];
        return $language_labels[$id] ?? $id;
    }

    /**
     * Labels voor materiaalcombinaties
     */
    public static function get_material_combination_label(string|int $id): string
    {
        $material_labels = [
            '1' => 'Examen',
            '2' => 'Examen + boek',
            '4' => 'Examen + e-learning',
            '5' => 'Examen + proefexamens',
            '6' => 'Examen + boek + proefexamens',
            '7' => 'Examen + e-learning + proefexamens',
        ];
        return $material_labels[(string)$id] ?? 'Geen keuze';
    }

    /**
     * Label voor individueel materiaal vanuit ProductRegistry
     */
    public static function get_material_label(string|int $id): string
    {
        // Gebruik de ProductRegistry indien beschikbaar voor prijzen/labels
        if (class_exists('\ProductRegistry')) {
            $data = \ProductRegistry::getDataForJavaScript();
            return $data['materialProducts'][$id]['label'] ?? (string)$id;
        }
        return (string)$id;
    }

    /**
     * NIEUW: De centrale methode aangeroepen door de Webhook Handler
     */
    public static function send_confirmation_emails(array $order_data): void 
    {
        // $order_data bevat de database rij, de echte formulierdata zit in de 'data' key (via hydrate/json_decode)
        $data = $order_data['data'] ?? $order_data;
        self::send_inschrijving_mails($data);
    }

    /**
     * Verstuurt de e-mails naar klant en eigenaar
     */
    public static function send_inschrijving_mails(array $order): void
    {
        // --- Normaliseer formulier-keys (Mapping van diverse veldnamen) ---
        $map = [
            'order_initials'    => $order['given-name'] ?? ($order['first_name'] ?? null),
            'order_infix'       => $order['additional-name'] ?? ($order['infix'] ?? null),
            'order_lastname'    => $order['family-name'] ?? ($order['last_name'] ?? null),
            'order_postcode'    => $order['postal-code'] ?? ($order['postcode'] ?? null),
            'order_housenumber' => $order['address-line2'] ?? ($order['housenumber'] ?? null),
            'order_street'      => $order['street-address'] ?? ($order['street'] ?? null),
            'order_city'        => $order['address-level2'] ?? ($order['city'] ?? null),
            'order_phone'       => $order['tel'] ?? ($order['phone'] ?? null),
            'order_email'       => $order['order_email'] ?? ($order['email'] ?? null),
            'order_company'     => $order['organization'] ?? ($order['company_name'] ?? null),
            'order_vat'         => $order['order_vat'] ?? ($order['vat_number'] ?? null),
        ];

        foreach ($map as $k => $v) {
            if (!isset($order[$k]) && $v !== null) {
                $order[$k] = $v;
            }
        }

        // --- Verrijk data met labels ---
        $order['exam_label']     = self::get_exam_label($order['exam_type'] ?? '');
        $order['language_label'] = self::get_language_label($order['language'] ?? '');
        $order['material_label'] = self::get_material_combination_label($order['material'] ?? '');

        // --- Verwerk extra opties ---
        $extra = [];
        if (!empty($order['extra_material'])) {
            $extra = array_merge($extra, (array) $order['extra_material']);
        }
        if (!empty($order['extra_options'])) {
            $extra = array_merge($extra, (array) $order['extra_options']);
        }
        $order['extra_material'] = array_values(array_unique($extra));

        // Controleer op weekendcursus
        $order['_has_weekend'] = false;
        foreach ($order['extra_material'] as $id) {
            if (str_starts_with((string)$id, 'cursus-weekend')) {
                $order['_has_weekend'] = true;
                break;
            }
        }

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: Certipro <info@test1.certipro.nl>'
        ];

        /**
         * 📨 KLANTMAIL
         */
        ob_start();
        include PONTIFEX_OI_PATH . 'public/emails/payment-success-email-template.php';
        $klantmail = ob_get_clean();

        $to_klant = $order['order_email'] ?? '';
        if (!empty($to_klant)) {
            $subject_klant = 'Bevestiging inschrijving - ' . $order['exam_label'];
            wp_mail($to_klant, $subject_klant, $klantmail, $headers);
        }

        /**
         * 📨 EIGENAARSMAIL (Admin Notificatie)
         */
        ob_start();
        include PONTIFEX_OI_PATH . 'public/emails/owner-notification-email-template.php';
        $eigenaarmail = ob_get_clean();

        // Kandidaat naam bepalen voor het onderwerp
        $kandidaat_fullname = $order['candidate_fullname'][0] ?? ($order['order_initials'] ?? 'Nieuwe');
        $kandidaat_achternaam = $order['candidate_lastname'][0] ?? ($order['order_lastname'] ?? 'Inschrijving');

        $subject_owner = 'Nieuwe inschrijving van ' . trim($kandidaat_fullname . ' ' . $kandidaat_achternaam);
        $to_owner = 'planning@test1.certipro.nl';

        wp_mail($to_owner, $subject_owner, $eigenaarmail, $headers);
    }

    /**
     * Formatteert de examen-naam voor overzichten
     */
    public static function format_exam_label_for_summary(array $order): string
    {
        $examRaw = $order['exam_type'] ?? '';
        
        // Gebruik de ProductRegistry label als die bestaat
        if (class_exists('\ProductRegistry') && isset(\ProductRegistry::EXAMS[$examRaw])) {
            $label = \ProductRegistry::EXAMS[$examRaw]['label'];
        } else {
            $label = self::get_exam_label($examRaw);
        }

        $extrasAll = array_merge(
            (array) ($order['extra_material'] ?? []),
            (array) ($order['extra_options'] ?? [])
        );

        $weekend = false;
        foreach ($extrasAll as $eid) {
            if (str_starts_with((string)$eid, 'cursus-weekend')) {
                $weekend = true;
                break;
            }
        }

        return $weekend ? ($label . ' met cursusweekend en examen') : ($label . ' met examen');
    }
}