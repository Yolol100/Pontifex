<?php
/**
 * Pontifex OI - SOAP Client
 * Geüpdatet voor:
 * - MariaDB/MySQL compatibiliteit
 * - Correcte $wpdb prepare usage
 * - Consistente postcode veldnaam (location_postcode)
 * - Veilige debugHandshake
 */
namespace PontifexOI\Api;

use Exception;

if (!defined('ABSPATH')) {
    exit;
}

class SoapClient
{
    private $client = null;

    private $endpoint;

    private $options = [
        'trace'              => 1,
        'exceptions'         => 1,
        'cache_wsdl'         => WSDL_CACHE_BOTH,
        'connection_timeout' => 15,
        'compression'        => SOAP_COMPRESSION_ACCEPT | SOAP_COMPRESSION_GZIP,
        'features'           => SOAP_SINGLE_ELEMENT_ARRAARS,
    ];

    public function __construct()
    {
        $this->endpoint = get_option(
            'pontifex_oi_soap_url',
            'https://staging-webservice.pontifexcertificatie.nl/service.php/?wsdl'
        );
    }

    private function getClient(): \SoapClient
    {
        if ($this->client === null) {
            try {
                $this->client = new \SoapClient($this->endpoint, $this->options);
            } catch (\Exception $e) {
                error_log('PontifexOI: SOAP client aanmaken gefaald: ' . $e->getMessage());
                throw new Exception('SOAP client kon niet worden aangemaakt: ' . $e->getMessage());
            }
        }
        return $this->client;
    }

    /**
     * Deze plugin gebruikt geen registratie via SOAP meer.
     * Alleen planning wordt opgehaald.
     */
    public function sendRegistration(array $order): bool
    {
        // Logging wordt nu meestal in de webhook afgehandeld
        return true;
    }

    /**
     * Hoofdmethode: haalt planning op via SOAP en slaat deze lokaal op
     */
    public function fetchAndStorePlanning(): array
    {
        global $wpdb;

        $table_name = $wpdb->prefix . 'pontifex_planning';

        $user_identifier = (int) get_option('pontifex_oi_soap_user_id');
        $hash = trim((string) get_option('pontifex_oi_soap_hash'));

        if (empty($user_identifier) || empty($hash)) {
            error_log("PontifexOI SOAP ERROR - Lege authenticatievelden.");
            throw new Exception('SOAP authenticatiegegevens ontbreken.');
        }

        $params = [
            'user_identifier' => $user_identifier,
            'hash'            => $hash,
        ];

        $plannings = $this->callGetWalkInPlanning($params);

        $seenIds = [];
        foreach ($plannings as $planning) {
            $data = $this->mapPlanningData($planning);
            $this->upsertPlanningRecord($data);
            $seenIds[] = $data['planning_identifier'];
        }

        $this->cleanupObsoletePlanningRecords($seenIds);
        $this->invalidateAllPlanningCaches();

        return $seenIds;
    }

    private function callGetWalkInPlanning(array $params): array
    {
        $client = $this->getClient();

        try {
            $response = $client->__soapCall('getWalkInPlanning', $params);

            if (is_object($response) && isset($response->getWalkInPlanningResult)) {
                $response = $response->getWalkInPlanningResult;
            }

            if ($response instanceof \stdClass) {
                $response = [$response];
            } elseif (isset($response['planning_identifier'])) {
                $response = [(object) $response];
            }

            if (!is_array($response) || empty($response)) {
                error_log("PontifexOI ERROR - Geen planningen ontvangen van SOAP API.");
                return [];
            }

            return array_map(fn($item) => is_array($item) ? (object)$item : $item, $response);
        } catch (\Exception $e) {
            error_log('PontifexOI SOAP fout bij ophalen planning: ' . $e->getMessage());
            if (method_exists($e, 'getResponse')) {
                error_log('Response: ' . $e->getResponse());
            }
            throw $e;
        }
    }

    private function mapPlanningData(object $planning): array
    {
        $loc = $planning->location ?? null;

        return [
            'planning_identifier' => (string) ($planning->planning_identifier ?? ''),
            'planning_date'       => $planning->planning_date ?? null,
            'planning_time'       => $planning->planning_time ?? null,
            'planning_start_date' => $planning->planning_start_date
                ? date('Y-m-d H:i:s', strtotime($planning->planning_start_date))
                : null,
            'planning_updated'    => $planning->planning_updated
                ? date('Y-m-d H:i:s', strtotime($planning->planning_updated))
                : null,
            'planning_status'     => $planning->planning_status ?? null,
            'available_seats'     => (int) ($planning->available_seats ?? 0),
            'location_identifier' => $loc?->location_identifier ?? null,
            'location_name'       => $loc?->location_name ?? '',
            'location_street'     => $loc?->location_street ?? '',
            'location_number'     => $loc?->location_number ?? '',
            'location_suffix'     => $loc?->location_suffix ?? '',
            // Consequente veldnaam: location_postcode (matcht DB kolom)
            'location_postcode'   => $loc?->Postcode
                ?? $loc?->location_postcode
                ?? $planning->Postcode ?? '',
            'location_city'       => $loc?->location_city ?? '',
            'location_province'   => $loc?->location_province ?? '',
            'location_country'    => $loc?->location_country ?? '',
            'location_seats'      => (int) ($loc?->location_seats ?? 0),
        ];
    }

    private function upsertPlanningRecord(array $data): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'pontifex_planning';

        $columns      = array_keys($data);
        $placeholders = implode(', ', array_fill(0, count($columns), '%s'));
        $values       = array_values($data);

        $set = [];
        foreach ($columns as $column) {
            if ($column === 'planning_identifier') {
                continue;
            }
            $set[] = "$column = VALUES($column)";
        }

        $query = $wpdb->prepare(
            "INSERT INTO {$table} (" . implode(', ', $columns) . ")
             VALUES ($placeholders)
             ON DUPLICATE KEY UPDATE " . implode(', ', $set),
            ...$values
        );

        $wpdb->query($query);
    }

    private function cleanupObsoletePlanningRecords(array $currentIds): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'pontifex_planning';

        if (empty($currentIds)) {
            $wpdb->query("DELETE FROM {$table} WHERE planning_date >= CURDATE()");
            return;
        }

        $placeholders = implode(',', array_fill(0, count($currentIds), '%s'));
        $query = $wpdb->prepare(
            "DELETE FROM {$table}
             WHERE planning_identifier NOT IN ($placeholders)
             AND planning_date >= CURDATE()",
            ...$currentIds
        );

        $wpdb->query($query);
    }

    private function invalidateAllPlanningCaches(): void
    {
        delete_transient('pontifex_oi_filter_months');
        delete_transient('pontifex_oi_filter_provinces');

        global $wpdb;
        $table = $wpdb->prefix . 'pontifex_planning';

        $provinces = $wpdb->get_col("
            SELECT DISTINCT location_province
            FROM {$table}
            WHERE location_province IS NOT NULL 
              AND location_province <> ''
        ");

        foreach ($provinces as $province) {
            $key = 'pontifex_oi_filter_cities_' . sanitize_title($province);
            delete_transient($key);
        }
    }

    public function getPlanning(array $filters = [], int $per_page = 0, int $offset = 0): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'pontifex_planning';

        $where = ["planning_date >= CURDATE()"];
        $args  = [];

        if (!empty($filters['month'])) {
            $where[] = "DATE_FORMAT(planning_date, '%Y-%m') = %s";
            $args[]  = $filters['month'];
        }

        if (!empty($filters['province'])) {
            $where[] = "location_province = %s";
            $args[]  = $filters['province'];
        }

        if (!empty($filters['city']) || !empty($filters['location'])) {
            $city    = $filters['city'] ?? $filters['location'] ?? '';
            $where[] = "location_city = %s";
            $args[]  = $city;
        }

        if (!empty($filters['timeslot'])) {
            $slot = $filters['timeslot'];
            if ($slot === 'ochtend') {
                $where[] = "HOUR(planning_time) < 12";
            } elseif ($slot === 'middag') {
                $where[] = "HOUR(planning_time) >= 12 AND HOUR(planning_time) < 18";
            } elseif ($slot === 'avond') {
                $where[] = "HOUR(planning_time) >= 18";
            }
        }

        $sql = "SELECT * FROM {$table} WHERE " . implode(' AND ', $where);
        $sql .= " ORDER BY planning_date ASC, planning_time ASC";

        if ($per_page > 0) {
            $sql .= " LIMIT %d OFFSET %d";
            $args[] = $per_page;
            $args[] = $offset;
        }

        $results = $wpdb->get_results(
            $wpdb->prepare($sql, ...$args),
            ARRAY_A
        );

        $formatted = [];
        foreach ($results ?: [] as $row) {
            $available = (int) $row['available_seats'];
            $total     = (int) $row['location_seats'];

            $spots_text = match (true) {
                $available > 0  => $available . ' plaatsen',
                $available === 0 => 'VOL',
                default         => $total . ' plaatsen (vrij onbekend)'
            };

            $formatted[] = [
                'date'     => date_i18n('d-m-Y (l)', strtotime($row['planning_date'])),
                'time'     => substr($row['planning_time'], 0, 5),
                'location' => $row['location_city'] ?: $row['location_name'],
                'province' => $row['location_province'],
                'spots'    => $spots_text,
                'price'    => '',
                'postcode' => $row['location_postcode'] ?? '',
            ];
        }

        return $formatted;
    }

    public function getMonths(): array
    {
        $cache = get_transient('pontifex_oi_filter_months');
        if ($cache !== false) {
            return $cache;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pontifex_planning';

        $months = $wpdb->get_col("
            SELECT DISTINCT DATE_FORMAT(planning_date, '%Y-%m') AS month
            FROM {$table}
            WHERE planning_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
            ORDER BY month ASC
        ");

        $out = [['id' => '', 'name' => 'Toon alles']];
        foreach ($months as $m) {
            $out[] = [
                'id'   => $m,
                'name' => ucfirst(date_i18n('F Y', strtotime($m . '-01')))
            ];
        }

        set_transient('pontifex_oi_filter_months', $out, HOUR_IN_SECONDS * 6);
        return $out;
    }

    public function getProvinces(): array
    {
        $cache = get_transient('pontifex_oi_filter_provinces');
        if ($cache !== false) {
            return $cache;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pontifex_planning';

        $provinces = $wpdb->get_col("
            SELECT DISTINCT location_province
            FROM {$table}
            WHERE location_province IS NOT NULL
              AND location_province <> ''
              AND planning_date >= CURDATE()
            ORDER BY location_province ASC
        ");

        $out = [['id' => '', 'name' => 'Toon alles']];
        foreach ($provinces as $p) {
            $out[] = ['id' => $p, 'name' => $p];
        }

        set_transient('pontifex_oi_filter_provinces', $out, HOUR_IN_SECONDS * 6);
        return $out;
    }

    public function getLocations(array $filters = []): array
    {
        $cacheKey = 'pontifex_oi_filter_cities';
        if (!empty($filters['province'])) {
            $cacheKey .= '_' . sanitize_title($filters['province']);
        }

        $cache = get_transient($cacheKey);
        if ($cache !== false) {
            return $cache;
        }

        global $wpdb;
        $t = $wpdb->prefix . 'pontifex_planning';

        $where = [
            "location_city IS NOT NULL",
            "location_city <> ''",
            "planning_date >= CURDATE()"
        ];
        $args = [];

        if (!empty($filters['province'])) {
            $where[] = "location_province = %s";
            $args[] = $filters['province'];
        }

        $sql = "
            SELECT DISTINCT location_city AS city, location_province AS province
            FROM {$t}
            WHERE " . implode(' AND ', $where) . "
            ORDER BY location_city ASC
        ";

        $results = $args
            ? $wpdb->get_results($wpdb->prepare($sql, ...$args), ARRAY_A)
            : $wpdb->get_results($sql, ARRAY_A);

        $out = [['id' => '', 'name' => 'Toon alles']];
        foreach ($results as $l) {
            $out[] = ['id' => $l['city'], 'name' => $l['city']];
        }

        set_transient($cacheKey, $out, 5 * MINUTE_IN_SECONDS);
        return $out;
    }

    public function getTimeslots(array $filters = []): array
    {
        return [
            ['id' => '',        'name' => 'Toon alles'],
            ['id' => 'ochtend', 'name' => 'Ochtend'],
            ['id' => 'middag',  'name' => 'Middag'],
            ['id' => 'avond',   'name' => 'Avond'],
        ];
    }

    public function getLanguages(array $filters = []): array
    {
        return [
            ['id' => 'nl', 'name' => 'Nederlands'],
            ['id' => 'en', 'name' => 'Engels'],
        ];
    }

    public function getMaterials(array $filters = []): array
    {
        return [
            ['id' => '', 'name' => 'Geen keuze'],
            ['id' => '1', 'name' => 'Los examen'],
            ['id' => '2', 'name' => 'Examen + boek'],
            ['id' => '4', 'name' => 'Examen + e-learning'],
            ['id' => '5', 'name' => 'Examen + proefexamens'],
            ['id' => '6', 'name' => 'Examen + boek + proefexamens'],
            ['id' => '7', 'name' => 'Examen + e-learning + proefexamens'],
        ];
    }

    private function maskHash(string $hash): string
    {
        if (empty($hash)) return '';
        return substr($hash, 0, 1) . '...' . substr($hash, -1);
    }

    public function debugHandshake(bool $do_ping = false): array
    {
        $out = ['ok' => false];

        try {
            $client = $this->getClient();
            $out['soap_functions'] = $client->__getFunctions();

            if ($do_ping) {
                $user_id = (int) get_option('pontifex_oi_soap_user_id', 0);
                $hash    = (string) get_option('pontifex_oi_soap_hash', '');

                if ($user_id && $hash) {
                    $client->__soapCall('getWalkInPlanning', [
                        'user_identifier' => $user_id,
                        'hash'            => $hash,
                    ]);
                }
            }

            $out['ok']            = true;
            $out['last_request']  = $client->__getLastRequest();
            $out['last_response'] = $client->__getLastResponse();
        } catch (\Throwable $e) {
            $out['message']       = $e->getMessage();
            // Veilige toegang: $client bestaat mogelijk niet bij een vroege exception
            $out['last_request']  = isset($client) ? $client->__getLastRequest() : null;
            $out['last_response'] = isset($client) ? $client->__getLastResponse() : null;
        }

        return $out;
    }
}