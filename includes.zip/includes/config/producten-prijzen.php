<?php
/**
 * Centrale product- en prijsregistratie - alles op één plek, geen globals meer
 * Met backward compatibility layer voor oude code die globals verwacht
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

final class ProductRegistry
{
    public const EXAMS = [
        'los-examen-vca-basis' => [
            'label' => 'VCA Basis',
            'prices' => [
                'nl' => 129, 'de' => 129, 'en' => 129, 'fr' => 129,
                'ar' => 149, 'bg' => 149, 'lt' => 149, 'pl' => 149,
                'pt' => 149, 'ro' => 149, 'ru' => 149, 'tr' => 149,
                'el' => 184, 'hu' => 184, 'it' => 184, 'hr' => 184,
                'uk' => 184, 'sk' => 184, 'es' => 184, 'vi' => 184,
            ],
        ],
        'los-examen-vca-basis-groen' => [
            'label' => 'VCA Basis Groen',
            'prices' => ['nl' => 129],
        ],
        'los-examen-vca-vol' => [
            'label' => 'VCA Vol',
            'prices' => [
                'nl' => 139, 'de' => 139, 'en' => 139, 'fr' => 139,
            ],
        ],
        'los-examen-vca-vil' => [
            'label' => 'VCA VIL',
            'prices' => [
                'nl' => 139, 'en' => 139,
            ],
        ],
        'vca-weekend-nl' => [
            'label' => 'WeekendCursus (NL)',
            'prices' => ['nl' => 245],
        ],
    ];

    public const EXTRA_PRODUCTS = [
        // 🇳🇱 Basis NL
        'vca_proefexamen_nl'     => ['label' => 'Proefexamen',                  'price' => 25.00],
        'vca_elearning_nl'       => ['label' => 'E-learning met proefexamen',  'price' => 29.00],
        'boek_basis_nl'          => ['label' => 'Boek',                         'price' => 36.00],
        'boek_combi_nl'          => ['label' => 'Boek combi',                   'price' => 49.00],

        // 🇬🇧 Basis EN
        'vca_proefexamen_en'     => ['label' => 'Practice exams',              'price' => 25.00],
        'vca_elearning_en'       => ['label' => 'E-learning with practice exam','price' => 49.00],
        'boek_basis_en'          => ['label' => 'Book',                         'price' => 56.00],
        'boek_combi_en'          => ['label' => 'Book combi',                   'price' => 69.00],

        // 🇳🇱 Vol NL
        'vca_vol_proefexamen_nl' => ['label' => 'Proefexamen',                  'price' => 25.00],
        'vca_vol_elearning_nl'   => ['label' => 'E-learning met proefexamen',  'price' => 39.00],
        'boek_vol_nl'            => ['label' => 'Boek',                         'price' => 42.00],
        'boek_combi_vol_nl'      => ['label' => 'Boek combi',                   'price' => 49.00],

        // 🇬🇧 Vol EN
        'vca_vol_proefexamen_en' => ['label' => 'Practice exams',              'price' => 25.00],
        'vca_vol_elearning_en'   => ['label' => 'E-learning with practice exam','price' => 59.00],
        'boek_vol_en'            => ['label' => 'Book',                         'price' => 62.00],
        'boek_combi_vol_en'      => ['label' => 'Book combi',                   'price' => 69.00],

        // Weekendcursus los
        'cursus-weekend-nl'      => ['label' => 'Met examen',                   'price' => 245.00],
        'cursus-weekend-en'      => ['label' => 'With exam',                    'price' => 245.00],

        // Vertaalde/aliassen / legacy keys
        'cursus-weekend'              => ['label' => 'Weekendcursus met examen',       'price' => 245.00],
        'vca-basis-proefexamens-nl'   => ['label' => 'VCA Basis Proefexamens (NL)',    'price' => 25.00],
        'vca-vol-proefexamens-nl'     => ['label' => 'VCA Vol Proefexamens (NL)',      'price' => 25.00],
        'proefexamens-en'             => ['label' => 'Proefexamens (EN)',              'price' => 25.00],
    ];

    private const COMBI_MAP = [
        '' => [],
        'boek' => [
            'basis' => ['boek_basis_nl'],
            'vol'   => ['boek_vol_nl'],
        ],
        'elearning' => [
            'basis' => ['vca_elearning_nl'],
            'vol'   => ['vca_vol_elearning_nl'],
        ],
        'proef' => [
            'basis' => ['vca_proefexamen_nl'],
            'vol'   => ['vca_vol_proefexamen_nl'],
        ],
        'boek_proef' => [
            'basis' => ['boek_basis_nl', 'vca_proefexamen_nl'],
            'vol'   => ['boek_vol_nl',   'vca_vol_proefexamen_nl'],
        ],
        'elearning_proef' => [
            'basis' => ['vca_elearning_nl', 'vca_proefexamen_nl'],
            'vol'   => ['vca_vol_elearning_nl', 'vca_vol_proefexamen_nl'],
        ],
    ];

    public const WEEKEND_ALLOWED_BY_EXAM = [
        'los-examen-vca-basis'       => ['nl', 'en'],
        'los-examen-vca-vol'         => ['nl', 'en'],
        'los-examen-vca-basis-groen' => [],
        'los-examen-vca-vil'         => [],
    ];

    private static function isPracticeExamItem(string $key, array $item): bool
    {
        return str_contains($key, 'proefexamen')
            || str_contains($key, 'proefexamens')
            || str_contains($key, 'practice')
            || str_contains(strtolower($item['label'] ?? ''), 'proef')
            || str_contains(strtolower($item['label'] ?? ''), 'practice');
    }

    public static function getFilteredExtraProducts(): array
    {
        return array_filter(
            self::EXTRA_PRODUCTS,
            static function (string $key, array $item): bool {
                // Verberg proefexamens die géén Nederlandse versie zijn
                return !(
                    self::isPracticeExamItem($key, $item)
                    && !str_contains($key, '_nl')
                    && !str_contains($key, '-nl')
                );
            },
            ARRAY_FILTER_USE_BOTH
        );
    }

    public static function normalizeExamKey(string $key): string
    {
        return match ($key) {
            'vca-basis'          => 'los-examen-vca-basis',
            'vca-vol'            => 'los-examen-vca-vol',
            'los-examen-vil-vcu' => 'los-examen-vca-vil',
            'vca-weekend-nl'     => 'vca-weekend-nl',
            default              => $key,
        };
    }

    public static function getExamPrice(string $examType, string $language = 'nl'): float
    {
        $examType = self::normalizeExamKey($examType);
        $prices = self::EXAMS[$examType]['prices'] ?? null;

        if ($prices === null) {
            return 0.0;
        }

        return (float) ($prices[$language] ?? $prices['nl'] ?? 0);
    }

    public static function getMaterialPrice(string $key): float
    {
        return (float) (self::EXTRA_PRODUCTS[$key]['price'] ?? 0.0);
    }

    /**
     * Berekent totaalprijs examen + materiaalcombinatie (klassieke 1 t/m 7 keuzes)
     */
    public static function calculateTotalPrice(
        string $examType,
        string $language = 'nl',
        string|int $materialChoice = '1'
    ): float {
        $total = self::getExamPrice($examType, $language);

        if ((string) $materialChoice === '1' || $materialChoice === '') {
            return $total;
        }

        $isVol = str_contains($examType, 'vol') || str_contains($examType, 'vil');
        $type = $isVol ? 'vol' : 'basis';

        $combiId = match ((string) $materialChoice) {
            '2' => 'boek',
            '4' => 'elearning',
            '5' => 'proef',
            '6' => 'boek_proef',
            '7' => 'elearning_proef',
            default => null,
        };

        if ($combiId === null || !isset(self::COMBI_MAP[$combiId][$type])) {
            return $total;
        }

        foreach (self::COMBI_MAP[$combiId][$type] as $materialKey) {
            $total += self::getMaterialPrice($materialKey);
        }

        return $total;
    }

    /**
     * Data-structuur voor JavaScript (frontend dropdowns, prijsberekening, etc.)
     */
    public static function getDataForJavaScript(): array
    {
        $examProducts = [];
        foreach (self::EXAMS as $key => $data) {
            $examProducts[$key] = [
                'label'  => $data['label'],
                'prices' => $data['prices'],
            ];
        }

        return [
            'examProducts'       => $examProducts,
            'materialProducts'   => self::EXTRA_PRODUCTS,
            'extraProducts'      => self::getFilteredExtraProducts(),
            'materialCombis'     => self::COMBI_MAP,
            'weekendAllowedByExam' => self::WEEKEND_ALLOWED_BY_EXAM,
        ];
    }
}

// =============================================================================
// === BACKWARD COMPATIBILITY LAYER - voor oude code die globals verwacht ===
// =============================================================================

$GLOBALS['EXAM_PRODUCTS']     = ProductRegistry::EXAMS;
$GLOBALS['EXTRA_PRODUCTS']    = ProductRegistry::EXTRA_PRODUCTS;
$GLOBALS['MATERIAL_PRODUCTS'] = ProductRegistry::EXTRA_PRODUCTS;

// Optioneel - als oude code expliciet MATERIAL_COMBIS verwacht
// (momenteel vaak niet nodig, maar ter veiligheid):
$GLOBALS['MATERIAL_COMBIS'] = ProductRegistry::COMBI_MAP;

// Voor heel oude code die nog de oude keys verwacht:
$GLOBALS['EXAM_PRICES'] = array_map(
    fn($exam) => $exam['prices'],
    ProductRegistry::EXAMS
);